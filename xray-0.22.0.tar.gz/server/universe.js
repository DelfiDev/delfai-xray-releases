// Stock universe for the Heat map and Stock screener: real data only.
//  - Members: S&P 500, Nasdaq-100 and Dow 30 lists (Wikipedia's public tables), plus your watchlists.
//  - Fundamentals: SEC XBRL "frames" (one call returns a concept for every US filer), latest full year + latest quarter-end.
//  - Prices: your broker's quotes. Technicals and performance: your broker's daily candles (cached, refreshed in the background).
// Anything a source doesn't give stays null and the app shows "—".
'use strict';
const https = require('https');
const http = require('http');
const zlib = require('zlib');
const HOST = { wiki: 'en.wikipedia.org', sec: 'data.sec.gov', proto: 'https' }; // tests point these at local doubles
const fs = require('fs');
const path = require('path');

const DAY = 86400000;
const UA = 'DELFAi X-ray (desktop app) support@delfitrading.com';

const getText = (host, p, headers) => new Promise((resolve, reject) => {
  const [hn, port] = host.split(':');
  const req = (HOST.proto === 'http' ? http : https).request({ host: hn, port: port || undefined, path: p, method: 'GET', headers: Object.assign({ 'User-Agent': UA, 'Accept-Encoding': 'gzip' }, headers || {}), timeout: 30000 }, (res) => {
    const ch = []; res.on('data', (c) => ch.push(c));
    res.on('end', () => { let raw = Buffer.concat(ch); if (/gzip/.test(res.headers['content-encoding'] || '')) { try { raw = zlib.gunzipSync(raw); } catch (e) { return reject(e); } } const b = raw.toString('utf8'); if (res.statusCode !== 200) { const e = new Error(host + ' HTTP ' + res.statusCode); e.status = res.statusCode; return reject(e); } resolve(b); });
  });
  req.on('timeout', () => req.destroy(new Error(host + ' timed out'))); req.on('error', reject); req.end();
});

// ---------- index members (Wikipedia's rendered tables) ----------
// Read every table whose header has a Symbol/Ticker column; works whatever templates the editors use.
const GICS = ['Information Technology', 'Health Care', 'Financials', 'Consumer Discretionary', 'Communication Services', 'Industrials', 'Consumer Staples', 'Energy', 'Utilities', 'Real Estate', 'Materials'];
const ICB = { Technology: 'Information Technology', Telecommunications: 'Communication Services', 'Basic Materials': 'Materials' };
const cellText = (h) => h.replace(/<sup[\s\S]*?<\/sup>/g, '').replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&#160;|&nbsp;/g, ' ').replace(/&#[0-9]+;/g, '').replace(/\s+/g, ' ').trim();
function tables(html) {
  const out = [];
  (html.match(/<table[\s\S]*?<\/table>/g) || []).forEach((t) => {
    const rows = (t.match(/<tr[\s\S]*?<\/tr>/g) || []).map((r) => (r.match(/<t[hd][^>]*>[\s\S]*?<\/t[hd]>/g) || []).map(cellText));
    const hi = rows.findIndex((r) => r.some((c) => /^(symbol|ticker)$/i.test(c)));
    if (hi < 0) return;
    const head = rows[hi].map((c) => c.toLowerCase());
    out.push({ head, rows: rows.slice(hi + 1).filter((r) => r.length >= head.length - 1) });
  });
  return out;
}
async function wikiTable(page) {
  const j = JSON.parse(await getText(HOST.wiki, '/w/api.php?action=parse&format=json&prop=text&formatversion=2&redirects=1&page=' + encodeURIComponent(page)));
  const html = (j.parse && j.parse.text) || '';
  // the biggest symbol table on the page is the members list
  const hasSec = (x) => x.head.some((h) => /sector|industry/.test(h)) ? 1 : 0;
  const t = tables(html).sort((x, y) => hasSec(y) - hasSec(x) || y.rows.length - x.rows.length)[0];
  if (!t) return [];
  const col = (re) => t.head.findIndex((h) => re.test(h));
  const iS = col(/^(symbol|ticker)$/), iSec = col(/gics sector|^industry$|icb industry|^sector$/), iC = col(/^cik$/);
  return t.rows.map((r) => {
    const sym = (r[iS] || '').toUpperCase().replace(/[^A-Z.]/g, '');
    let sec = iSec >= 0 ? r[iSec] || '' : ''; sec = GICS.find((g) => sec.includes(g)) || ICB[sec] || null;
    return { sym, sector: sec, cik: iC >= 0 && /^\d+$/.test(r[iC] || '') ? +r[iC] : null };
  }).filter((x) => /^[A-Z][A-Z.]{0,6}$/.test(x.sym));
}
async function members() {
  const out = { SPX: [], NDX: [], DJI: [], sector: {}, cik: {} };
  // the member lists live on their own "List of ..." pages; the index article is the fallback
  const take = async (key, pages, min) => {
    for (const page of pages) {
      let got = [];
      try { got = await wikiTable(page); } catch (e) { continue; }
      if (got.length < (HOST.wiki === 'en.wikipedia.org' ? min : 1)) continue;
      got.forEach((x) => { if (out[key].includes(x.sym)) return; out[key].push(x.sym); if (x.sector && (!out.sector[x.sym] || key === 'SPX')) out.sector[x.sym] = x.sector; if (x.cik) out.cik[x.sym] = x.cik; });
      return;
    }
  };
  await take('SPX', ['List of S&P 500 companies'], 400);
  await take('NDX', ['List of NASDAQ-100 companies', 'Nasdaq-100'], 90);
  await take('DJI', ['List of Dow Jones Industrial Average companies', 'Dow Jones Industrial Average'], 28);
  return out;
}

// ---------- SEC frames ----------
const FR = {
  rev: [['us-gaap', 'Revenues'], ['us-gaap', 'RevenueFromContractWithCustomerExcludingAssessedTax'], ['us-gaap', 'SalesRevenueNet']],
  ni: [['us-gaap', 'NetIncomeLoss']], op: [['us-gaap', 'OperatingIncomeLoss']], gp: [['us-gaap', 'GrossProfit']],
  rd: [['us-gaap', 'ResearchAndDevelopmentExpense']], da: [['us-gaap', 'DepreciationDepletionAndAmortization'], ['us-gaap', 'DepreciationAndAmortization']],
  ocf: [['us-gaap', 'NetCashProvidedByUsedInOperatingActivities']], icf: [['us-gaap', 'NetCashProvidedByUsedInInvestingActivities']], fcfin: [['us-gaap', 'NetCashProvidedByUsedInFinancingActivities']], capex: [['us-gaap', 'PaymentsToAcquirePropertyPlantAndEquipment']],
  eps: [['us-gaap', 'EarningsPerShareDiluted']], wsh: [['us-gaap', 'WeightedAverageNumberOfDilutedSharesOutstanding']], dps: [['us-gaap', 'CommonStockDividendsPerShareDeclared'], ['us-gaap', 'CommonStockDividendsPerShareCashPaid']]
};
const INST = {
  cash: [['us-gaap', 'CashAndCashEquivalentsAtCarryingValue']], assets: [['us-gaap', 'Assets']], liab: [['us-gaap', 'Liabilities']],
  equity: [['us-gaap', 'StockholdersEquity']], ltd: [['us-gaap', 'LongTermDebtNoncurrent'], ['us-gaap', 'LongTermDebt']], std: [['us-gaap', 'LongTermDebtCurrent'], ['us-gaap', 'DebtCurrent']],
  ca: [['us-gaap', 'AssetsCurrent']], cl: [['us-gaap', 'LiabilitiesCurrent']], shares: [['dei', 'EntityCommonStockSharesOutstanding']]
};

class Universe {
  constructor(opts) {
    if (opts.wikiHost) HOST.wiki = opts.wikiHost; if (opts.secHost) HOST.sec = opts.secHost; if (opts.protocol) HOST.proto = opts.protocol;
    this.cal = opts.cal || null;
    this.getDm = opts.getDm || (() => opts.dm); this.sec = opts.sec; this.log = opts.log || (() => {});
    this.dir = opts.cacheDir; if (this.dir) fs.mkdirSync(this.dir, { recursive: true });
    this.mem = null; this.fund = null; this.tech = this.read('tech.json') || {}; this.quotes = {}; this.qAt = 0;
    this.busy = { mem: false, fund: false, tech: false }; this.techQueue = []; this.err = {}; this.alias = {};
  }
  get dm() { return this.getDm(); }
  read(n, maxAge) { try { const f = path.join(this.dir, n); if (maxAge && Date.now() - fs.statSync(f).mtimeMs > maxAge) return null; return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return null; } }
  write(n, o) { try { fs.writeFileSync(path.join(this.dir, n), JSON.stringify(o)); } catch (e) { /* optional */ } }

  async loadMembers() {
    if (this.mem) return this.mem;
    const c = this.read('members.json', 7 * DAY); if (c && c.SPX && c.SPX.length > 400) return (this.mem = c);
    if (this.busy.mem) return null; this.busy.mem = true;
    try { const m = await members(); if (m.SPX.length > 400) this.write('members.json', m); this.mem = m.SPX.length ? m : (this.read('members.json') || m); }
    catch (e) { this.err.mem = e.message; this.mem = this.read('members.json'); }
    finally { this.busy.mem = false; }
    return this.mem;
  }

  // every fundamental for every filer, keyed by CIK
  async loadFund() {
    if (this.fund && Date.now() - this.fund.at < DAY) return this.fund;
    const c = this.read('fund.json', DAY); if (c) return (this.fund = c);
    if (this.busy.fund) return this.fund; this.busy.fund = true;
    try {
      const y = new Date().getUTCFullYear();
      // one frame = one concept, one period, every filer. Settled periods are kept on disk for good; recent ones for a day.
      fs.mkdirSync(path.join(this.dir, 'frames'), { recursive: true });
      const settled = (period) => { const m = /^CY(\d{4})(?:Q(\d))?I?$/.exec(period); if (!m) return false; const end = Date.UTC(+m[1], m[2] ? 3 * +m[2] : 12, 0); return Date.now() - end > 450 * DAY; };
      const frame = async (tax, tag, unit, period) => {
        const name = path.join('frames', [tax, tag, unit, period].join('_') + '.json');
        const c = this.read(name, settled(period) ? 0 : DAY); if (c) return c;
        try {
          const j = JSON.parse(await getText(HOST.sec, '/api/xbrl/frames/' + tax + '/' + tag + '/' + unit + '/' + period + '.json'));
          const m = {}; (j.data || []).forEach((d) => { m[d.cik] = d.val; });
          this.write(name, m); return m;
        } catch (e) { if (e.status === 404) { this.write(name, {}); return {}; } return this.read(name) || {}; }
      };
      const pick = async (list, unit, period) => { const out = {}; for (const [tax, tag] of list) { const m = await frame(tax, tag, unit, period); Object.keys(m).forEach((k) => { if (out[k] === undefined) out[k] = m[k]; }); } return out; };
      // each company's latest full fiscal year (SEC files a fiscal year under the calendar year it mostly falls in, so a
      // September or January year-end can already sit in this calendar year), and the year before it for growth
      const Y = y - 1;
      const KEYS = ['rev', 'ni', 'op', 'gp', 'rd', 'da', 'ocf', 'capex', 'icf', 'fcfin', 'eps', 'wsh'];
      const ann = {};
      for (const k of KEYS) { ann[k] = []; for (let i = 0; i < 3; i++) ann[k].push(await pick(FR[k], k === 'eps' ? 'USD-per-shares' : k === 'wsh' ? 'shares' : 'USD', 'CY' + (y - i))); }
      const F = { year: Y, cur: {}, prev: {}, inst: {}, divYears: {}, fy: {} };
      KEYS.forEach((k) => { F.cur[k] = {}; F.prev[k] = {}; });
      const ciks = new Set(); ['rev', 'ni'].forEach((k) => ann[k].forEach((m) => Object.keys(m).forEach((c2) => ciks.add(c2))));
      ciks.forEach((c2) => {
        const i = ann.rev[0][c2] !== undefined || ann.ni[0][c2] !== undefined ? 0 : 1;
        F.fy[c2] = y - i;
        KEYS.forEach((k) => { if (ann[k][i][c2] !== undefined) F.cur[k][c2] = ann[k][i][c2]; if (ann[k][i + 1][c2] !== undefined) F.prev[k][c2] = ann[k][i + 1][c2]; });
      });
      const rev = F.cur.rev;
      // balance sheet: newest quarter-end that most filers have reported
      const qs = []; for (let yy = y; yy >= y - 2; yy--) for (let q = 4; q >= 1; q--) qs.push('CY' + yy + 'Q' + q + 'I');
      // newest quarter-end each filer has reported, plus the same line four quarters earlier (growth)
      F.instPrev = {};
      for (const k of Object.keys(INST)) {
        const unit = k === 'shares' ? 'shares' : 'USD'; const deep = ['ltd', 'std', 'assets'].includes(k);
        const per = []; for (let i = 0; i < (deep ? 10 : 6); i++) per.push(await pick(INST[k], unit, qs[i]));
        const out = {}, prev = {};
        per.forEach((m, i) => Object.keys(m).forEach((c2) => { if (out[c2] !== undefined || i > 5) return; out[c2] = m[c2]; if (deep && per[i + 4] && per[i + 4][c2] !== undefined) prev[c2] = per[i + 4][c2]; }));
        F.inst[k] = out; if (deep) F.instPrev[k] = prev;
      }
      // dividends: per-share each year, to count years paid / years raised in a row
      const dps = []; for (let yy = y; yy >= 2009; yy--) dps.push(await pick(FR.dps, 'USD-per-shares', 'CY' + yy));
      const dciks = new Set(); dps.forEach((m) => Object.keys(m).forEach((k) => dciks.add(k)));
      dciks.forEach((k) => {
        const s0 = F.fy[k] === y || (F.fy[k] === undefined && dps[0][k] > 0) ? 0 : 1;   // start at the company's latest fiscal year
        let paid = 0, grow = 0, growing = true;
        for (let i = s0; i < dps.length; i++) { const v = dps[i][k]; if (!(v > 0)) break; paid++; const prev = dps[i + 1] && dps[i + 1][k]; if (growing && prev > 0 && v > prev) grow++; else growing = false; }
        F.divYears[k] = [paid, grow, dps[s0][k] || null, (dps[s0 + 1] && dps[s0 + 1][k]) || null];
      });
      F.at = Date.now();
      if (Object.keys(rev).length) { this.write('fund.json', F); this.fund = F; } else throw new Error('SEC returned no data');
    } catch (e) { this.err.fund = e.message; this.log('universe fundamentals: ' + e.message); }
    finally { this.busy.fund = false; }
    return this.fund;
  }

  // daily-candle technicals for one ticker (same formulas TradingView uses: Wilder smoothing for RSI/ATR/ADX)
  static techOf(bars) {
    const b = (bars || []).filter((x) => Number.isFinite(x.c) && Number.isFinite(x.h) && Number.isFinite(x.l)); const n = b.length; if (n < 30) return null;
    const c = b.map((x) => x.c), h = b.map((x) => x.h), lo = b.map((x) => x.l), L = c[n - 1];
    const emaS = (arr, len) => { const k = 2 / (len + 1); const out = [arr[0]]; for (let i = 1; i < arr.length; i++) out.push(arr[i] * k + out[i - 1] * (1 - k)); return out; };
    const rma = (arr, len) => { if (arr.length < len) return []; let v = arr.slice(0, len).reduce((a2, x) => a2 + x, 0) / len; const out = new Array(len - 1).fill(null); out.push(v); for (let i = len; i < arr.length; i++) { v = (v * (len - 1) + arr[i]) / len; out.push(v); } return out; };
    const sma = (len, at) => { const end = at === undefined ? n : at + 1; if (end < len) return null; let s2 = 0; for (let i = end - len; i < end; i++) s2 += c[i]; return s2 / len; };
    const sd = (len, at) => { const m = sma(len, at); if (m === null) return null; const end = at === undefined ? n : at + 1; let s2 = 0; for (let i = end - len; i < end; i++) s2 += (c[i] - m) * (c[i] - m); return Math.sqrt(s2 / len); };
    const up = [], dn = [], tr = [], pdm = [], mdm = [];
    for (let i = 1; i < n; i++) {
      const d = c[i] - c[i - 1]; up.push(Math.max(d, 0)); dn.push(Math.max(-d, 0));
      tr.push(Math.max(h[i] - lo[i], Math.abs(h[i] - c[i - 1]), Math.abs(lo[i] - c[i - 1])));
      const u = h[i] - h[i - 1], m = lo[i - 1] - lo[i]; pdm.push(u > m && u > 0 ? u : 0); mdm.push(m > u && m > 0 ? m : 0);
    }
    const ru = rma(up, 14), rd = rma(dn, 14); const RU = ru[ru.length - 1], RD = rd[rd.length - 1];
    const rsi = RD === 0 ? 100 : 100 - 100 / (1 + RU / RD);
    const atr = rma(tr, 14); const ATR = atr[atr.length - 1];
    const sp = rma(pdm, 14), sm = rma(mdm, 14);
    const dx = atr.map((a2, i) => (a2 && sp[i] !== null ? (() => { const P = 100 * sp[i] / a2, M = 100 * sm[i] / a2; return P + M ? 100 * Math.abs(P - M) / (P + M) : 0; })() : null)).filter((x) => x !== null);
    const adxA = rma(dx, 14); const adx = adxA.length ? adxA[adxA.length - 1] : null;
    const e12 = emaS(c, 12), e26 = emaS(c, 26); const macdL = c.map((_, i) => e12[i] - e26[i]); const sig = emaS(macdL, 9);
    const hh = Math.max(...h.slice(n - 14)), ll = Math.min(...lo.slice(n - 14)); const stochK = hh > ll ? (L - ll) / (hh - ll) * 100 : null;
    const tp = b.map((x) => (x.h + x.l + x.c) / 3); const tp20 = tp.slice(n - 20); const tpm = tp20.reduce((a2, x) => a2 + x, 0) / 20; const md = tp20.reduce((a2, x) => a2 + Math.abs(x - tpm), 0) / 20;
    const cci = md ? (tp[n - 1] - tpm) / (0.015 * md) : null;
    const bb = (at) => { const m = sma(20, at), s2 = sd(20, at); return m === null ? null : [m + 2 * s2, m - 2 * s2]; };
    const b0 = bb(), b1 = bb(n - 2);
    const back = (days) => { const t = b[n - 1].t - days * DAY; for (let i = n - 1; i >= 0; i--) if (b[i].t <= t) return c[i]; return null; };
    const pct = (x) => (x ? (L / x - 1) * 100 : null);
    const ytd = (() => { const y0 = Date.UTC(new Date(b[n - 1].t).getUTCFullYear(), 0, 1); for (let i = n - 1; i >= 0; i--) if (b[i].t < y0) return c[i]; return null; })();
    const yr = b.filter((x) => x.t >= b[n - 1].t - 365 * DAY);
    const rets = []; for (let i = n - 21; i < n; i++) rets.push(c[i] / c[i - 1] - 1); const mr = rets.reduce((a2, x) => a2 + x, 0) / rets.length;
    const vsum = (k) => b.slice(n - k).reduce((a2, x) => a2 + (x.v || 0), 0);
    const avgV = b.slice(Math.max(0, n - 31), n - 1).reduce((a2, x) => a2 + (x.v || 0), 0) / Math.min(30, n - 1);
    const adr = b.slice(n - 14).reduce((a2, x) => a2 + (x.h - x.l) / x.l * 100, 0) / 14;
    return {
      ema50: emaS(c, 50)[n - 1], ema20: emaS(c, 20)[n - 1], sma50: sma(50), sma200: sma(200), rsi, bbU: b0 && b0[0], bbL: b0 && b0[1],
      bbCrossU: !!(b0 && b1 && c[n - 1] > b0[0] && c[n - 2] <= b1[0]), bbCrossL: !!(b0 && b1 && c[n - 1] < b0[1] && c[n - 2] >= b1[1]),
      atrPct: ATR / L * 100, adx, macd: macdL[n - 1], macdSig: sig[n - 1], stochK, cci, adrPct: adr,
      hi52: Math.max(...yr.map((x) => x.h)), lo52: Math.min(...yr.map((x) => x.l)),
      p1w: pct(back(7)), p1m: pct(back(30)), p3m: pct(back(91)), p6m: pct(back(182)), pytd: pct(ytd), p1y: pct(back(365)), p5y: b[0].t <= b[n - 1].t - 5 * 365 * DAY + 7 * DAY ? pct(back(5 * 365)) : null,
      vol1m: Math.sqrt(rets.reduce((a2, x) => a2 + (x - mr) * (x - mr), 0) / rets.length) * 100, avgVol: avgV, volW: vsum(5), volM: vsum(21),
      // the last full session (for 1W/1M turnover); today's live volume comes from the quote
      at: Date.now()
    };
  }

  // fill technicals in the background, a few tickers at a time (the broker allows ~2 calls a second)
  queueTech(syms) {
    const stale = syms.filter((s) => { const t = this.tech[s]; return !t || Date.now() - t.at > 12 * 3600000; });
    stale.forEach((s) => { if (!this.techQueue.includes(s)) this.techQueue.push(s); });
    if (this.busy.tech || !this.techQueue.length || !this.dm) return;
    this.busy.tech = true;
    (async () => {
      let n = 0;
      while (this.techQueue.length) {
        const s = this.techQueue.shift();
        try { const r = await this.dm.bars(this.alias[s] || s, '1D'); const t = Universe.techOf(r && r.bars); if (t) this.tech[s] = t; else this.tech[s] = { at: Date.now(), none: true }; } catch (e) { this.tech[s] = { at: Date.now() - 11 * 3600000, none: true }; }
        if (++n % 25 === 0) this.write('tech.json', this.tech);
        await new Promise((r) => setTimeout(r, 650));
      }
      this.write('tech.json', this.tech); this.busy.tech = false;
    })();
  }

  async refreshQuotes(syms) {
    if (!this.dm || this.busy.q || Date.now() - this.qAt < 30000) return;
    this.busy.q = true; this.qAt = Date.now();
    try {
      // class shares (BRK.B, BF.B): brokers spell them BRK.B, BRK/B or BRK B, so ask for each and keep what answers
      const ask = []; const back = {};
      syms.forEach((s) => { if (/^[A-Z]{1,5}$/.test(s)) { ask.push(s); back[s] = s; } else if (/^[A-Z]{1,5}\.[A-Z]$/.test(s)) [s, s.replace('.', '/'), s.replace('.', ' ')].forEach((v) => { ask.push(v); back[v] = s; }); });
      const q = Object.assign({}, await this.dm.quotes(ask.filter((v) => back[v] === v)));
      // the odd spellings go one at a time so a broker that rejects one can't sink the main batch
      for (const v of ask.filter((x) => back[x] !== x)) { if (this.alias[back[v]] && this.alias[back[v]] !== v) continue; try { Object.assign(q, await this.dm.quotes([v])); } catch (e) { /* not this spelling */ } }
      Object.keys(q || {}).forEach((v) => { const s = back[v] || v; this.quotes[s] = Object.assign(this.quotes[s] || {}, q[v]); if (v !== s) this.alias[s] = v; });
      // Schwab sends a fundamental block with each quote: market cap, P/E, beta, dividend yield
      (this.dm.list || [this.dm]).forEach((d) => { const F = d && d.fund; if (!F) return; Object.keys(F).forEach((key) => { const s = Object.keys(this.alias).find((k) => this.alias[k] === key) || key; const f = F[key].f || {}; const o = this.quotes[s]; if (!o) return; const v = (x) => (Number.isFinite(+x) && +x !== 0 ? +x : null); o.marketCap = v(f.marketCap) ? f.marketCap * (f.marketCap < 1e7 ? 1e6 : 1) : o.marketCap; o.pe = v(f.peRatio) || o.pe; o.beta = v(f.beta) || o.beta; o.divYield = f.divYield != null ? +f.divYield : o.divYield; }); });
    } catch (e) { this.err.quotes = e.message; }
    finally { this.busy.q = false; }
  }

  // earnings dates from the Nasdaq calendar (one request per weekday, cached by the calendar module)
  async loadEarnings() {
    if (!this.cal || this.busy.ern || (this.ern && Date.now() - this.ern.at < 6 * 3600000)) return;
    this.busy.ern = true;
    try {
      const next = {}, last = {}; const now = Date.now();
      const iso = (t) => new Date(t - 5 * 3600000).toISOString().slice(0, 10);
      for (let i = -35; i <= 35; i++) {
        const t = now + i * DAY; const dow = new Date(t - 5 * 3600000).getUTCDay(); if (dow === 0 || dow === 6) continue;
        const d = iso(t); let rows = [];
        try { rows = await this.cal.earningsDay(d); } catch (e) { continue; }
        rows.forEach((r) => { if (!r.sym) return; if (i >= 0) { if (!next[r.sym]) next[r.sym] = [d, r.when]; } else last[r.sym] = [d, r.when]; });
      }
      this.ern = { next, last, at: Date.now() };
    } finally { this.busy.ern = false; }
  }

  // the rows the pages show
  async rows(extraSyms) {
    const M = await this.loadMembers();
    const F = this.fund || this.read('fund.json');
    if (!this.fund || Date.now() - (this.fund.at || 0) > DAY) this.loadFund();
    this.loadEarnings();
    const set = new Set([...(M ? M.SPX.concat(M.NDX, M.DJI) : []), ...(extraSyms || [])].filter((s) => /^[A-Z][A-Z.]{0,6}$/.test(s)));
    const syms = [...set];
    if (!Object.keys(this.quotes).length) await this.refreshQuotes(syms); else this.refreshQuotes(syms);   // first look waits for prices
    if (this.dm) this.queueTech(syms);
    const map = await this.sec.tickerMap().catch(() => ({}));
    const n = (v) => (Number.isFinite(v) ? v : null);
    const E = this.ern || { next: {}, last: {} };
    const rows = syms.map((s) => {
      const alt = s.replace('.', '-');
      const q = this.quotes[s] || {}; const t = this.tech[s] && !this.tech[s].none ? this.tech[s] : {};
      const ci = (map[s] && map[s].cik) || (M && M.cik && M.cik[s]) || (map[alt] && map[alt].cik); const k = ci != null ? String(ci) : null;
      const g = (o, key) => (F && k && o && o[key] ? n(o[key][k]) : null);
      const C = F && F.cur, P = F && F.prev;
      const rev = g(C, 'rev'), revP = g(P, 'rev'), ni = g(C, 'ni'), niP = g(P, 'ni'), op = g(C, 'op'), opP = g(P, 'op'), gp = g(C, 'gp'), gpP = g(P, 'gp');
      const rd = g(C, 'rd'), da = g(C, 'da'), daP = g(P, 'da'), ocf = g(C, 'ocf'), ocfP = g(P, 'ocf'), capex = g(C, 'capex'), capexP = g(P, 'capex');
      const icf = g(C, 'icf'), fin = g(C, 'fcfin'), eps = g(C, 'eps'), epsP = g(P, 'eps');
      const I = (key) => g(F && F.inst, key), IP = (key) => g(F && F.instPrev, key);
      const cash = I('cash'), equity = I('equity'), ltd = I('ltd'), std = I('std'), assets = I('assets'), ca = I('ca'), cl = I('cl'), liab = I('liab');
      let shares = I('shares') || g(C, 'wsh');
      const sumD = (a2, b2) => (a2 !== null || b2 !== null ? (a2 || 0) + (b2 || 0) : null);
      const debt = sumD(ltd, std), debtP = sumD(IP('ltd'), IP('std')), assetsP = IP('assets');
      const px = n(q.last); const chg = n(q.chgPct);
      // share classes priced differently from what the filing counts (BRK.B vs Class A): a P/E under 1.5 gives it away,
      // so per-share math from the filing is dropped rather than shown wrong
      const classOff = px && eps > 0 && px / eps < 1.5;
      if (classOff) shares = null;
      const mcap = n(q.marketCap) || (px && shares ? px * shares : null);
      const sh = shares || (mcap && px ? mcap / px : null);
      const fcf = ocf !== null && capex !== null ? ocf - capex : null, fcfP = ocfP !== null && capexP !== null ? ocfP - capexP : null;
      const ebitda = op !== null ? op + (da || 0) : null, ebitdaP = opP !== null ? opP + (daP || 0) : null;
      const gr = (a2, b2) => (a2 !== null && b2 !== null && b2 !== 0 ? (a2 - b2) / Math.abs(b2) * 100 : null);
      const dv = F && k && F.divYears && F.divYears[k] ? F.divYears[k] : null;
      const pe0 = n(q.pe) || (px && eps > 0 && !classOff ? px / eps : null); const pe = pe0 > 0 ? pe0 : null;
      const epsG = gr(eps, epsP);
      const ev = mcap !== null && debt !== null ? mcap + debt - (cash || 0) : null;
      const per = (v) => (v !== null && sh ? v / sh : null);
      const en = E.next[s] || E.next[alt], el = E.last[s] || E.last[alt];
      const hi = n(q.high), lw = n(q.low);
      return {
        sym: s, name: (q.name || (map[s] && map[s].title) || (map[alt] && map[alt].title) || s), sector: (M && M.sector[s]) || null,
        idx: M ? ['SPX', 'NDX', 'DJI'].filter((x) => M[x].includes(s)) : [],
        px, chg, chgAbs: n(q.chg), vol: n(q.volume), open: n(q.open), high: hi, low: lw, prevClose: n(q.prevClose),
        gap: n(q.open) && n(q.prevClose) ? (q.open / q.prevClose - 1) * 100 : null, chgOpen: px && n(q.open) ? (px / q.open - 1) * 100 : null,
        volat: hi && lw ? (hi - lw) / lw * 100 : null, turnover: px && n(q.volume) ? px * q.volume : null,
        relVol: t.avgVol && n(q.volume) ? q.volume / t.avgVol : null, avgVol: n(t.avgVol), volW: n(t.volW), volM: n(t.volM),
        mcap, shares: sh, pe, eps, fy: F && k && F.fy ? F.fy[k] || null : null, epsG, peg: pe && epsG > 0 ? pe / epsG : null, ps: mcap && rev > 0 ? mcap / rev : null, pb: mcap && equity > 0 ? mcap / equity : null,
        pcf: mcap && ocf > 0 ? mcap / ocf : null, pfcf: mcap && fcf > 0 ? mcap / fcf : null, ev, evEbitda: ev !== null && ebitda > 0 ? ev / ebitda : null, evRev: ev !== null && rev > 0 ? ev / rev : null,
        ey: pe ? 100 / pe : null,
        beta: n(q.beta), div: n(q.divYield) || (dv && dv[2] && px && !classOff ? dv[2] / px * 100 : null), dps: dv ? dv[2] : null, divYrs: dv ? dv[0] : null, divGrowYrs: dv ? dv[1] : null,
        payout: dv && dv[2] && eps > 0 && !classOff ? dv[2] / eps * 100 : null, dpsG: dv ? gr(dv[2], dv[3]) : null,
        rev, revG: gr(rev, revP), ni, niG: gr(ni, niP), gp, gpG: gr(gp, gpP), op, ebitda, ebitdaG: gr(ebitda, ebitdaP), rd, fcf, fcfG: gr(fcf, fcfP), capexG: gr(capex, capexP),
        gm: rev && gp !== null ? gp / rev * 100 : null, om: rev && op !== null ? op / rev * 100 : null, nm: rev && ni !== null ? ni / rev * 100 : null,
        fcfM: rev && fcf !== null ? fcf / rev * 100 : null, rdr: rev && rd !== null ? rd / rev * 100 : null,
        roe: ni !== null && equity > 0 ? ni / equity * 100 : null, roa: ni !== null && assets > 0 ? ni / assets * 100 : null,
        roic: ni !== null && (equity || 0) + (debt || 0) > 0 ? ni / ((equity || 0) + (debt || 0)) * 100 : null,
        cash, debt, debtG: gr(debt, debtP), netDebt: debt !== null && cash !== null ? debt - cash : null, equity, assets, assetsG: gr(assets, assetsP), liab,
        de: debt !== null && equity > 0 ? debt / equity : null, cr: ca && cl ? ca / cl : null, ocf, icf, fin, capex,
        revSh: per(rev), fcfSh: per(fcf), bookSh: per(equity), cashSh: per(cash), debtSh: per(debt),
        ema20: n(t.ema20), ema50: n(t.ema50), sma50: n(t.sma50), sma200: n(t.sma200), rsi: n(t.rsi), bbU: n(t.bbU), bbL: n(t.bbL), bbCrossU: !!t.bbCrossU, bbCrossL: !!t.bbCrossL,
        atrPct: n(t.atrPct), adx: n(t.adx), macd: n(t.macd), macdSig: n(t.macdSig), stochK: n(t.stochK), cci: n(t.cci), adrPct: n(t.adrPct),
        hi52: n(q.hi52) || n(t.hi52), lo52: n(q.lo52) || n(t.lo52), p1w: n(t.p1w), p1m: n(t.p1m), p3m: n(t.p3m), p6m: n(t.p6m), pytd: n(t.pytd), p1y: n(t.p1y), vol1m: n(t.vol1m),
        ern: en ? en[0] : null, ernWhen: en ? en[1] : null, rern: el ? el[0] : null
      };
    });
    const techDone = syms.filter((s) => this.tech[s]).length;
    return { rows, status: { members: !!M, fundYear: F ? F.year : null, fundLoading: this.busy.fund, techDone, total: syms.length, live: !!this.dm, earnings: !!this.ern } };
  }
}

module.exports = { Universe };
