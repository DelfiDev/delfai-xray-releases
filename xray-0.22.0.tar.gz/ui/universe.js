// Shared data for the Heat map and Stock screener: /api/universe (index members + your watchlists), refreshed every
// 30 seconds while one of those pages is open. Real values only: anything a source doesn't have stays null.
(() => {
  'use strict';
  const listeners = new Set();
  let data = null, busy = false, at = 0;

  const lists = () => {
    try { const s = JSON.parse(localStorage.getItem('xray-state-v1') || 'null'); const L = s && Array.isArray(s.wlists) ? s.wlists : []; return L.filter((l) => l && Array.isArray(l.syms)).map((l) => ({ id: String(l.id), name: String(l.name || 'Watchlist'), syms: l.syms.map((x) => String(x).toUpperCase()).filter((x) => /^[A-Z][A-Z.]{0,6}$/.test(x)) })); } catch (e) { return []; }
  };

  // numbers worked out from the row itself (no extra source)
  const derive = (r) => {
    r.offHi = r.px && r.hi52 ? (r.hi52 - r.px) / r.hi52 * 100 : null;
    r.offLo = r.px && r.lo52 ? (r.px - r.lo52) / r.lo52 * 100 : null;
    r.vsEma50 = r.px && r.ema50 ? (r.px / r.ema50 - 1) * 100 : null;
    r.vsSma200 = r.px && r.sma200 ? (r.px / r.sma200 - 1) * 100 : null;
    r.bbPos = r.px && r.bbU && r.bbL && r.bbU > r.bbL ? (r.px - r.bbL) / (r.bbU - r.bbL) * 100 : null;
    r.turnW = r.volW && r.px ? r.volW * r.px : null;
    r.turnM = r.volM && r.px ? r.volM * r.px : null;
    return r;
  };

  const pull = async () => {
    if (busy) return; busy = true;
    try {
      const extra = [...new Set(lists().flatMap((l) => l.syms))].slice(0, 300).join(',');
      const res = await fetch('/api/universe' + (extra ? '?extra=' + encodeURIComponent(extra) : ''));
      if (res.ok) {
        const j = await res.json();
        if (j && Array.isArray(j.rows)) { j.rows.forEach(derive); data = j; at = Date.now(); listeners.forEach((f) => { try { f(data); } catch (e) { console.error(e); } }); }
      }
    } catch (e) { /* next tick tries again */ }
    finally { busy = false; }
  };

  // quicker refreshes while technicals and fundamentals are still filling in
  setInterval(() => {
    if (!listeners.size) return;
    const filling = !data || (data.status && (data.status.fundLoading || data.status.techDone < data.status.total)) || !data.rows.some((r) => r.px);
    if (Date.now() - at > (filling ? 8000 : 30000)) pull();
  }, 1000);

  const open = (sym) => {
    const c = window.__app && window.__app.c; if (!c) return;
    c.setState({ chartSym: sym, page: 'dash', q: '', start: null, hi: null });
  };
  const go = (page) => { const c = window.__app && window.__app.c; if (c) c.setState({ page, q: null }); };

  const fmt = {
    money: (v) => { if (!Number.isFinite(v)) return '—'; const a = Math.abs(v), s = v < 0 ? '−' : ''; return s + (a >= 1e12 ? (a / 1e12).toFixed(2) + 'T' : a >= 1e9 ? (a / 1e9).toFixed(2) + 'B' : a >= 1e6 ? (a / 1e6).toFixed(2) + 'M' : a >= 1e3 ? (a / 1e3).toFixed(1) + 'K' : a.toFixed(0)); },
    num: (v, d) => (Number.isFinite(v) ? (v < 0 ? '−' : '') + Math.abs(v).toFixed(d === undefined ? 2 : d) : '—'),
    pct: (v, d) => (Number.isFinite(v) ? (v > 0 ? '+' : v < 0 ? '−' : '') + Math.abs(v).toFixed(d === undefined ? 2 : d) + '%' : '—'),
    pctPlain: (v, d) => (Number.isFinite(v) ? (v < 0 ? '−' : '') + Math.abs(v).toFixed(d === undefined ? 2 : d) + '%' : '—'),
    px: (v) => (Number.isFinite(v) ? v.toFixed(v >= 1 ? 2 : 4) : '—'),
    vol: (v) => (Number.isFinite(v) ? fmt.money(v) : '—'),
    x: (v) => (Number.isFinite(v) ? v.toFixed(2) + '×' : '—'),
    date: (s) => { if (!s) return '—'; const d = new Date(s + 'T12:00:00Z'); return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', timeZone: 'UTC' }); }
  };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

  // copy a picture of an element (desktop app), same route as the chart camera button
  const snapEl = async (el, toast) => {
    if (!/Electron/i.test(navigator.userAgent) || !el) return toast && toast('Copy image works in the desktop app');
    const r = el.getBoundingClientRect(); const x = Math.max(0, r.left), y = Math.max(0, r.top);
    try {
      const res = await fetch('/api/snap', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ x, y, w: Math.min(r.right, innerWidth) - x, h: Math.min(r.bottom, innerHeight) - y }) });
      const j = await res.json().catch(() => ({}));
      if (toast) toast(res.ok && !j.error ? 'Image copied. Paste it anywhere.' : 'Could not copy the image');
    } catch (e) { if (toast) toast('Could not copy the image'); }
  };
  let toastEl = null, toastT = 0;
  const toast = (txt) => {
    if (!toastEl) { toastEl = document.createElement('div'); toastEl.setAttribute('role', 'status'); toastEl.style.cssText = 'position:fixed;left:50%;bottom:28px;transform:translateX(-50%);z-index:99999;background:#0B1017;color:#E8EEF2;border:1px solid #2C4A63;border-radius:999px;padding:9px 16px;font:500 13px "IBM Plex Sans",sans-serif;box-shadow:0 8px 28px rgba(0,0,0,.45);pointer-events:none;transition:opacity .2s'; document.body.appendChild(toastEl); }
    toastEl.textContent = txt; toastEl.style.opacity = '1'; clearTimeout(toastT); toastT = setTimeout(() => { toastEl.style.opacity = '0'; }, 2400);
  };
  const store = (k, v) => { try { if (v === undefined) return JSON.parse(localStorage.getItem(k) || 'null'); localStorage.setItem(k, JSON.stringify(v)); } catch (e) { return null; } return v; };

  window.XRU = {
    sub(f) { listeners.add(f); if (data) f(data); else pull(); return () => listeners.delete(f); },
    get data() { return data; }, refresh: pull, lists, open, go, fmt, esc, snapEl, toast, store,
    SECTORS: ['Information Technology', 'Health Care', 'Financials', 'Consumer Discretionary', 'Communication Services', 'Industrials', 'Consumer Staples', 'Energy', 'Utilities', 'Real Estate', 'Materials'],
    INDEXES: [['SPX', 'S&P 500'], ['NDX', 'Nasdaq-100'], ['DJI', 'Dow Jones Industrial']]
  };
})();
