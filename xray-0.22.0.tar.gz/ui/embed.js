// One widget of the app, alone in a frame, for the My Layout tab. The frame's address says which page the widget
// lives on and how to find it; everything else on that page is hidden and the widget fills the frame.
// Its ticker can be set by the layout (linked groups), and when you change the ticker inside the widget the
// layout hears about it so the rest of the group follows.
(function () {
  'use strict';
  const m = /[#&]emb=([^&]+)/.exec(location.hash);
  if (!m) return;
  let cfg; try { cfg = JSON.parse(decodeURIComponent(m[1])); } catch (e) { return; }
  window.__xrEmb = cfg;
  document.documentElement.classList.add('xr-embed');
  const GAMMA_SYMS = ['SPX', 'SPY', 'QQQ', 'NVDA', 'TSLA'];
  const app = () => window.__app && window.__app.c;
  const post = (o) => { try { window.parent.postMessage(Object.assign({ xrEmb: cfg.id }, o), location.origin); } catch (e) { /* layout gone */ } };
  const symPatch = (s) => Object.assign({ chartSym: s, q: '', start: null, hi: null }, GAMMA_SYMS.includes(s) ? { sym: s } : {});
  let lastSym = null, ready = false, t0 = Date.now(), missingSent = '';
  let pending = cfg.sym || null;   // the ticker the layout wants, applied once the app is up

  const loop = () => {
    const c = app(); if (!c || !c.state) return;
    const st = c.state;
    if (pending) { const s = pending; pending = null; lastSym = s; if (st.chartSym !== s) { c.setState(symPatch(s)); return; } }
    // ticker changed from inside the widget (picked a mover, searched, clicked a heat map tile): tell the layout
    if (st.chartSym && st.chartSym !== lastSym) { if (lastSym !== null) post({ type: 'sym', sym: st.chartSym }); lastSym = st.chartSym; }
    // stay on this widget's page (clicking something that opens another page just changes the ticker)
    if (st.page !== cfg.page || (cfg.mode && st.wlMode !== cfg.mode)) { const p = { page: cfg.page }; if (cfg.mode) p.wlMode = cfg.mode; c.setState(p); return; }
    const el = document.querySelector(cfg.sel);
    if (!el) {
      const locked = !!(window.XRLock && window.XRLock(cfg.page)), live = !!(window.XR && window.XR.live);
      const why = locked ? 'locked' : !live && Date.now() - t0 > 4000 ? 'offline' : 'loading';
      if (Date.now() - t0 > (why === 'loading' ? 9000 : 2500) && missingSent !== why) { missingSent = why; post({ type: 'missing', why }); }
      return;
    }
    if (missingSent) { missingSent = ''; post({ type: 'found' }); }
    document.querySelectorAll('[data-xl-emb]').forEach((x) => { if (x !== el) x.removeAttribute('data-xl-emb'); });
    if (!el.hasAttribute('data-xl-emb')) el.setAttribute('data-xl-emb', '');
    // hide everything beside the widget, level by level up to the app root
    const root = document.getElementById('app');
    let n = el;
    while (n && n !== root && n.parentElement) {
      if (n.hasAttribute('data-xl-embhide')) n.removeAttribute('data-xl-embhide');
      const par = n.parentElement;
      Array.from(par.children).forEach((s) => { if (s !== n && s.tagName !== 'TEMPLATE' && s.tagName !== 'SCRIPT' && !s.hasAttribute('data-xl-embhide')) s.setAttribute('data-xl-embhide', ''); });
      if (par === root) break;
      n = par;
    }
    if (!ready) { ready = true; post({ type: 'ready' }); }
  };
  setInterval(loop, 250);

  window.addEventListener('message', (e) => {
    if (e.origin !== location.origin || !e.data || e.data.xrEmbSet !== cfg.id) return;
    const s = String(e.data.sym || '').toUpperCase();
    if (!/^\^?[A-Z][A-Z.]{0,6}$/.test(s)) return;
    const c = app();
    if (!c || !c.state) { pending = s; return; }
    lastSym = s;
    if (c.state.chartSym !== s) c.setState(symPatch(s));
  });
})();
