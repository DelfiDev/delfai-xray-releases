// No broker connected: every view that needs live market data shows "Market data not connected" with a
// Connect account button, instead of any stand-in numbers. Free-source views (news, economy, catalysts) stay open.
(() => {
  const PAGES = ['watch', 'gamma', 'dealer', 'pulse', 'screen', 'flow', 'heat', 'stocks'];
  const CARDS = ['Price chart', 'Market movers', 'Sentiment analysis', 'Bullish or bearish sentiment', 'Options chain', 'Premium chart', 'My options', 'Opening gamma brief', 'Expected move', 'Top flow tickers', 'Live flow'];
  const go = () => { if (window.XRGo) window.XRGo('/setup.html'); else location.href = '/setup.html'; };
  let layer = null, boxes = [];
  const panel = (big) => {
    const d = document.createElement('div');
    d.className = 'xr-gate'; d.setAttribute('role', 'region'); d.setAttribute('aria-label', 'Market data not connected');
    d.innerHTML = '<div class="xr-gate-in"><svg width="' + (big ? 30 : 22) + '" height="' + (big ? 30 : 22) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M9 7H6a5 5 0 0 0 0 10h3M15 7h3a5 5 0 0 1 0 10h-3M8 12h8"/></svg><span class="xr-gate-t">Market data not connected</span><button type="button" class="xr-gate-b">Connect account</button></div>';
    d.querySelector('button').addEventListener('click', go);
    return d;
  };
  const sync = () => {
    const X = window.XR;
    const known = X && X.status;   // wait for the first status check so a live user never sees a flash of this
    const off = !!known && !X.live;
    document.body.classList.toggle('xr-nodata', off);
    if (!layer) { layer = document.createElement('div'); layer.id = 'xr-gate-layer'; document.body.appendChild(layer); }
    const targets = [];
    if (off) {
      const page = document.body.getAttribute('data-xr-page') || '';
      const main = document.querySelector('#app main');
      if (main && PAGES.includes(page)) targets.push([main, true]);
      else CARDS.forEach((l) => document.querySelectorAll('main [aria-label="' + l + '"]').forEach((el) => targets.push([el, false])));
    }
    while (boxes.length > targets.length) layer.removeChild(boxes.pop().el);
    targets.forEach(([el, big], i) => {
      if (!boxes[i] || boxes[i].big !== big) { const p = panel(big); if (boxes[i]) layer.replaceChild(p, boxes[i].el); else layer.appendChild(p); boxes[i] = { el: p, big }; }
      const r = el.getBoundingClientRect(), b = boxes[i].el;
      const vis = r.width > 40 && r.height > 40 && r.bottom > 0 && r.top < innerHeight;
      b.style.display = vis ? '' : 'none';
      if (vis) { const top = Math.max(r.top, big ? 0 : -9999); b.style.left = r.left + 'px'; b.style.top = top + 'px'; b.style.width = r.width + 'px'; b.style.height = (big ? Math.min(r.bottom, innerHeight) - top : r.height) + 'px'; }
    });
  };
  setInterval(sync, 250); addEventListener('scroll', sync, true); addEventListener('resize', sync);
})();
