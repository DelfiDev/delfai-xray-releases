// My Layout tab: build your own screen out of any widgets in the app. Drag them around, resize them, link them in
// colored groups (change the ticker in one and the whole group follows), and keep several named layouts.
// Each widget is the real widget from its page, running in its own frame with the same live data.
(() => {
  'use strict';
  const KEY = 'xr-floor-v1';
  const COLS = 12, ROW = 30, GAP = 10;
  const GROUPS = { A: '#8FD2EC', B: '#F0A04B', C: '#B48CF2', D: '#34D399' };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const al = (l) => '[aria-label="' + l + '"]';

  // [key, title, category, page, selector, watch mode, follows ticker, default width, default height]
  const W = [
    ['chart', 'Price chart', 'Charts', 'dash', '#xr-chart', null, true, 7, 16],
    ['prem', 'Premium chart', 'Charts', 'watch', 'section' + al('Premium chart'), 'opt', true, 7, 16],
    ['chain', 'Options chain', 'Options', 'watch', 'section' + al('Options chain'), 'opt', true, 7, 14],
    ['book', 'Order book', 'Options', 'watch', '#xr-book', 'opt', true, 5, 14],
    ['grader', 'Setup grader', 'Options', 'watch', 'aside' + al('Setup grader'), 'opt', true, 5, 14],
    ['myopts', 'My options', 'Options', 'watch', 'section' + al('My options'), 'opt', false, 12, 10],
    ['tnews', 'Ticker news', 'Stock', 'dash', 'aside' + al('Ticker news and catalysts'), null, true, 5, 16],
    ['fund', 'Fundamentals', 'Stock', 'dash', '#xr-fund', null, true, 12, 6],
    ['movers', 'Market movers', 'Market', 'dash', 'section' + al('Market movers'), null, false, 7, 14],
    ['wl', 'My watchlist', 'Market', 'watch', 'section' + al('My watchlist'), 'stk', false, 12, 14],
    ['alerts', 'Alerts', 'Market', 'watch', 'section' + al('Alerts'), 'stk', false, 12, 10],
    ['heat', 'Stock heat map', 'Market', 'heat', '#xr-heat', null, false, 12, 22],
    ['stocks', 'Stock screener', 'Market', 'stocks', '#xr-stocks', null, false, 12, 20],
    ['gbrief', 'Opening gamma brief', 'Gamma', 'gamma', al('Opening gamma brief'), null, true, 7, 6],
    ['gregime', 'Gamma regime', 'Gamma', 'gamma', al('Gamma regime'), null, true, 5, 6],
    ['gprof', 'Gamma profile by strike', 'Gamma', 'gamma', al('Gamma profile by strike'), null, true, 6, 10],
    ['gvp', 'Net gamma vs price', 'Gamma', 'gamma', al('Gamma versus price'), null, true, 4, 9],
    ['gpin', '0DTE pin probability', 'Gamma', 'gamma', al('0DTE pin probability'), null, true, 4, 9],
    ['gskew', 'IV skew & term structure', 'Gamma', 'gamma', al('IV skew and term structure'), null, true, 4, 12],
    ['gscan', 'Gamma scanner', 'Gamma', 'gamma', al('Gamma scanner'), null, false, 12, 8],
    ['galerts', 'Gamma alerts', 'Gamma', 'gamma', al('Gamma alerts'), null, true, 12, 7],
    ['mmap', 'Money map', 'Gamma', 'gamma', al('Money map'), null, true, 12, 8],
    ['dread', 'Dealer read', 'Dealer', 'dealer', 'section' + al('Dealer read'), null, true, 12, 6],
    ['dhedge', 'Hedging if price moves', 'Dealer', 'dealer', 'section' + al('Hedging if price moves'), null, true, 12, 10],
    ['dcharm', 'Charm into the close', 'Dealer', 'dealer', 'section' + al('Charm into the close'), null, true, 4, 10],
    ['dvanna', 'Vanna', 'Dealer', 'dealer', 'section' + al('Vanna'), null, true, 4, 10],
    ['dtape', 'Tape check', 'Dealer', 'dealer', 'section' + al('Tape check'), null, true, 4, 10],
    ['dgex', 'Gamma by strike (dealer)', 'Dealer', 'dealer', 'section' + al('Gamma by strike'), null, true, 12, 18],
    ['pdark', 'Dark pool pressure', 'Pulse', 'pulse', 'section' + al('Dark pool pressure'), null, false, 12, 18],
    ['ppulse', 'Options pulse', 'Pulse', 'pulse', 'section' + al('Options pulse'), null, false, 12, 12],
    ['punusual', 'Unusual activity', 'Pulse', 'pulse', 'section' + al('Unusual activity'), null, false, 12, 18],
    ['flow', 'Premium flow', 'Flow', 'flow', al('Premium flow'), null, false, 12, 11],
    ['oscreen', 'Options screener', 'Flow', 'screen', 'div:has(> ' + al('Screener filters') + ')', null, false, 12, 22],
    ['mnews', 'Market news', 'News', 'news', 'section' + al('Market news'), null, false, 6, 18],
    ['cats', 'Catalysts this week', 'News', 'news', 'section' + al('Catalysts this week'), null, false, 6, 18],
    ['bigcats', 'Big mover catalysts', 'News', 'news', 'section' + al('Big mover catalysts'), null, false, 12, 16],
    ['globe', 'Global intel globe', 'News', 'news', al('Global news globe'), null, false, 7, 20],
    ['gnews', 'Global news', 'News', 'news', al('Global news'), null, false, 5, 20],
    ['econ', 'Economic graphs', 'News', 'econ', 'div:has(> [id^="xr-graph-"])', null, false, 12, 20],
    ['jplan', 'Game plan', 'Journal', 'journal', al('Game plan'), null, false, 12, 16],
    ['jequity', 'Equity curve', 'Journal', 'journal', al('Equity curve'), null, false, 7, 10],
    ['jcal', 'P&L calendar', 'Journal', 'journal', al('P&L calendar'), null, false, 5, 10],
    ['jsetup', 'Performance by setup', 'Journal', 'journal', al('Performance by setup'), null, false, 7, 10],
    ['jmist', 'Cost of mistakes', 'Journal', 'journal', al('Cost of mistakes'), null, false, 5, 10],
    ['jmind', 'Mindset & execution', 'Journal', 'journal', al('Mindset'), null, false, 12, 12],
    ['jlog', 'Trade log', 'Journal', 'journal', al('Trade log'), null, false, 12, 10]
  ];
  const WM = {}; W.forEach((w) => { WM[w[0]] = { key: w[0], title: w[1], cat: w[2], page: w[3], sel: w[4], mode: w[5], sym: w[6], w: w[7], h: w[8] }; });
  const CATS = [...new Set(W.map((w) => w[2]))];

  // ---------- saved layouts ----------
  let uid = Date.now() % 100000;
  const nid = () => 'w' + (uid++).toString(36) + Math.random().toString(36).slice(2, 5);
  const item = (key, x, y, w, h, g) => ({ id: nid(), key, x, y, w: w || WM[key].w, h: h || WM[key].h, g: g === undefined ? (WM[key].sym ? 'A' : null) : g, sym: null });
  const DEFAULT = () => ({ name: 'My layout', groups: { A: 'SPY', B: 'QQQ', C: 'NVDA', D: 'TSLA' }, items: [
    item('chart', 0, 0, 7, 17), item('prem', 7, 0, 5, 17),
    item('chain', 0, 17, 7, 15), item('book', 7, 17, 5, 15),
    item('gprof', 0, 32, 6, 11), item('flow', 6, 32, 6, 11),
    item('alerts', 0, 43, 12, 10, null)
  ] });
  const load = () => { try { const s = JSON.parse(localStorage.getItem(KEY) || 'null'); if (s && Array.isArray(s.list) && s.list.length) return s; } catch (e) { /* fresh */ } return { cur: 0, list: [DEFAULT()] }; };
  let S = load();
  const L = () => S.list[Math.min(S.cur, S.list.length - 1)];
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { /* storage full */ } };
  L().items = L().items.filter((it) => WM[it.key]);

  // ---------- grid math ----------
  let area = null, host = null, layer = null, editing = false, open = null;
  const colW = () => ((area ? area.clientWidth : 1000) - GAP * (COLS - 1)) / COLS;
  const px = (it) => { const c = colW(); return { left: it.x * (c + GAP), top: it.y * (ROW + GAP), width: it.w * c + (it.w - 1) * GAP, height: it.h * ROW + (it.h - 1) * GAP }; };
  const hit = (a, b) => a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
  // put `first` where it was dropped, then let everything else fall into place (no overlaps, no gaps above)
  const settle = (first) => {
    const items = L().items; const placed = [];
    if (first) { first.x = Math.max(0, Math.min(COLS - first.w, first.x)); first.y = Math.max(0, first.y); placed.push(first); }
    items.filter((i) => i !== first).sort((a, b) => a.y - b.y || a.x - b.x).forEach((it) => {
      it.x = Math.max(0, Math.min(COLS - it.w, it.x));
      let y = 0; while (placed.some((p) => hit(p, { x: it.x, y, w: it.w, h: it.h }))) y++;
      it.y = y; placed.push(it);
    });
    // close gaps: float each item up as far as it can go
    placed.sort((a, b) => a.y - b.y).forEach((it) => { while (it.y > 0 && !placed.some((p) => p !== it && hit(p, { x: it.x, y: it.y - 1, w: it.w, h: it.h }))) it.y--; });
  };
  const rowsUsed = () => L().items.reduce((m, it) => Math.max(m, it.y + it.h), 0);

  // ---------- frames ----------
  const frames = {};   // id -> { el, frame, ready }
  const symOf = (it) => (it.g ? L().groups[it.g] : it.sym) || 'SPY';
  const src = (it) => { const w = WM[it.key]; const pop = it.key === 'chart' ? 'S' : it.key === 'prem' ? 'O' : 'E'; return location.pathname + '#pop=' + pop + '&emb=' + encodeURIComponent(JSON.stringify({ id: it.id, page: w.page, sel: w.sel, mode: w.mode, sym: w.sym ? symOf(it) : null })); };
  const sendSym = (it) => { const f = frames[it.id]; if (f && f.frame && f.frame.contentWindow && WM[it.key].sym) f.frame.contentWindow.postMessage({ xrEmbSet: it.id, sym: symOf(it) }, location.origin); };

  const groupBtn = (it) => {
    if (!WM[it.key].sym) return '';
    const c = it.g ? GROUPS[it.g] : '#5B6B7A';
    return '<div class="xf-gw"><button type="button" class="xf-g" data-gmenu="' + it.id + '" aria-expanded="' + (open === 'g:' + it.id) + '" title="' + (it.g ? 'Linked to group ' + it.g + ': the whole group shows the same ticker' : 'Not linked: this widget keeps its own ticker') + '"><span class="xf-dot" style="background:' + c + '"></span>' + (it.g || '—') + '</button>' + '</div>';
  };
  const headHtml = (it) => {
    const w = WM[it.key];
    return '<div class="xf-hd" data-drag="' + it.id + '">' + (editing ? '<span class="xf-grip" aria-hidden="true">⋮⋮</span>' : '') + '<span class="xf-t">' + esc(w.title) + '</span>' +
      (w.sym ? '<input class="xf-sym" data-symfor="' + it.id + '" value="' + esc(symOf(it)) + '" aria-label="Ticker for ' + esc(w.title) + '" spellcheck="false" autocomplete="off">' : '') + groupBtn(it) +
      (editing ? '<button type="button" class="xf-x" data-rm="' + it.id + '" aria-label="Remove ' + esc(w.title) + '">×</button>' : '') + '</div>';
  };
  const ensure = (it) => {
    let f = frames[it.id];
    if (!f) {
      const el = document.createElement('div'); el.className = 'xf-w'; el.dataset.id = it.id;
      el.innerHTML = '<div class="xf-hdw"></div><div class="xf-body"><div class="xf-load">Loading ' + esc(WM[it.key].title) + '…</div><iframe class="xf-fr" title="' + esc(WM[it.key].title) + '" src="' + esc(src(it)) + '"></iframe><div class="xf-shield" data-drag="' + it.id + '"></div></div><div class="xf-rs" data-rs="' + it.id + '" title="Drag to resize" aria-hidden="true"></div>';
      layer.appendChild(el);
      f = frames[it.id] = { el, frame: el.querySelector('iframe'), ready: false, hd: '' };
    }
    return f;
  };
  const paintItem = (it) => {
    const f = ensure(it); const p = px(it);
    Object.assign(f.el.style, { transform: 'translate(' + p.left + 'px,' + p.top + 'px)', width: p.width + 'px', height: p.height + 'px' });
    f.el.style.setProperty('--gc', it.g && WM[it.key].sym ? GROUPS[it.g] : 'transparent');
    const h = headHtml(it);
    if (h !== f.hd) { const focus = document.activeElement && f.el.contains(document.activeElement) && document.activeElement.matches('.xf-sym'); if (!focus) { f.el.querySelector('.xf-hdw').innerHTML = h; f.hd = h; } }
    f.el.classList.toggle('xf-ready', f.ready);
  };
  const paint = () => {
    if (!host || !area) return;
    const items = L().items;
    Object.keys(frames).forEach((id) => { if (!items.some((i) => i.id === id)) { frames[id].el.remove(); delete frames[id]; } });
    items.forEach(paintItem);
    area.style.height = Math.max(ROW * 4, rowsUsed() * (ROW + GAP) + 40) + 'px';
    layer.classList.toggle('xf-edit', editing);
    const empty = host.querySelector('.xf-empty'); if (empty) empty.hidden = items.length > 0;
  };

  // ---------- toolbar ----------
  // the layout and add-widget menus float above the widgets, so they live on their own layer
  const popHtml = () => {
    if (open === 'layouts') return '<div class="xf-pop" role="listbox" aria-label="Layouts">' + S.list.map((l, i) => '<button type="button" role="option" class="xf-opt" data-pick="' + i + '" aria-selected="' + (i === S.cur) + '">' + esc(l.name) + '<span class="xf-dim">' + l.items.length + ' widgets</span></button>').join('') +
      '<div class="xf-sep"></div><label class="xf-lab">Name<input type="text" class="xf-name" value="' + esc(L().name) + '" maxlength="40"></label><div class="xf-row"><button type="button" class="xs-btn" data-rename="1">Rename</button><button type="button" class="xs-btn" data-new="1">New layout</button><button type="button" class="xs-btn" data-dup="1">Copy</button></div>' +
      (S.list.length > 1 ? '<button type="button" class="xs-clear" data-dellayout="1">Delete this layout</button>' : '') + '</div>';
    if (open === 'add') return '<div class="xf-pop xf-addpop" role="dialog" aria-label="Add widget">' + CATS.map((c) => '<div class="xf-cat"><div class="xf-ch">' + esc(c) + '</div>' + W.filter((w) => w[2] === c).map((w) => '<button type="button" class="xf-add-i" data-add="' + w[0] + '">' + esc(w[1]) + '</button>').join('') + '</div>').join('') + '</div>';
    if (open && open.startsWith('g:')) {
      const it = itemById(open.slice(2)); if (!it) return '';
      return '<div class="xf-pop" role="listbox" aria-label="Link group">' + Object.keys(GROUPS).map((g) => '<button type="button" role="option" class="xf-opt" data-setg="' + g + '" data-id="' + it.id + '" aria-selected="' + (it.g === g) + '"><span class="xf-dot" style="background:' + GROUPS[g] + '"></span>Group ' + g + '<span class="xf-dim">' + esc(L().groups[g]) + '</span></button>').join('') + '<button type="button" role="option" class="xf-opt" data-setg="" data-id="' + it.id + '" aria-selected="' + !it.g + '"><span class="xf-dot" style="background:#5B6B7A"></span>Own ticker<span class="xf-dim">' + esc(it.g ? '' : symOf(it)) + '</span></button></div>';
    }
    return '';
  };
  let popL = null;
  const drawPop = () => {
    if (!popL) { popL = document.createElement('div'); popL.className = 'xf-popl'; document.body.appendChild(popL); popL.addEventListener('click', onClick); popL.addEventListener('keydown', onKey); }
    const btn = host && open && (open.startsWith('g:') ? layer && layer.querySelector('[data-gmenu="' + open.slice(2) + '"]') : host.querySelector('[data-open="' + open + '"]'));
    if (!btn) { popL.innerHTML = ''; return; }
    popL.innerHTML = popHtml();
    const r = btn.getBoundingClientRect(); const pop = popL.firstChild; if (!pop) return;
    const w = pop.offsetWidth; const left = open === 'layouts' ? r.left : Math.max(8, Math.min(window.innerWidth - w - 8, r.right - w));
    Object.assign(pop.style, { position: 'fixed', top: (r.bottom + 6) + 'px', left: left + 'px' });
  };
  const bar = () => {
    return '<div class="xh-top"><h1 class="xh-h1">My Layout</h1>' +
      '<div class="xf-lw"><button type="button" class="xs-btn" data-open="layouts" aria-expanded="' + (open === 'layouts') + '">' + esc(L().name) + ' <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#8796A3" stroke-width="2" aria-hidden="true"><path d="M6 9l6 6 6-6"></path></svg></button>' +
      '</div>' +
      '<div class="xh-tools">' + (editing ? '<div class="xf-lw"><button type="button" class="xs-btn" data-open="add" aria-expanded="' + (open === 'add') + '">+ Add widget</button></div><button type="button" class="xs-btn" data-clear="1">Clear all</button><button type="button" class="xs-btn" data-default="1">Reset to default</button>' : '') +
      '<button type="button" class="xf-edit-b' + (editing ? ' on' : '') + '" data-edit="1" aria-pressed="' + editing + '"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18.4 2.6a2 2 0 0 1 2.9 2.9L11 15.8l-3.6.7.7-3.6z"></path><path d="M7.5 16.5c-2 0-3.5 1.5-3.5 3.5 0 .6-.4 1-1 1 1.5 1 3 1 4.5 1 2.5 0 4-1.6 4-3.5"></path></svg>' + (editing ? 'Done' : 'Edit layout') + '</button></div></div>' +
      '<p class="xf-help">' + (editing ? 'Drag a widget by its title bar, resize from the bottom-right corner, × removes it. Click Done to lock it in.' : 'Widgets with the same colored group share one ticker: type a ticker in any of them and the whole group follows.') + '</p>';
  };
  const shell = () => {
    host.innerHTML = '<div class="xf-bar"></div><div class="xf-area" id="xf-area"><p class="xf-empty" hidden>Nothing here yet. Click <b>Edit layout</b>, then <b>+ Add widget</b>.</p></div>';
    area = host.querySelector('#xf-area');
  };
  const drawBar = () => { if (host) { const b = host.querySelector('.xf-bar'); if (b) b.innerHTML = bar(); } drawPop(); };

  // ---------- keep the frame layer over the page area ----------
  const track = () => {
    if (!layer) return;
    const on = host && area && host.isConnected;
    if (!on) { layer.style.display = 'none'; return; }
    const r = area.getBoundingClientRect(); const m = (document.querySelector('#app main') || document.body).getBoundingClientRect();
    layer.style.display = 'block';
    layer.style.transform = 'translate(' + r.left + 'px,' + r.top + 'px)'; layer.style.width = r.width + 'px'; layer.style.height = r.height + 'px';
    // never paint over the top bar or the side menu
    const top = Math.max(0, m.top - r.top), left = Math.max(0, m.left - r.left);
    layer.style.clipPath = 'inset(' + top + 'px 0 0 ' + left + 'px)';
  };
  const loop = () => { track(); requestAnimationFrame(loop); };

  // ---------- interaction ----------
  let drag = null;
  const itemById = (id) => L().items.find((i) => i.id === id);
  const groupChanged = (g) => L().items.forEach((it) => { if (it.g === g) { sendSym(it); paintItem(it); } });
  const setTicker = (it, raw) => {
    const s = String(raw || '').trim().toUpperCase().replace(/^\$/, '');
    if (!/^\^?[A-Z][A-Z.]{0,6}$/.test(s)) return false;
    if (it.g) { if (L().groups[it.g] === s) return true; L().groups[it.g] = s; save(); groupChanged(it.g); }
    else { it.sym = s; save(); sendSym(it); paintItem(it); }
    return true;
  };
  const onDown = (e) => {
    if (!editing || e.button !== 0) return;
    const rs = e.target.closest('[data-rs]'); const hd = e.target.closest('[data-drag]');
    if (!rs && (!hd || e.target.closest('button, input'))) return;
    const it = itemById((rs || hd).dataset.rs || hd.dataset.drag); if (!it) return;
    e.preventDefault();
    drag = { it, rs: !!rs, sx: e.clientX, sy: e.clientY, ox: it.x, oy: it.y, ow: it.w, oh: it.h };
    frames[it.id].el.classList.add('xf-moving');
  };
  const onMove = (e) => {
    if (!drag) return;
    const c = colW() + GAP, rH = ROW + GAP; const dx = Math.round((e.clientX - drag.sx) / c), dy = Math.round((e.clientY - drag.sy) / rH);
    const it = drag.it;
    if (drag.rs) { it.w = Math.max(2, Math.min(COLS - it.x, drag.ow + dx)); it.h = Math.max(4, drag.oh + dy); }
    else { it.x = Math.max(0, Math.min(COLS - it.w, drag.ox + dx)); it.y = Math.max(0, drag.oy + dy); }
    settle(it); paint();
    const f = frames[it.id]; if (f && !drag.rs) { const p = px(it); f.el.style.transform = 'translate(' + (p.left + (e.clientX - drag.sx) - dx * c) + 'px,' + (p.top + (e.clientY - drag.sy) - dy * rH) + 'px)'; }
  };
  const onUp = () => { if (!drag) return; frames[drag.it.id].el.classList.remove('xf-moving'); drag = null; settle(); save(); paint(); };

  const onClick = (e) => {
    const t = e.target.closest('button'); if (!t) return;
    const d = t.dataset;
    if (d.connect) { if (window.XRGo) window.XRGo('/setup.html'); else location.href = '/setup.html'; return; }
    if (d.edit) { editing = !editing; open = null; if (!editing) { settle(); save(); } drawBar(); paint(); return; }
    if (d.open) { open = open === d.open ? null : d.open; drawBar(); return; }
    if (d.gmenu) { open = open === 'g:' + d.gmenu ? null : 'g:' + d.gmenu; paint(); drawPop(); return; }
    if (d.setg !== undefined) { const it = itemById(d.id); if (it) { if (!d.setg && it.g) it.sym = L().groups[it.g]; it.g = d.setg || null; save(); sendSym(it); } open = null; paint(); drawPop(); return; }
    if (d.add) {
      const it = item(d.add, 0, rowsUsed()); L().items.push(it); settle(it); save(); open = null; drawBar(); paint();
      setTimeout(() => { if (area) window.scrollTo({ top: window.scrollY + area.getBoundingClientRect().top + px(it).top - 140, behavior: 'smooth' }); }, 50);
      return;
    }
    if (d.rm) { L().items = L().items.filter((i) => i.id !== d.rm); settle(); save(); paint(); drawBar(); return; }
    if (d.pick !== undefined) { S.cur = +d.pick; open = null; save(); swapLayout(); return; }
    if (d.rename) { const n = (host.querySelector('.xf-name') || {}).value || ''; if (n.trim()) { L().name = n.trim(); save(); } open = null; drawBar(); return; }
    if (d.new) { S.list.push({ name: 'Layout ' + (S.list.length + 1), groups: { A: 'SPY', B: 'QQQ', C: 'NVDA', D: 'TSLA' }, items: [] }); S.cur = S.list.length - 1; editing = true; open = 'add'; save(); swapLayout(); return; }
    if (d.dup) { const c = JSON.parse(JSON.stringify(L())); c.name = L().name + ' copy'; c.items.forEach((i) => { i.id = nid(); }); S.list.push(c); S.cur = S.list.length - 1; open = null; save(); swapLayout(); return; }
    if (d.dellayout) { S.list.splice(S.cur, 1); S.cur = 0; open = null; save(); swapLayout(); return; }
    if (d.clear) { L().items = []; save(); paint(); drawBar(); return; }
    if (d.default) { const keep = L().name; S.list[S.cur] = DEFAULT(); L().name = keep; save(); swapLayout(); return; }
  };
  const swapLayout = () => { Object.keys(frames).forEach((id) => { frames[id].el.remove(); delete frames[id]; }); drawBar(); paint(); };
  const onKey = (e) => {
    const inp = e.target.closest && e.target.closest('.xf-sym');
    if (inp && e.key === 'Enter') { const it = itemById(inp.dataset.symfor); if (it && setTicker(it, inp.value)) { inp.blur(); const f = frames[it.id]; if (f) f.hd = ''; paintItem(it); } else inp.select(); }
    if (inp && e.key === 'Escape') { const it = itemById(inp.dataset.symfor); inp.value = symOf(it); inp.blur(); }
    if (e.key === 'Escape' && open) { open = null; drawBar(); paint(); }
  };
  const onFocusOut = (e) => { const inp = e.target.closest && e.target.closest('.xf-sym'); if (inp) { const it = itemById(inp.dataset.symfor); if (it) { inp.value = symOf(it); const f = frames[it.id]; if (f) f.hd = ''; setTimeout(() => paintItem(it), 0); } } };

  // widgets talk back: ready, ticker changed inside, or the widget isn't on its page (locked, not loaded)
  window.addEventListener('message', (e) => {
    if (e.origin !== location.origin || !e.data || !e.data.xrEmb) return;
    const it = itemById(e.data.xrEmb); const f = frames[e.data.xrEmb]; if (!it || !f) return;
    if (e.data.type === 'ready') { f.ready = true; f.el.classList.add('xf-ready'); f.el.classList.remove('xf-missing'); }
    if (e.data.type === 'missing') {
      f.el.classList.add('xf-missing'); const l = f.el.querySelector('.xf-load'); const w = WM[it.key];
      if (l) l.innerHTML = e.data.why === 'locked' ? '<span>' + esc(w.title) + ' is an X-ray Pro widget.</span>'
        : e.data.why === 'offline' ? '<span>Market data not connected.</span><button type="button" class="xs-apply" data-connect="1">Connect account</button>'
        : '<span>' + (w.mode === 'opt' ? 'Waiting for the options chain from your broker…' : 'Loading ' + esc(w.title) + (w.sym ? ' for ' + esc(symOf(it)) : '') + '…') + '</span>';
    }
    if (e.data.type === 'found') { f.el.classList.remove('xf-missing'); }
    if (e.data.type === 'sym' && WM[it.key].sym) setTicker(it, e.data.sym);
  });

  // ---------- mount ----------
  let away = 0;
  const tick = () => {
    const h = document.getElementById('xr-floor');
    if (h && h !== host) {
      host = h; shell(); drawBar();
      if (!layer) { layer = document.createElement('div'); layer.className = 'xf-layer'; document.body.appendChild(layer); layer.addEventListener('mousedown', onDown); layer.addEventListener('click', onClick); layer.addEventListener('keydown', onKey); layer.addEventListener('focusout', onFocusOut); }
      host.addEventListener('click', onClick); host.addEventListener('keydown', onKey);
      settle(); paint(); away = 0;
    }
    if (!h && host) { host = null; area = null; away = Date.now(); open = null; drawPop(); }
    document.body.classList.toggle('xf-on', !!host);
    // left the tab a while ago: free the widgets (they reload when you come back)
    if (!host && away && Date.now() - away > 120000) { Object.keys(frames).forEach((id) => { frames[id].el.remove(); delete frames[id]; }); away = 0; }
    if (host && area) { const w = area.clientWidth; if (w !== tick.w) { tick.w = w; paint(); } }
  };
  document.addEventListener('mousemove', onMove); document.addEventListener('mouseup', onUp);
  document.addEventListener('mousedown', (e) => { if (open && !(e.target.closest && e.target.closest('.xf-pop, .xf-popl, [data-open], [data-gmenu]'))) { open = null; drawBar(); if (host) paint(); } });
  if (!/[#&]emb=/.test(location.hash)) { setInterval(tick, 200); requestAnimationFrame(loop); }
})();
