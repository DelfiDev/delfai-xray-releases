// Stock screener (like TradingView's): preset screens, filter pills with manual setup, extra filters, column sets,
// sorting, CSV export, saved screens, and a heat map view of the results. Real values only, from /api/universe.
(() => {
  'use strict';
  const U = () => window.XRU;
  const KEY = 'xr-stocks';
  const B = 1e9, M = 1e6;

  // ---------- every field the screener can filter or show ----------
  // [key, label, format, category]
  const F = [
    ['px', 'Price', 'px', 'Market data'], ['chg', 'Change %', 'pct', 'Market data'], ['chgAbs', 'Change', 'num', 'Market data'], ['vol', 'Volume', 'vol', 'Market data'], ['avgVol', 'Average volume 30D', 'vol', 'Market data'],
    ['relVol', 'Relative volume', 'x', 'Market data'], ['turnover', 'Turnover 1D', 'money', 'Market data'], ['gap', 'Gap %', 'pct', 'Market data'], ['chgOpen', 'Change from open %', 'pct', 'Market data'],
    ['volat', 'Volatility 1D %', 'pctPlain', 'Market data'], ['high', 'High', 'px', 'Market data'], ['low', 'Low', 'px', 'Market data'], ['open', 'Open', 'px', 'Market data'],
    ['hi52', '52W high', 'px', 'Market data'], ['lo52', '52W low', 'px', 'Market data'], ['offHi', 'Below 52W high %', 'pctPlain', 'Market data'], ['offLo', 'Above 52W low %', 'pctPlain', 'Market data'],
    ['p1w', 'Performance 1W %', 'pct', 'Market data'], ['p1m', 'Performance 1M %', 'pct', 'Market data'], ['p3m', 'Performance 3M %', 'pct', 'Market data'], ['p6m', 'Performance 6M %', 'pct', 'Market data'], ['pytd', 'Performance YTD %', 'pct', 'Market data'], ['p1y', 'Performance 1Y %', 'pct', 'Market data'],
    ['vol1m', 'Volatility 1M (daily σ) %', 'pctPlain', 'Market data'], ['beta', 'Beta', 'num', 'Market data'],
    ['rsi', 'RSI 14', 'num1', 'Technicals'], ['macd', 'MACD (12, 26)', 'num', 'Technicals'], ['macdSig', 'MACD signal (9)', 'num', 'Technicals'], ['adx', 'ADX 14', 'num1', 'Technicals'], ['atrPct', 'ATR % (14)', 'pctPlain', 'Technicals'],
    ['adrPct', 'Average daily range % (14)', 'pctPlain', 'Technicals'], ['stochK', 'Stochastic %K (14)', 'num1', 'Technicals'], ['cci', 'CCI 20', 'num1', 'Technicals'], ['ema20', 'EMA 20', 'px', 'Technicals'], ['ema50', 'EMA 50', 'px', 'Technicals'],
    ['sma50', 'SMA 50', 'px', 'Technicals'], ['sma200', 'SMA 200', 'px', 'Technicals'], ['vsEma50', 'Price vs EMA 50 %', 'pct', 'Technicals'], ['vsSma200', 'Price vs SMA 200 %', 'pct', 'Technicals'],
    ['bbU', 'Bollinger upper (20, 2)', 'px', 'Technicals'], ['bbL', 'Bollinger lower (20, 2)', 'px', 'Technicals'], ['bbPos', 'Bollinger %B', 'num1', 'Technicals'],
    ['rev', 'Revenue (FY)', 'money', 'Financials'], ['gp', 'Gross profit (FY)', 'money', 'Financials'], ['op', 'Operating income (FY)', 'money', 'Financials'], ['ni', 'Net income (FY)', 'money', 'Financials'],
    ['ebitda', 'EBITDA (FY)', 'money', 'Financials'], ['eps', 'EPS diluted (FY)', 'num', 'Financials'], ['rd', 'R&D (FY)', 'money', 'Financials'], ['ocf', 'Operating cash flow (FY)', 'money', 'Financials'],
    ['icf', 'Investing cash flow (FY)', 'money', 'Financials'], ['fin', 'Financing cash flow (FY)', 'money', 'Financials'], ['capex', 'CapEx (FY)', 'money', 'Financials'], ['fcf', 'Free cash flow (FY)', 'money', 'Financials'],
    ['cash', 'Cash & equivalents', 'money', 'Financials'], ['debt', 'Total debt', 'money', 'Financials'], ['netDebt', 'Net debt', 'money', 'Financials'], ['assets', 'Total assets', 'money', 'Financials'],
    ['liab', 'Total liabilities', 'money', 'Financials'], ['equity', 'Total equity', 'money', 'Financials'], ['cr', 'Current ratio', 'num', 'Financials'], ['de', 'Debt to equity', 'num', 'Financials'],
    ['mcap', 'Market cap', 'money', 'Valuation'], ['pe', 'P/E', 'num', 'Valuation'], ['peg', 'PEG', 'num', 'Valuation'], ['ps', 'P/S', 'num', 'Valuation'], ['pb', 'P/B', 'num', 'Valuation'],
    ['pcf', 'P/CF', 'num', 'Valuation'], ['pfcf', 'P/FCF', 'num', 'Valuation'], ['ev', 'Enterprise value', 'money', 'Valuation'], ['evEbitda', 'EV/EBITDA', 'num', 'Valuation'], ['evRev', 'EV/Revenue', 'num', 'Valuation'], ['ey', 'Earnings yield %', 'pctPlain', 'Valuation'],
    ['revG', 'Revenue growth % (FY YoY)', 'pct', 'Growth'], ['epsG', 'EPS diluted growth % (FY YoY)', 'pct', 'Growth'], ['niG', 'Net income growth %', 'pct', 'Growth'], ['gpG', 'Gross profit growth %', 'pct', 'Growth'],
    ['ebitdaG', 'EBITDA growth %', 'pct', 'Growth'], ['fcfG', 'Free cash flow growth %', 'pct', 'Growth'], ['capexG', 'CapEx growth %', 'pct', 'Growth'], ['debtG', 'Total debt growth % (YoY)', 'pct', 'Growth'], ['assetsG', 'Total assets growth % (YoY)', 'pct', 'Growth'],
    ['gm', 'Gross margin %', 'pctPlain', 'Margins'], ['om', 'Operating margin %', 'pctPlain', 'Margins'], ['nm', 'Net margin %', 'pctPlain', 'Margins'], ['fcfM', 'FCF margin %', 'pctPlain', 'Margins'],
    ['roa', 'Return on assets %', 'pctPlain', 'Margins'], ['roe', 'Return on equity %', 'pctPlain', 'Margins'], ['roic', 'Return on invested capital %', 'pctPlain', 'Margins'], ['rdr', 'R&D ratio %', 'pctPlain', 'Margins'],
    ['div', 'Dividend yield %', 'pctPlain', 'Dividends'], ['dps', 'Dividends per share (FY)', 'num', 'Dividends'], ['payout', 'Payout ratio %', 'pctPlain', 'Dividends'], ['dpsG', 'DPS growth %', 'pct', 'Dividends'],
    ['divGrowYrs', 'Years of dividend growth', 'int', 'Dividends'], ['divYrs', 'Years paying dividends', 'int', 'Dividends'],
    ['revSh', 'Revenue per share', 'num', 'Per share'], ['fcfSh', 'FCF per share', 'num', 'Per share'], ['bookSh', 'Book value per share', 'num', 'Per share'], ['cashSh', 'Cash per share', 'num', 'Per share'], ['debtSh', 'Debt per share', 'num', 'Per share'],
    ['shares', 'Shares outstanding', 'vol', 'Security info'], ['sector', 'Sector', 'text', 'Security info'], ['ern', 'Next earnings', 'date', 'Security info'], ['rern', 'Last earnings', 'date', 'Security info']
  ];
  const FM = {}; F.forEach((f) => { FM[f[0]] = f; });
  const CATS = ['Security info', 'Market data', 'Technicals', 'Financials', 'Valuation', 'Growth', 'Margins', 'Dividends', 'Per share'];
  const show = (k, v) => {
    const f = U().fmt, t = FM[k] ? FM[k][2] : 'num';
    if (t === 'text') return v ? U().esc(v) : '—';
    if (t === 'date') return f.date(v);
    if (t === 'int') return Number.isFinite(v) ? String(v) : '—';
    if (t === 'num1') return f.num(v, 1);
    return (f[t] || f.num)(v);
  };

  // ---------- filters ----------
  // { f: field, op: gt|ge|lt|le|btw|out|eq|gtf|ltf|true|in|has|days, a, b }
  const test = (r, x) => {
    if (x.op === 'in') return x.a.includes(r[x.f]);
    if (x.op === 'has') return Array.isArray(r[x.f]) && x.a.some((v) => r[x.f].includes(v));
    if (x.op === 'syms') return x.a.includes(r.sym);
    if (x.op === 'true') return !!r[x.f];
    if (x.op === 'days') { if (!r[x.f]) return false; const d = (Date.parse(r[x.f] + 'T12:00:00Z') - Date.parse(today() + 'T12:00:00Z')) / 864e5; return d >= x.a && d <= x.b; }
    if (x.op === 'none') return !(r[x.f] > 0);
    const v = r[x.f]; if (!Number.isFinite(v)) return false;
    if (x.op === 'gtf' || x.op === 'ltf') { const w = r[x.a]; if (!Number.isFinite(w)) return false; return x.op === 'gtf' ? v > w : v < w; }
    switch (x.op) { case 'gt': return v > x.a; case 'ge': return v >= x.a; case 'lt': return v < x.a; case 'le': return v <= x.a; case 'btw': return v >= x.a && v <= x.b; case 'out': return v < x.a || v > x.b; case 'eq': return Math.abs(v - x.a) < 1e-9; default: return true; }
  };
  const today = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'America/New_York' }).format(new Date());
  const dow = () => new Date(today() + 'T12:00:00Z').getUTCDay();

  const o = (label, sub, flt) => ({ label, sub, flt });
  const gt = (f, a) => ({ f, op: 'gt', a }), lt = (f, a) => ({ f, op: 'lt', a }), btw = (f, a, b) => ({ f, op: 'btw', a, b });
  const chgOpts = (f) => [o('Above 30%', 'Exceptional up', gt(f, 30)), o('Above 20%', 'Very strong up', gt(f, 20)), o('Above 10%', 'Strong up', gt(f, 10)), o('Above 5%', 'Moderate up', gt(f, 5)), o('0% to 5%', 'Weak up', btw(f, 0, 5)), o('Above 0%', 'Up', gt(f, 0)), o('Below 0%', 'Down', lt(f, 0)), o('−5% to 0%', 'Weak down', btw(f, -5, 0)), o('Below −5%', 'Moderate down', lt(f, -5)), o('Below −10%', 'Strong down', lt(f, -10)), o('Below −20%', 'Very strong down', lt(f, -20)), o('Below −30%', 'Exceptional down', lt(f, -30))];
  // pills: [id, label, title, field for manual setup, options, multi?]
  const PILLS = () => [
    ['idx', 'Index', 'Index', null, U().INDEXES.map(([k, l]) => o(l, k, { f: 'idx', op: 'has', a: [k] })), true],
    ['wl', 'Watchlist', 'Your watchlists', null, U().lists().map((l) => o(l.name, l.syms.length + ' symbols', { f: 'sym', op: 'syms', a: l.syms, id: l.id }))],
    ['px', 'Price', 'Price', 'px', [o('Above 100', 'Fractional shares time', gt('px', 100)), o('10 to 100', 'Mid-priced', btw('px', 10, 100)), o('10 and below', 'Not quite penny stocks', { f: 'px', op: 'le', a: 10 }), o('5 and below', 'Penny stocks', { f: 'px', op: 'le', a: 5 }), o('Above EMA 50', 'Uptrend', { f: 'px', op: 'gtf', a: 'ema50' }), o('Below EMA 50', 'Downtrend', { f: 'px', op: 'ltf', a: 'ema50' }), o('Crosses BB 20 upper', 'Overbought', { f: 'bbCrossU', op: 'true' }), o('Crosses BB 20 lower', 'Oversold', { f: 'bbCrossL', op: 'true' })]],
    ['chg', 'Chg %', 'Price change % · 1 day', 'chg', chgOpts('chg')],
    ['mcap', 'Mkt cap', 'Market capitalization', 'mcap', [o('200B and above', 'Mega', { f: 'mcap', op: 'ge', a: 200 * B }), o('10B to 200B', 'Large', btw('mcap', 10 * B, 200 * B)), o('2B to 10B', 'Mid', btw('mcap', 2 * B, 10 * B)), o('300M to 2B', 'Small', btw('mcap', 300 * M, 2 * B)), o('50M to 300M', 'Micro', btw('mcap', 50 * M, 300 * M)), o('50M and below', 'Nano', { f: 'mcap', op: 'le', a: 50 * M })]],
    ['pe', 'P/E', 'Price to earnings', 'pe', [o('50 and above', 'Extremely high', { f: 'pe', op: 'ge', a: 50 }), o('35 to 50', 'Very high', btw('pe', 35, 50)), o('25 to 35', 'High', btw('pe', 25, 35)), o('15 to 25', 'Moderate', btw('pe', 15, 25)), o('5 to 15', 'Low', btw('pe', 5, 15)), o('0 to 5', 'Very low', btw('pe', 0, 5))]],
    ['epsG', 'EPS dil growth', 'EPS diluted growth · FY YoY', 'epsG', [o('Above 50%', 'Exceptional', gt('epsG', 50)), o('25% to 50%', 'Strong', btw('epsG', 25, 50)), o('10% to 25%', 'Moderate', btw('epsG', 10, 25)), o('5% to 10%', 'Low', btw('epsG', 5, 10)), o('0% to 5%', 'Minimal', btw('epsG', 0, 5)), o('Above 0%', 'Positive', gt('epsG', 0)), o('Below 0%', 'Reduction', lt('epsG', 0))]],
    ['div', 'Div yield %', 'Dividend yield', 'div', [o('Above 15%', 'Extremely high', gt('div', 15)), o('10% to 15%', 'Very high', btw('div', 10, 15)), o('6% to 10%', 'High', btw('div', 6, 10)), o('4% to 6%', 'Moderate', btw('div', 4, 6)), o('2% to 4%', 'Low', btw('div', 2, 4)), o('0% to 2%', 'Minimal', { f: 'div', op: 'btw', a: 0.0001, b: 2 }), o('0%', 'No dividend', { f: 'div', op: 'none' })]],
    ['sector', 'Sector', 'Sector (GICS)', null, U().SECTORS.map((s) => o(s, '', { f: 'sector', op: 'in', a: [s] })), true],
    ['perf', 'Perf %', 'Performance % · YTD', 'pytd', chgOpts('pytd')],
    ['revG', 'Revenue growth', 'Revenue growth · FY YoY', 'revG', [o('Above 50%', '', gt('revG', 50)), o('25% to 50%', '', btw('revG', 25, 50)), o('10% to 25%', '', btw('revG', 10, 25)), o('0% to 10%', '', btw('revG', 0, 10)), o('Above 0%', '', gt('revG', 0)), o('Below 0%', '', lt('revG', 0)), o('−25% to 0%', '', btw('revG', -25, 0)), o('Below −25%', '', lt('revG', -25))]],
    ['peg', 'PEG', 'Price/earnings to growth', 'peg', [o('Above 3', '', gt('peg', 3)), o('2 to 3', '', btw('peg', 2, 3)), o('1.5 to 2', '', btw('peg', 1.5, 2)), o('1 to 1.5', '', btw('peg', 1, 1.5)), o('0.5 to 1', '', btw('peg', 0.5, 1)), o('0 to 0.5', '', btw('peg', 0, 0.5))]],
    ['roe', 'ROE', 'Return on equity · FY', 'roe', [o('Above 30%', '', gt('roe', 30)), o('20% to 30%', '', btw('roe', 20, 30)), o('10% to 20%', '', btw('roe', 10, 20)), o('5% to 10%', '', btw('roe', 5, 10)), o('0% to 5%', '', btw('roe', 0, 5)), o('Above 0%', '', gt('roe', 0)), o('Below 0%', '', lt('roe', 0))]],
    ['beta', 'Beta', 'Beta', 'beta', [o('Above 1.5', 'Very high volatility', gt('beta', 1.5)), o('1.1 to 1.5', 'High', btw('beta', 1.1, 1.5)), o('0.9 to 1.1', 'Market', btw('beta', 0.9, 1.1)), o('0.5 to 0.9', 'Low', btw('beta', 0.5, 0.9)), o('0 to 0.5', 'Very low', btw('beta', 0, 0.5)), o('Above 0', '', gt('beta', 0)), o('Below 0', 'Inverse', lt('beta', 0))]],
    ['ern', 'Upcoming earnings', 'Upcoming earnings date', null, (() => { const d = dow(); const toFri = Math.max(0, 5 - d); return [o('Today', '', { f: 'ern', op: 'days', a: 0, b: 0 }), o('Next day', '', { f: 'ern', op: 'days', a: 1, b: d === 5 ? 3 : 1 }), o('Next 5 days', '', { f: 'ern', op: 'days', a: 0, b: 7 }), o('This week', '', { f: 'ern', op: 'days', a: 0, b: toFri }), o('Next week', '', { f: 'ern', op: 'days', a: toFri + 3, b: toFri + 7 }), o('Next 30 days', '', { f: 'ern', op: 'days', a: 0, b: 30 })]; })()],
    ['rern', 'Recent earnings', 'Recent earnings date', null, (() => { const d = dow(); return [o('Today', '', { f: 'rern', op: 'days', a: 0, b: 0 }), o('Previous day', '', { f: 'rern', op: 'days', a: d === 1 ? -3 : -1, b: -1 }), o('Previous 5 days', '', { f: 'rern', op: 'days', a: -7, b: 0 }), o('This week', '', { f: 'rern', op: 'days', a: -Math.max(0, d - 1), b: 0 }), o('Previous 30 days', '', { f: 'rern', op: 'days', a: -30, b: 0 })]; })()]
  ];

  // ---------- TradingView's preset screens, built on the same fields ----------
  const PRESETS = [
    ['All stocks', {}, { sort: ['mcap', -1] }],
    ['Most capitalized', { mcap: gt('mcap', 10 * B) }, { sort: ['mcap', -1] }],
    ['Highest net income', { mcap: gt('mcap', 10 * B) }, { sort: ['ni', -1], cols: 'Income statement' }],
    ['Highest cash', { mcap: gt('mcap', 10 * B) }, { sort: ['cash', -1], cols: 'Balance sheet' }],
    ['Close to new-high and undervalued', { mcap: gt('mcap', 750 * M), pe: lt('pe', 20), epsG: gt('epsG', 25), x_offHi: btw('offHi', 0, 10) }, { sort: ['mcap', -1] }],
    ['Healthy growth technology stocks', { mcap: gt('mcap', 1 * B), revG: gt('revG', 30), x_fcfM: gt('fcfM', 0), sector: { f: 'sector', op: 'in', a: ['Information Technology'] } }, { sort: ['revG', -1] }],
    ['High capital efficiency stocks', { epsG: gt('epsG', 15), roe: gt('roe', 30), x_roic: gt('roic', 20), x_roa: gt('roa', 15) }, { sort: ['roe', -1], cols: 'Profitability' }],
    ['Strong performance small caps', { chg: gt('chg', 7), mcap: lt('mcap', 1 * B), epsG: gt('epsG', 25), x_eps: gt('eps', 0) }, { sort: ['chg', -1] }],
    ['Debt reduction and business growth', { revG: gt('revG', 15), x_debtG: lt('debtG', -15), x_de: lt('de', 1), x_ebitdaG: gt('ebitdaG', 15) }, { sort: ['revG', -1] }],
    ['Dividend growers', { mcap: gt('mcap', 1 * B), x_divGrowYrs: { f: 'divGrowYrs', op: 'ge', a: 10 }, x_payout: btw('payout', 0, 80) }, { sort: ['divGrowYrs', -1], cols: 'Dividends', note: 'Counts years of dividend raises in SEC filings, which go back to 2009, so streaks top out around 15 years. Use this in place of Dividend princes and kings.' }],
    ['Bullish and undervalued', { pe: lt('pe', 20), epsG: gt('epsG', 25), revG: gt('revG', 15), peg: lt('peg', 1), x_ps: lt('ps', 2) }, { sort: ['peg', 1], cols: 'Valuation' }],
    ['Large, efficient and innovative', { mcap: gt('mcap', 10 * B), x_rdr: gt('rdr', 5) }, { sort: ['rdr', -1], cols: 'Profitability', note: 'Revenue per employee is left out: no free source has employee counts.' }],
    ['Doubled', { mcap: gt('mcap', 10 * B), perf: gt('p1y', 100) }, { sort: ['p1y', -1], cols: 'Performance' }]
  ];

  // ---------- column sets ----------
  const SETS = {
    Overview: ['px', 'chg', 'vol', 'relVol', 'mcap', 'pe', 'eps', 'epsG', 'div', 'sector', 'ern'],
    Performance: ['px', 'chg', 'p1w', 'p1m', 'p3m', 'p6m', 'pytd', 'p1y', 'vol1m', 'volat'],
    Technicals: ['px', 'rsi', 'macd', 'macdSig', 'adx', 'atrPct', 'stochK', 'cci', 'vsEma50', 'vsSma200', 'bbPos'],
    Valuation: ['mcap', 'pe', 'peg', 'ps', 'pb', 'pcf', 'pfcf', 'ev', 'evEbitda', 'evRev', 'ey'],
    Dividends: ['px', 'div', 'dps', 'payout', 'dpsG', 'divGrowYrs', 'divYrs'],
    Profitability: ['gm', 'om', 'nm', 'fcfM', 'roa', 'roe', 'roic', 'rdr'],
    'Income statement': ['rev', 'revG', 'gp', 'op', 'ni', 'niG', 'ebitda', 'ebitdaG', 'eps', 'epsG'],
    'Balance sheet': ['assets', 'assetsG', 'cash', 'debt', 'debtG', 'netDebt', 'equity', 'cr', 'de'],
    'Cash flow': ['ocf', 'icf', 'fin', 'capex', 'fcf', 'fcfG'],
    'Per share': ['px', 'revSh', 'eps', 'fcfSh', 'bookSh', 'cashSh', 'debtSh']
  };
  const SHORT = { px: 'Price', chg: 'Chg %', vol: 'Volume', relVol: 'Rel vol', mcap: 'Mkt cap', pe: 'P/E', eps: 'EPS dil', epsG: 'EPS growth', div: 'Div yield', sector: 'Sector', ern: 'Earnings',
    p1w: '1W', p1m: '1M', p3m: '3M', p6m: '6M', pytd: 'YTD', p1y: '1Y', vol1m: 'Volatility 1M', volat: 'Volatility 1D', rsi: 'RSI 14', macd: 'MACD', macdSig: 'Signal', adx: 'ADX', atrPct: 'ATR %', stochK: 'Stoch %K', cci: 'CCI 20', vsEma50: 'vs EMA 50', vsSma200: 'vs SMA 200', bbPos: 'BB %B',
    peg: 'PEG', ps: 'P/S', pb: 'P/B', pcf: 'P/CF', pfcf: 'P/FCF', ev: 'EV', evEbitda: 'EV/EBITDA', evRev: 'EV/Rev', ey: 'Earn yield', dps: 'Div/share', payout: 'Payout', dpsG: 'DPS growth', divGrowYrs: 'Yrs growing', divYrs: 'Yrs paying',
    gm: 'Gross margin', om: 'Op margin', nm: 'Net margin', fcfM: 'FCF margin', roa: 'ROA', roe: 'ROE', roic: 'ROIC', rdr: 'R&D ratio', rev: 'Revenue', revG: 'Rev growth', gp: 'Gross profit', op: 'Op income', ni: 'Net income', niG: 'NI growth', ebitda: 'EBITDA', ebitdaG: 'EBITDA growth',
    assets: 'Total assets', assetsG: 'Assets growth', cash: 'Cash', debt: 'Total debt', debtG: 'Debt growth', netDebt: 'Net debt', equity: 'Equity', cr: 'Current ratio', de: 'Debt/equity', ocf: 'Operating CF', icf: 'Investing CF', fin: 'Financing CF', capex: 'CapEx', fcf: 'FCF', fcfG: 'FCF growth',
    revSh: 'Revenue/sh', fcfSh: 'FCF/sh', bookSh: 'Book/sh', cashSh: 'Cash/sh', debtSh: 'Debt/sh' };
  const head = (k) => SHORT[k] || (FM[k] ? FM[k][1] : k);
  const signed = new Set(['chg', 'chgAbs', 'gap', 'chgOpen', 'p1w', 'p1m', 'p3m', 'p6m', 'pytd', 'p1y', 'epsG', 'revG', 'niG', 'gpG', 'ebitdaG', 'fcfG', 'capexG', 'dpsG', 'vsEma50', 'vsSma200', 'macd', 'assetsG', 'debtG']);

  // ---------- state ----------
  const saved = (U() && U().store(KEY)) || {};
  const st = { preset: saved.preset || 'All stocks', flt: saved.flt || {}, extra: saved.extra || [], cols: saved.cols || 'Overview', sort: saved.sort || ['mcap', -1], view: saved.view || 'Table', open: null, add: false, cat: 'Market data', q: '', man: null, mine: saved.mine || [], note: '' };
  const persist = () => U().store(KEY, { preset: st.preset, flt: st.flt, extra: st.extra, cols: st.cols, sort: st.sort, view: st.view, mine: st.mine });
  const applyPreset = (name) => {
    const p = PRESETS.find((x) => x[0] === name); if (!p) return;
    st.preset = name; st.flt = {}; st.extra = [];
    Object.keys(p[1]).forEach((k) => { if (k.startsWith('x_')) st.extra.push({ f: k.slice(2), flt: p[1][k] }); else st.flt[k] = Object.assign({ label: lbl(p[1][k]) }, p[1][k]); });
    st.sort = p[2].sort || ['mcap', -1]; if (p[2].cols) st.cols = p[2].cols; st.note = p[2].note || '';
  };
  const n2 = (v, f) => { const t = FM[f] ? FM[f][2] : 'num'; return t === 'money' ? U().fmt.money(v) : (Math.round(v * 100) / 100) + (/pct/.test(t) ? '%' : ''); };
  const lbl = (x) => {
    if (!x) return '';
    if (x.op === 'in' || x.op === 'has') return x.a.length > 1 ? x.a.length + ' picked' : x.a[0];
    switch (x.op) { case 'gt': return '> ' + n2(x.a, x.f); case 'ge': return '≥ ' + n2(x.a, x.f); case 'lt': return '< ' + n2(x.a, x.f); case 'le': return '≤ ' + n2(x.a, x.f); case 'btw': return n2(x.a, x.f) + ' to ' + n2(x.b, x.f); case 'out': return 'outside ' + n2(x.a, x.f) + '–' + n2(x.b, x.f); case 'eq': return '= ' + n2(x.a, x.f); case 'gtf': return '> ' + head(x.a); case 'ltf': return '< ' + head(x.a); default: return ''; }
  };

  // ---------- rendering ----------
  let host = null, unsub = null, last = null;
  const esc = (s) => U().esc(s);
  const caret = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#8796A3" stroke-width="2" aria-hidden="true"><path d="M6 9l6 6 6-6"></path></svg>';
  const OPS = [['gt', 'Above'], ['ge', 'Above or equal'], ['lt', 'Below'], ['le', 'Below or equal'], ['btw', 'Between'], ['out', 'Outside'], ['eq', 'Equal']];
  const manual = (id, field) => {
    const m = st.man && st.man.id === id ? st.man : { id, op: 'gt', a: '', b: '' };
    const money = FM[field] && FM[field][2] === 'money';
    return '<div class="xs-man"><span class="xs-cap">MANUAL SETUP</span><div class="xs-manrow"><label>Condition<select data-man="op" data-id="' + id + '">' + OPS.map(([k, l]) => '<option value="' + k + '"' + (m.op === k ? ' selected' : '') + '>' + l + '</option>').join('') + '</select></label>' +
      '<label>' + (money ? 'Value ($, 10B / 750M ok)' : 'Value') + '<input type="text" data-man="a" data-id="' + id + '" value="' + esc(m.a) + '" placeholder="' + (money ? '10B' : '0') + '"></label>' + (m.op === 'btw' || m.op === 'out' ? '<label>and<input type="text" data-man="b" data-id="' + id + '" value="' + esc(m.b) + '"></label>' : '') + '</div>' +
      '<button type="button" class="xs-apply" data-apply="' + id + '" data-field="' + field + '">Apply</button></div>';
  };
  const parseV = (s) => { const m = /^\s*(-?[\d.]+)\s*([kmbt])?\s*%?\s*$/i.exec(String(s).replace(/,/g, '').replace('−', '-')); if (!m) return NaN; return +m[1] * ({ k: 1e3, m: 1e6, b: 1e9, t: 1e12 }[(m[2] || '').toLowerCase()] || 1); };

  const pillsHtml = () => PILLS().map(([id, label, title, field, opts, multi]) => {
    const cur = st.flt[id]; const on = !!cur; const open = st.open === id;
    let pop = '';
    if (open) {
      pop = '<div class="xs-pop" role="listbox" aria-label="' + esc(title) + '"' + (multi ? ' aria-multiselectable="true"' : '') + '><div class="xs-pt">' + esc(title) + '</div>' +
        (!opts.length ? '<p class="xs-none">' + (id === 'wl' ? 'No watchlists yet. Make one on the Watchlist page.' : 'Nothing to pick.') + '</p>' : '') +
        opts.map((x, i) => { const sel = multi ? !!(cur && cur.a && x.flt.a.every((v) => cur.a.includes(v))) : !!(cur && cur.label === x.label); return '<button type="button" role="option" class="xs-opt" data-pill="' + id + '" data-i="' + i + '" aria-selected="' + sel + '"><span>' + (multi ? '<span class="xs-chk">' + (sel ? '✓' : '') + '</span>' : '') + esc(x.label) + '</span><span class="xs-osub">' + esc(x.sub || '') + '</span></button>'; }).join('') +
        (field ? manual(id, field) : '') + (on ? '<button type="button" class="xs-clear" data-clear="' + id + '">Clear this filter</button>' : '') + '</div>';
    }
    return '<div class="xs-pw"><button type="button" class="xs-pill' + (on ? ' xs-on' : '') + '" data-open="' + id + '" aria-expanded="' + open + '">' + esc(label) + (on ? '<span class="xs-pv">' + esc(cur.label) + '</span>' : '') + caret + '</button>' + pop + '</div>';
  }).join('');

  const extraHtml = () => st.extra.map((e, i) => {
    const id = 'x' + i; const open = st.open === id;
    return '<div class="xs-pw"><button type="button" class="xs-pill' + (e.flt ? ' xs-on' : '') + '" data-open="' + id + '" aria-expanded="' + open + '">' + esc(FM[e.f] ? FM[e.f][1] : e.f) + (e.flt ? '<span class="xs-pv">' + esc(lbl(e.flt)) + '</span>' : '') + caret + '</button>' +
      (open ? '<div class="xs-pop"><div class="xs-pt">' + esc(FM[e.f] ? FM[e.f][1] : e.f) + '</div>' + manual(id, e.f) + '<button type="button" class="xs-clear" data-rmx="' + i + '">Remove filter</button></div>' : '') + '</div>';
  }).join('');

  const addHtml = () => {
    if (!st.add) return '';
    const q = st.q.toLowerCase();
    const list = F.filter((f) => !['sector', 'ern', 'rern'].includes(f[0]) && (q ? f[1].toLowerCase().includes(q) : f[3] === st.cat));
    return '<div class="xs-add" role="dialog" aria-label="Add filter"><div class="xs-cats"><input type="text" class="xs-q" placeholder="Search filters" aria-label="Search filters" value="' + esc(st.q) + '">' +
      CATS.map((c) => '<button type="button" class="xs-cat" data-cat="' + esc(c) + '" aria-pressed="' + (st.cat === c && !q) + '">' + esc(c) + '<span>' + F.filter((f) => f[3] === c && !['sector', 'ern', 'rern'].includes(f[0])).length + '</span></button>').join('') + '</div>' +
      '<div class="xs-items">' + list.map((f) => '<button type="button" class="xs-item" data-addf="' + f[0] + '">' + esc(f[1]) + '</button>').join('') + (list.length ? '' : '<p class="xs-none">No filter by that name.</p>') + '</div></div>';
  };

  const filtered = () => {
    if (!last) return [];
    const all = Object.values(st.flt).concat(st.extra.map((e) => e.flt).filter(Boolean));
    let rows = last.rows.filter((r) => all.every((x) => test(r, x)));
    const [k, dir] = st.sort;
    rows = rows.slice().sort((a, b) => { const x = a[k], y = b[k]; const nx = x === null || x === undefined || x === '', ny = y === null || y === undefined || y === ''; if (nx && ny) return 0; if (nx) return 1; if (ny) return -1; return (typeof x === 'string' ? x.localeCompare(y) : x - y) * dir; });
    return rows;
  };

  const tableHtml = (rows) => {
    const cols = SETS[st.cols] || SETS.Overview;
    const th = (k, l, left) => { const on = st.sort[0] === k; return '<th scope="col" class="' + (left ? 'xs-l' : '') + '" aria-sort="' + (on ? (st.sort[1] > 0 ? 'ascending' : 'descending') : 'none') + '"><button type="button" data-sort="' + k + '">' + esc(l) + (on ? (st.sort[1] > 0 ? ' ▲' : ' ▼') : '') + '</button></th>'; };
    const max = 600;
    return '<div class="xs-tw"><table class="xs-t"><thead><tr>' + th('sym', 'Symbol', true) + cols.map((k) => th(k, head(k), k === 'sector')).join('') + '</tr></thead><tbody>' +
      rows.slice(0, max).map((r) => '<tr data-row="' + esc(r.sym) + '" tabindex="0"><td class="xs-l xs-sym"><b>' + esc(r.sym) + '</b>' + (r.name && r.name !== r.sym ? '<span>' + esc(r.name) + '</span>' : '') + '</td>' + cols.map((k) => {
        const v = r[k]; const c = signed.has(k) && Number.isFinite(v) ? (v > 0 ? ' xs-up' : v < 0 ? ' xs-dn' : '') : '';
        return '<td class="' + (k === 'sector' ? 'xs-l xs-sec' : '') + c + '">' + (k === 'ern' && r.ernWhen && r.ern ? show(k, v) + ' <small>' + esc(r.ernWhen) + '</small>' : show(k, v)) + '</td>';
      }).join('') + '</tr>').join('') + '</tbody></table>' + (rows.length > max ? '<p class="xs-more">Showing the first ' + max + ' of ' + rows.length + '. Add a filter to narrow it down.</p>' : '') + (rows.length ? '' : '<p class="xs-none xs-pad">No stocks match these filters right now.</p>') + '</div>';
  };

  const render = () => {
    if (!host) return;
    const rows = filtered(); const s = (last && last.status) || {};
    const keep = host.querySelector('.xs-q') === document.activeElement;
    const myOpen = st.open === 'mine';
    host.innerHTML =
      '<div class="xh-top"><h1 class="xh-h1">' + esc(st.preset) + '</h1><span class="xh-sub">' + (last ? rows.length + ' of ' + last.rows.length + ' stocks' : 'Loading…') + '</span>' +
      '<div class="xh-tools"><div class="xh-seg" role="group" aria-label="View">' + ['Table', 'Heatmap'].map((v) => '<button type="button" data-view="' + v + '" aria-pressed="' + (st.view === v) + '">' + v + '</button>').join('') + '</div>' +
      '<div class="xs-pw"><button type="button" class="xs-btn" data-open="mine" aria-expanded="' + myOpen + '">My screens ' + caret + '</button>' + (myOpen ? '<div class="xs-pop xs-popr"><div class="xs-pt">Saved screens</div>' + (st.mine.length ? st.mine.map((m, i) => '<div class="xs-mrow"><button type="button" class="xs-opt" data-load="' + i + '">' + esc(m.name) + '</button><button type="button" class="xs-x" data-del="' + i + '" aria-label="Delete ' + esc(m.name) + '">×</button></div>').join('') : '<p class="xs-none">Nothing saved yet.</p>') + '<div class="xs-man"><label>Save this screen as<input type="text" class="xs-sname" placeholder="My screen"></label><button type="button" class="xs-apply" data-save="1">Save screen</button></div></div>' : '') + '</div>' +
      '<button type="button" class="xs-btn" data-csv="1">Export CSV</button></div></div>' +
      '<div class="xs-presets" role="tablist" aria-label="Preset screens">' + PRESETS.map((p) => '<button type="button" role="tab" data-preset="' + esc(p[0]) + '" aria-selected="' + (st.preset === p[0]) + '">' + esc(p[0]) + '</button>').join('') + '</div>' +
      '<div class="xs-pills">' + pillsHtml() + extraHtml() + '<div class="xs-pw"><button type="button" class="xs-plus" data-addbtn="1" aria-expanded="' + st.add + '" aria-label="Add filter">+</button>' + addHtml() + '</div>' +
      (Object.keys(st.flt).length || st.extra.length ? '<button type="button" class="xs-reset" data-reset="1">Reset</button>' : '') + '</div>' +
      (st.note ? '<p class="xs-note">' + esc(st.note) + '</p>' : '') +
      (st.view === 'Table' ? '<div class="xs-sets" role="tablist" aria-label="Columns">' + Object.keys(SETS).map((k) => '<button type="button" role="tab" data-cols="' + esc(k) + '" aria-selected="' + (st.cols === k) + '">' + esc(k) + '</button>').join('') + '</div>' + tableHtml(rows)
        : '<div class="xh-map xs-hm" id="xs-map"></div><div class="xh-foot"><div class="xh-leg" id="xs-leg"></div><span class="xh-hint">Colored by today\'s change, sized by market cap. Click a tile to open its chart.</span></div>') +
      '<p class="xs-src">Prices and volume: your broker, live. Technicals and performance: daily candles from your broker' + (s.total ? ' (' + s.techDone + ' of ' + s.total + ' loaded)' : '') + '. Financials: each company\'s latest annual SEC filing' + (s.fundYear ? ' (calendar ' + s.fundYear + ')' : s.fundLoading ? ' (loading…)' : '') + ', balance sheet from the latest quarter. Earnings dates: Nasdaq. Index members: Wikipedia. Pre/post-market, analyst ratings and forecasts are left out (no free source).</p>';
    if (st.view === 'Heatmap') {
      const map = host.querySelector('#xs-map');
      requestAnimationFrame(() => { const r0 = window.XRHeat.draw(map, rows, { size: 'mcap', color: 'chg', group: 'sector' }); if (!r0 || !r0.count) map.innerHTML = '<p class="xh-empty">' + (rows.length ? 'Waiting for prices and market caps…' : 'No stocks match these filters right now.') + '</p>'; host.querySelector('#xs-leg').innerHTML = window.XRHeat.legend('div', 3).map(([b, l]) => '<span class="xh-lb" style="background:' + window.XRHeat.colorOf(b, 'div') + '">' + l + '</span>').join(''); });
    }
    if (keep) { const q = host.querySelector('.xs-q'); if (q) { q.focus(); q.setSelectionRange(q.value.length, q.value.length); } }
  };

  const csv = () => {
    const rows = filtered(); const cols = ['sym', 'name'].concat(SETS[st.cols] || SETS.Overview);
    const cell = (v) => { if (v === null || v === undefined) return ''; const s = typeof v === 'number' ? String(Math.round(v * 1e4) / 1e4) : String(v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
    const txt = [cols.map((k) => cell(k === 'sym' ? 'Symbol' : k === 'name' ? 'Name' : FM[k] ? FM[k][1] : k)).join(',')].concat(rows.map((r) => cols.map((k) => cell(r[k])).join(','))).join('\n');
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([txt], { type: 'text/csv' })); a.download = st.preset.replace(/[^\w -]/g, '') + ' ' + today() + '.csv'; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  };

  const close = () => { st.open = null; st.add = false; st.man = null; };
  const onClick = (e) => {
    const t = e.target.closest('button, tr[data-row]');
    if (!t || !host.contains(t)) return;
    const d = t.dataset;
    if (d.row) { U().open(d.row); return; }
    if (d.preset) { applyPreset(d.preset); close(); persist(); render(); return; }
    if (d.view) { st.view = d.view; persist(); render(); return; }
    if (d.cols) { st.cols = d.cols; persist(); render(); return; }
    if (d.sort) { st.sort = st.sort[0] === d.sort ? [d.sort, -st.sort[1]] : [d.sort, ['sym', 'sector', 'ern'].includes(d.sort) ? 1 : -1]; persist(); render(); return; }
    if (d.open) { const was = st.open; close(); st.open = was === d.open ? null : d.open; render(); return; }
    if (d.addbtn) { const was = st.add; close(); st.add = !was; render(); return; }
    if (d.cat) { st.cat = d.cat; st.q = ''; render(); return; }
    if (d.addf) { st.extra.push({ f: d.addf, flt: null }); close(); st.open = 'x' + (st.extra.length - 1); persist(); render(); return; }
    if (d.rmx !== undefined) { st.extra.splice(+d.rmx, 1); close(); st.preset = 'Custom screen'; persist(); render(); return; }
    if (d.clear) { delete st.flt[d.clear]; close(); st.preset = 'Custom screen'; persist(); render(); return; }
    if (d.reset) { applyPreset('All stocks'); close(); persist(); render(); return; }
    if (d.csv) { csv(); return; }
    if (d.pill) {
      const P = PILLS().find((p) => p[0] === d.pill); const x = P[4][+d.i]; if (!x) return;
      if (P[5]) {
        const cur = st.flt[d.pill]; let a = cur && cur.a ? cur.a.slice() : [];
        const v = x.flt.a[0]; a = a.includes(v) ? a.filter((y) => y !== v) : a.concat(v);
        if (a.length) st.flt[d.pill] = Object.assign({}, x.flt, { a, label: a.length > 1 ? a.length + ' picked' : (P[0] === 'idx' ? (U().INDEXES.find((i) => i[0] === a[0]) || [0, a[0]])[1] : a[0]) }); else delete st.flt[d.pill];
      } else { st.flt[d.pill] = Object.assign({ label: x.label }, x.flt); st.open = null; }
      st.preset = 'Custom screen'; persist(); render(); return;
    }
    if (d.apply) {
      const m = st.man && st.man.id === d.apply ? st.man : null; const op = (host.querySelector('select[data-id="' + d.apply + '"]') || {}).value || 'gt';
      const ai = host.querySelector('input[data-man="a"][data-id="' + d.apply + '"]'), bi = host.querySelector('input[data-man="b"][data-id="' + d.apply + '"]');
      const a = parseV(ai ? ai.value : m && m.a), b = parseV(bi ? bi.value : m && m.b);
      if (!Number.isFinite(a) || ((op === 'btw' || op === 'out') && !Number.isFinite(b))) { U().toast('Type a number, like 20, 2.5 or 10B'); return; }
      const flt = { f: d.field, op, a: op === 'btw' || op === 'out' ? Math.min(a, b) : a, b: Math.max(a, b) }; flt.label = lbl(flt);
      if (d.apply.startsWith('x')) st.extra[+d.apply.slice(1)].flt = flt; else st.flt[d.apply] = flt;
      close(); st.preset = 'Custom screen'; persist(); render(); return;
    }
    if (d.save) { const nm = (host.querySelector('.xs-sname') || {}).value || ''; const name = nm.trim() || 'Screen ' + (st.mine.length + 1); st.mine = st.mine.filter((m) => m.name !== name).concat({ name, flt: st.flt, extra: st.extra, cols: st.cols, sort: st.sort }); st.preset = name; close(); persist(); render(); U().toast('Saved "' + name + '"'); return; }
    if (d.load !== undefined) { const m = st.mine[+d.load]; if (m) { st.flt = JSON.parse(JSON.stringify(m.flt)); st.extra = JSON.parse(JSON.stringify(m.extra || [])); st.cols = m.cols; st.sort = m.sort; st.preset = m.name; st.note = ''; } close(); persist(); render(); return; }
    if (d.del !== undefined) { st.mine.splice(+d.del, 1); persist(); render(); return; }
  };
  const onInput = (e) => {
    const t = e.target;
    if (t.classList.contains('xs-q')) { st.q = t.value; render(); return; }
    if (t.dataset.man) { const id = t.dataset.id; st.man = st.man && st.man.id === id ? st.man : { id, op: 'gt', a: '', b: '' }; st.man[t.dataset.man] = t.value; if (t.dataset.man === 'op') render(); }
  };
  const onKey = (e) => {
    if (!host) return;
    if (e.key === 'Escape' && (st.open || st.add)) { close(); render(); }
    if (e.key === 'Enter') { const tr = e.target.closest && e.target.closest('tr[data-row]'); if (tr && host.contains(tr)) U().open(tr.dataset.row); const inp = e.target.closest && e.target.closest('input[data-man]'); if (inp) { const b = host.querySelector('[data-apply="' + inp.dataset.id + '"]'); if (b) b.click(); } }
  };

  const fromHeat = () => {
    const h = U().store('xr-stocks-from-heat'); if (!h || Date.now() - h.at > 10000) return;
    U().store('xr-stocks-from-heat', null);
    applyPreset('All stocks'); st.preset = 'From heat map';
    if (h.src.startsWith('idx:')) st.flt.idx = { f: 'idx', op: 'has', a: [h.src.slice(4)], label: (U().INDEXES.find((i) => i[0] === h.src.slice(4)) || [0, h.src])[1] };
    else { const l = U().lists().find((x) => 'wl:' + x.id === h.src); if (l) st.flt.wl = { f: 'sym', op: 'syms', a: l.syms, label: l.name }; }
    st.sort = [h.sort, -1]; st.cols = ['chg', 'gap', 'relVol', 'volat'].includes(h.sort) ? 'Overview' : 'Performance'; st.view = 'Table'; persist();
  };

  const tick = () => {
    const h = document.getElementById('xr-stocks');
    if (h === host) return;
    if (host) { host.removeEventListener('click', onClick); host.removeEventListener('input', onInput); host.removeEventListener('change', onInput); }
    if (unsub) { unsub(); unsub = null; }
    host = h;
    if (host) {
      fromHeat();
      host.addEventListener('click', onClick); host.addEventListener('input', onInput); host.addEventListener('change', onInput);
      render(); unsub = U().sub((d) => { last = d; if (!st.open && !st.add) render(); });
    }
  };
  document.addEventListener('keydown', onKey);
  document.addEventListener('mousedown', (e) => { if (host && (st.open || st.add) && !(e.target.closest && e.target.closest('.xs-pw'))) { close(); render(); } });
  if (!saved.preset) { applyPreset('All stocks'); }
  else { const p = PRESETS.find((x) => x[0] === st.preset); if (p) st.note = p[2].note || ''; }
  setInterval(tick, 250);
})();
