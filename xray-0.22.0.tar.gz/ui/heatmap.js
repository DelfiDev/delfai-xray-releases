// Stock heat map (like TradingView's): every stock in the index as a tile sized by market cap (or volume), colored
// by today's change (or performance, relative volume, volatility, gap), grouped by sector. Live from /api/universe.
(() => {
  'use strict';
  const U = () => window.XRU;
  const KEY = 'xr-heat';

  // ---------- options (only metrics we have real data for) ----------
  const SIZE = [['mcap', 'Market cap'], ['vol', 'Volume 1D'], ['volW', 'Volume 1W'], ['volM', 'Volume 1M'], ['turnover', 'Turnover 1D'], ['turnW', 'Turnover 1W'], ['turnM', 'Turnover 1M'], ['eq', 'Equal size']];
  // [field, label, kind, scale]: kind 'div' = red/green around 0, 'rv' = around 1×, 'seq' = 0 and up
  const COLOR = [['chg', 'Change 1D %', 'div', 3], ['p1w', 'Performance 1W %', 'div', 6], ['p1m', 'Performance 1M %', 'div', 10], ['p3m', 'Performance 3M %', 'div', 20], ['p6m', 'Performance 6M %', 'div', 30], ['pytd', 'Performance YTD %', 'div', 30], ['p1y', 'Performance 1Y %', 'div', 30], ['relVol', 'Relative volume', 'rv', 3], ['volat', 'Volatility 1D %', 'seq', 6], ['gap', 'Gap %', 'div', 3]];
  const GROUP = [['sector', 'Sector'], ['none', 'No group']];

  const GREY = '#414554';
  // seven buckets like TradingView's legend: -3 -2 -1 0 +1 +2 +3 (scaled per metric)
  const bucket = (v, kind, sc) => {
    if (!Number.isFinite(v)) return -1;
    if (kind === 'rv') { const s = [0.5, 0.8, 1.2, 1.6, 2.2, sc]; return v < s[0] ? 0 : v < s[1] ? 1 : v < s[2] ? 3 : v < s[3] ? 4 : v < s[4] ? 5 : 6; }
    if (kind === 'seq') { const st = sc / 3; return v < st * 0.5 ? 3 : v < st ? 4 : v < st * 2 ? 5 : 6; }
    const st = sc / 3; return v <= -3 * st ? 0 : v <= -2 * st ? 1 : v <= -st ? 2 : v < st ? 3 : v < 2 * st ? 4 : v < 3 * st ? 5 : 6;
  };
  const BCOL = ['#F63538', '#BF4045', '#8B444E', GREY, '#35764E', '#2F9E4F', '#30CC5A'];
  // smooth color between the legend stops (like TradingView's), so +0.4% reads faintly green, not grey
  const hex = (c) => [1, 3, 5].map((i) => parseInt(c.slice(i, i + 2), 16));
  const mix = (a, b, t) => { const A = hex(a), Bc = hex(b); return 'rgb(' + A.map((x, i) => Math.round(x + (Bc[i] - x) * t)).join(',') + ')'; };
  const smooth = (v, kind, sc) => {
    if (!Number.isFinite(v)) return '#262D38';
    if (kind === 'rv') { const x = Math.max(0, Math.min(6, (v - 1) / (sc - 1) * 3 + 3)); const i = Math.min(5, Math.floor(x)); return mix(BCOL[i], BCOL[i + 1], x - i); }
    if (kind === 'seq') { const x = Math.max(0, Math.min(3, v / (sc / 3) / 2 * 3)); const i = Math.min(2, Math.floor(x)); return mix(SEQ[3 + i], SEQ[4 + i], x - i); }
    const x = Math.max(0, Math.min(6, v / (sc / 3) + 3)); const i = Math.min(5, Math.floor(x)); return mix(BCOL[i], BCOL[i + 1], x - i);
  };
  const SEQ = ['', '', '', '#3A4A5E', '#2D6A9F', '#2F86C9', '#4FB0F0'];
  const colorOf = (b, kind) => (b < 0 ? '#262D38' : kind === 'seq' ? SEQ[b] : BCOL[b]);
  const legend = (kind, sc) => {
    if (kind === 'rv') return ['< 0.5×', '0.5×', '', '1×', '1.6×', '2.2×', '> ' + sc + '×'].map((l, i) => [i, l]).filter((x) => x[1]);
    if (kind === 'seq') { const st = sc / 3; return [[3, '< ' + (st * 0.5).toFixed(1) + '%'], [4, (st * 0.5).toFixed(1) + '%'], [5, st.toFixed(1) + '%'], [6, '> ' + (st * 2).toFixed(1) + '%']]; }
    const st = sc / 3; const f = (x) => (x > 0 ? '+' : x < 0 ? '−' : '') + Math.abs(x).toFixed(st < 1 ? 1 : 0) + '%';
    return [[0, f(-3 * st)], [1, f(-2 * st)], [2, f(-st)], [3, '0%'], [4, f(st)], [5, f(2 * st)], [6, f(3 * st)]];
  };

  // ---------- squarified treemap ----------
  const squarify = (items, x, y, w, h) => {
    const out = []; const total = items.reduce((a, it) => a + it.w, 0); if (!total || w <= 0 || h <= 0) return out;
    const scale = w * h / total; let rest = items.map((it) => ({ it, a: it.w * scale })).filter((r) => r.a > 0);
    const worst = (row, side) => { const s = row.reduce((a, r) => a + r.a, 0); let mx = 0, mn = Infinity; row.forEach((r) => { mx = Math.max(mx, r.a); mn = Math.min(mn, r.a); }); return Math.max(side * side * mx / (s * s), s * s / (side * side * mn)); };
    while (rest.length) {
      const side = Math.min(w, h); let row = [rest[0]], i = 1;
      while (i < rest.length && worst(row.concat(rest[i]), side) <= worst(row, side)) { row.push(rest[i]); i++; }
      const s = row.reduce((a, r) => a + r.a, 0);
      if (w >= h) { const cw = s / h; let cy = y; row.forEach((r) => { const ch = r.a / cw; out.push({ it: r.it, x, y: cy, w: cw, h: ch }); cy += ch; }); x += cw; w -= cw; }
      else { const rh = s / w; let cx = x; row.forEach((r) => { const cw = r.a / rh; out.push({ it: r.it, x: cx, y, w: cw, h: rh }); cx += cw; }); y += rh; h -= rh; }
      rest = rest.slice(i);
    }
    return out;
  };

  // ---------- drawing (also used by the screener's Heatmap view) ----------
  // rows: universe rows; o: { size, color, group, zoom, band, onHover, onZoom }
  const draw = (box, rows, o) => {
    const esc = U().esc, fmt = U().fmt;
    const C = COLOR.find((c) => c[0] === o.color) || COLOR[0];
    const W = box.clientWidth, H = box.clientHeight; if (W < 50 || H < 50) return;
    const wt = (r) => (o.size === 'eq' ? 1 : Number.isFinite(r[o.size]) && r[o.size] > 0 ? r[o.size] : 0);
    const live = rows.filter((r) => wt(r) > 0);
    let groups;
    if (o.group === 'sector') {
      const m = {}; live.forEach((r) => { const g = r.sector || 'Other'; (m[g] = m[g] || []).push(r); });
      groups = Object.keys(m).map((name) => ({ name, rows: m[name], w: m[name].reduce((a, r) => a + wt(r), 0) }));
      if (o.zoom) groups = groups.filter((g) => g.name === o.zoom);
    } else groups = [{ name: '', rows: live, w: live.reduce((a, r) => a + wt(r), 0) }];
    groups.sort((a, b) => b.w - a.w);
    const html = [];
    const gl = squarify(groups.map((g) => ({ w: g.w, g })), 0, 0, W, H);
    gl.forEach((G) => {
      const g = G.it.g; const head = g.name && G.h > 34 && G.w > 60 ? 17 : 0; const pad = g.name ? 1 : 0;
      if (g.name) html.push('<div class="xh-sec" data-sec="' + esc(g.name) + '" style="left:' + G.x + 'px;top:' + G.y + 'px;width:' + G.w + 'px;height:' + G.h + 'px">' + (head ? '<button type="button" class="xh-sech" data-zoom="' + esc(g.name) + '" title="' + (o.zoom ? 'Back to all sectors' : 'Zoom into ' + esc(g.name)) + '">' + esc(g.name) + ' <span aria-hidden="true">' + (o.zoom ? '×' : '›') + '</span></button>' : '') + '</div>');
      const tiles = squarify(g.rows.slice().sort((a, b) => wt(b) - wt(a)).map((r) => ({ w: wt(r), r })), G.x + pad, G.y + head + pad, G.w - 2 * pad, G.h - head - 2 * pad);
      tiles.forEach((t) => {
        const r = t.it.r, v = r[C[0]], b = bucket(v, C[2], C[3]);
        const fs = Math.max(9, Math.min(40, Math.sqrt(t.w * t.h) / 5.2, t.w / (r.sym.length * 0.68)));
        const showSym = t.w > 24 && t.h > 14, showVal = t.w > 34 && t.h > fs * 2.3;
        const val = C[2] === 'rv' ? (Number.isFinite(v) ? v.toFixed(2) + '×' : '—') : C[2] === 'seq' ? fmt.pctPlain(v) : fmt.pct(v);
        const dim = o.band !== null && o.band !== undefined && b !== o.band;
        html.push('<button type="button" class="xh-tile' + (dim ? ' xh-dim' : '') + '" data-sym="' + esc(r.sym) + '" aria-label="' + esc(r.sym + ' ' + val) + '" style="left:' + (t.x + 1) + 'px;top:' + (t.y + 1) + 'px;width:' + Math.max(0, t.w - 2) + 'px;height:' + Math.max(0, t.h - 2) + 'px;background:' + smooth(v, C[2], C[3]) + '">' +
          (showSym ? '<span class="xh-s" style="font-size:' + fs.toFixed(1) + 'px">' + esc(r.sym) + '</span>' : '') + (showVal ? '<span class="xh-v" style="font-size:' + Math.max(9, fs * 0.62).toFixed(1) + 'px">' + val + '</span>' : '') + '</button>');
      });
    });
    box.innerHTML = html.join('');
    return { metric: C, count: live.length };
  };

  // ---------- the page ----------
  let host = null, unsub = null, last = null, built = false;
  const st = Object.assign({ src: 'SPX', size: 'mcap', color: 'chg', group: 'sector', zoom: null, band: null, open: null, hov: null }, U() ? U().store(KEY) || {} : {});
  st.open = null; st.band = null;
  const save = () => U().store(KEY, { src: st.src, size: st.size, color: st.color, group: st.group });

  const srcOpts = () => U().INDEXES.map(([k, l]) => ['idx:' + k, l]).concat(U().lists().map((l) => ['wl:' + l.id, 'Watchlist: ' + l.name]));
  const srcKey = () => (st.src.includes(':') ? st.src : 'idx:' + st.src);
  const pickRows = (rows) => {
    const k = srcKey();
    if (k.startsWith('wl:')) { const l = U().lists().find((x) => 'wl:' + x.id === k); const set = new Set(l ? l.syms : []); return rows.filter((r) => set.has(r.sym)); }
    const ix = k.slice(4); return rows.filter((r) => r.idx && r.idx.includes(ix));
  };
  const label = (list, v) => (list.find((x) => x[0] === v) || list[0])[1];

  const menu = (id, title, list, cur) => '<div class="xh-m"><button type="button" class="xh-mb" data-menu="' + id + '" aria-expanded="' + (st.open === id) + '"><span class="xh-ml">' + title + '</span>' + U().esc(label(list, cur)) + '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#8796A3" stroke-width="2" aria-hidden="true"><path d="M6 9l6 6 6-6"></path></svg></button>' +
    (st.open === id ? '<div class="xh-pop" role="listbox" aria-label="' + title + '">' + list.map(([k, l]) => '<button type="button" role="option" class="xh-opt" data-set="' + id + '" data-val="' + U().esc(k) + '" aria-selected="' + (k === cur) + '">' + U().esc(l) + '<span>' + (k === cur ? '✓' : '') + '</span></button>').join('') + '</div>' : '') + '</div>';

  const shell = () => {
    const S = srcOpts(); if (!S.some((x) => x[0] === srcKey())) st.src = 'SPX';
    host.innerHTML =
      '<div class="xh-top"><h1 class="xh-h1">Stock heat map</h1><span class="xh-sub" id="xh-count"></span>' +
      '<div class="xh-tools"><button type="button" class="xh-ib" data-act="snap" aria-label="Copy image" title="Copy image"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 8h3l2-3h6l2 3h3v11H4z"></path><circle cx="12" cy="13" r="3.5"></circle></svg></button>' +
      '<button type="button" class="xh-ib" data-act="full" aria-label="Full screen" title="Full screen"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"></path></svg></button>' +
      '<button type="button" class="xh-link" data-act="screener">Open in Screener</button></div></div>' +
      '<div class="xh-menus">' + menu('src', 'Universe', S, srcKey()) + menu('size', 'Size by', SIZE, st.size) + menu('color', 'Color by', COLOR.map((c) => [c[0], c[1]]), st.color) + menu('group', 'Group by', GROUP, st.group) + '</div>' +
      '<div class="xh-map" id="xh-map" role="group" aria-label="Heat map"></div>' +
      '<div class="xh-foot"><div class="xh-leg" id="xh-leg" role="group" aria-label="Color legend"></div><span class="xh-hint" id="xh-hint"></span><div class="xh-hov" id="xh-hov" aria-live="polite"></div></div>';
    built = true;
  };

  const hoverBar = () => {
    const el = host.querySelector('#xh-hov'); if (!el) return;
    const rows = last ? pickRows(last.rows) : []; const r = rows.find((x) => x.sym === st.hov);
    if (!r) { el.innerHTML = '<span class="xh-dimtxt">Hover a tile for details</span>'; return; }
    const C = COLOR.find((c) => c[0] === st.color) || COLOR[0]; const f = U().fmt, v = r[C[0]];
    const val = C[2] === 'rv' ? (Number.isFinite(v) ? v.toFixed(2) + '×' : '—') : C[2] === 'seq' ? f.pctPlain(v) : f.pct(v);
    const col = C[2] === 'div' && Number.isFinite(v) ? (v >= 0 ? '#34D399' : '#F2555A') : '#E8EEF2';
    el.innerHTML = '<b>' + U().esc(r.sym) + '</b><span class="xh-nm">' + U().esc(r.name) + '</span><span>' + f.px(r.px) + '</span><span class="xh-dimtxt">Mkt cap ' + f.money(r.mcap) + '</span><span style="color:' + col + '">' + val + '</span>';
  };

  const paint = () => {
    if (!host || !built) return;
    const map = host.querySelector('#xh-map'); const rows = last ? pickRows(last.rows) : [];
    const cnt = host.querySelector('#xh-count'), hint = host.querySelector('#xh-hint');
    if (!last) { map.innerHTML = '<p class="xh-empty">Loading the index from your broker…</p>'; return; }
    const s = last.status || {};
    if (!s.members) { map.innerHTML = '<p class="xh-empty">Could not load the index member list. Check your internet connection.</p>'; return; }
    const needCap = st.size === 'mcap' && !rows.some((r) => r.mcap > 0);
    const r0 = draw(map, rows, { size: st.size, color: st.color, group: st.group, zoom: st.zoom, band: st.band });
    if (!r0 || !r0.count) map.innerHTML = '<p class="xh-empty">' + (needCap ? 'Waiting for market caps (from your broker and SEC filings)…' : !rows.length ? 'No stocks in this list.' : 'Waiting for prices from your broker…') + '</p>';
    const C = COLOR.find((c) => c[0] === st.color) || COLOR[0];
    const techCol = !['chg', 'gap', 'volat'].includes(C[0]);
    cnt.textContent = (r0 ? r0.count : 0) + ' stocks' + (techCol && s.techDone < s.total ? ' · loading history ' + s.techDone + '/' + s.total : '');
    host.querySelector('#xh-leg').innerHTML = legend(C[2], C[3]).map(([b, l]) => '<button type="button" class="xh-lb" data-band="' + b + '" style="background:' + colorOf(b, C[2]) + '" title="Show only this range">' + l + '</button>').join('');
    hint.textContent = st.group === 'sector' ? (st.zoom ? 'Click the sector name to go back.' : 'Hover a color to light up only those names. Click a sector to zoom in.') : 'Hover a color to light up only those names.';
    hoverBar();
  };

  const onClick = (e) => {
    const t = e.target.closest('button'); if (!t || !host.contains(t)) return;
    if (t.dataset.menu) { st.open = st.open === t.dataset.menu ? null : t.dataset.menu; shell(); paint(); return; }
    if (t.dataset.set) { st[t.dataset.set] = t.dataset.val.startsWith('idx:') ? t.dataset.val.slice(4) : t.dataset.val; st.open = null; if (t.dataset.set === 'group' || t.dataset.set === 'src') st.zoom = null; save(); shell(); paint(); return; }
    if (t.dataset.zoom) { st.zoom = st.zoom ? null : t.dataset.zoom; paint(); return; }
    if (t.dataset.sym) { U().open(t.dataset.sym); return; }
    const a = t.dataset.act;
    if (a === 'snap') U().snapEl(host.querySelector('#xh-map').parentElement, U().toast);
    if (a === 'full') { const m = host; if (document.fullscreenElement) document.exitFullscreen(); else if (m.requestFullscreen) m.requestFullscreen().catch(() => {}); }
    if (a === 'screener') { U().store('xr-stocks-from-heat', { src: srcKey(), sort: st.color, at: Date.now() }); U().go('stocks'); }
  };
  const onOver = (e) => {
    const t = e.target.closest('.xh-tile'); if (t && t.dataset.sym !== st.hov) { st.hov = t.dataset.sym; hoverBar(); }
    const lb = e.target.closest('.xh-lb'); if (lb && String(st.band) !== lb.dataset.band) { st.band = +lb.dataset.band; paint(); }
    const sec = e.target.closest('.xh-sec, .xh-tile'); host.querySelectorAll('.xh-sec.xh-on').forEach((x) => x.classList.remove('xh-on'));
    if (sec && st.group === 'sector') { const r = last && last.rows.find((x) => x.sym === sec.dataset.sym); const name = sec.dataset.sec || (r && (r.sector || 'Other')); host.querySelectorAll('.xh-sec').forEach((x) => { if (x.dataset.sec === name) x.classList.add('xh-on'); }); }
  };
  const onOut = (e) => { if (e.target.closest('.xh-lb') && !(e.relatedTarget && e.relatedTarget.closest && e.relatedTarget.closest('.xh-lb'))) { st.band = null; paint(); } };
  const onKey = (e) => { if (e.key === 'Escape' && st.open) { st.open = null; shell(); paint(); } };

  let ro = null;
  const tick = () => {
    const h = document.getElementById('xr-heat');
    if (h !== host) {
      if (host) { host.removeEventListener('click', onClick); host.removeEventListener('mouseover', onOver); host.removeEventListener('mouseout', onOut); }
      if (ro) { ro.disconnect(); ro = null; }
      host = h; built = false;
      if (unsub) { unsub(); unsub = null; }
      if (host) {
        host.addEventListener('click', onClick); host.addEventListener('mouseover', onOver); host.addEventListener('mouseout', onOut);
        shell(); paint();
        unsub = U().sub((d) => { last = d; paint(); });
        ro = new ResizeObserver(() => paint()); ro.observe(host);
      }
    }
  };
  document.addEventListener('keydown', onKey);
  document.addEventListener('mousedown', (e) => { if (host && st.open && !(e.target.closest && e.target.closest('.xh-m'))) { st.open = null; shell(); paint(); } });
  setInterval(tick, 250);

  window.XRHeat = { draw, COLOR, SIZE, legend, colorOf };
})();
