(function () {
  const EV = { onclick: 'click', onmousedown: 'mousedown', onmousemove: 'mousemove', onmouseup: 'mouseup', onmouseleave: 'mouseleave', ondoubleclick: 'dblclick', onkeydown: 'keydown', onfocus: 'focus', onblur: 'blur' };
  const HOLE = /\{\{\s*([^}]+?)\s*\}\}/g;
  const SINGLE = /^\s*\{\{\s*([^}]+?)\s*\}\}\s*$/;
  function lookup(path, scope) {
    path = path.trim();
    if (path === 'true') return true; if (path === 'false') return false; if (path === 'null') return null;
    if (/^-?\d+(\.\d+)?$/.test(path)) return Number(path);
    if (/^'.*'$|^".*"$/.test(path)) return path.slice(1, -1);
    const parts = path.split('.');
    let v = scope;
    for (const p of parts) { if (v == null) return undefined; v = v[p]; }
    return v;
  }
  function interp(str, scope) { return str.replace(HOLE, (_, p) => { const v = lookup(p, scope); return v == null || v === false ? '' : String(v); }); }
  function bind(el, type, fn) {
    el._h = el._h || {}; el._b = el._b || {};
    el._h[type] = fn;
    if (!el._b[type]) { el._b[type] = true; el.addEventListener(type, (e) => { const f = el._h && el._h[type]; if (typeof f === 'function') f(e); }); }
  }
  function build(nodes, scope, out, ctx) {
    for (const n of nodes) {
      if (n.nodeType === 3) { out.appendChild(document.createTextNode(n.nodeValue.indexOf('{{') >= 0 ? interp(n.nodeValue, scope) : n.nodeValue)); continue; }
      if (n.nodeType !== 1) continue;
      const kids = n.content ? n.content.childNodes : n.childNodes;
      if (n.localName === 'template' && n.hasAttribute('data-scfor')) {
        const list = lookup(n.getAttribute('data-scfor'), scope) || [];
        const as = n.getAttribute('data-as');
        list.forEach((item, i) => { const s = Object.create(scope); s[as] = item; build(kids, s, out, ctx); });
        continue;
      }
      if (n.localName === 'template' && n.hasAttribute('data-scif')) {
        if (lookup(n.getAttribute('data-scif'), scope)) build(kids, scope, out, ctx);
        continue;
      }
      const el = n.namespaceURI === 'http://www.w3.org/1999/xhtml' ? document.createElement(n.localName) : document.createElementNS(n.namespaceURI, n.localName);
      const isImport = n.hasAttribute('data-dcimport');
      const props = {};
      const late = [];
      for (const a of Array.from(n.attributes)) {
        const name = a.name, val = a.value;
        const m = val.match(SINGLE);
        if (isImport && name !== 'data-dcimport' && !name.startsWith('hint-')) {
          const key = name.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
          props[key] = m ? lookup(m[1], scope) : val;
          continue;
        }
        if (EV[name] || name === 'onchange') {
          const fn = m ? lookup(m[1], scope) : null;
          let type = EV[name];
          if (name === 'onchange') type = (n.localName === 'input' && (n.getAttribute('type') === 'checkbox' || n.getAttribute('type') === 'radio')) || n.localName === 'select' ? 'change' : 'input';
          if (typeof fn === 'function') bind(el, type, fn);
          continue;
        }
        let v = m ? lookup(m[1], scope) : (val.indexOf('{{') >= 0 ? interp(val, scope) : val);
        if (name === 'value' || name === 'checked' || name === 'disabled') { late.push([name, v]); if (name !== 'value' && v) el.setAttribute(name, ''); continue; }
        if (v === false || v == null) continue;
        try { el.setAttributeNS(a.namespaceURI, name, v === true ? '' : String(v)); } catch (e) { }
      }
      if (isImport) { el.setAttribute('data-dcimport', n.getAttribute('data-dcimport')); ctx.imports.push({ el, name: n.getAttribute('data-dcimport'), props }); out.appendChild(el); continue; }
      if (n.localName === 'textarea') { /* value via property */ }
      else build(kids, scope, el, ctx);
      for (const [k, v] of late) { if (k === 'value') el.value = v == null ? '' : String(v); else el[k] = !!v; }
      out.appendChild(el);
    }
  }
  class DCLogic {
    constructor(props) { this.props = props || {}; this.state = {}; }
    setState(p) { if (typeof p === 'function') p = p(this.state, this.props); if (!p) return; this.state = Object.assign({}, this.state, p); this.__host && this.__host.schedule(); }
    forceUpdate() { this.__host && this.__host.schedule(); }
  }
  window.DCLogic = DCLogic;
  class Host {
    constructor(name, root, props) {
      this.name = name; this.root = root; this.children = {};
      this.tpl = document.getElementById('tpl-' + name).content.childNodes;
      const C = window.__C[name];
      this.c = new C(props || {}); this.c.__host = this;
      this.pending = false; this.mounted = false;
      this.render();
    }
    schedule() { if (this.pending) return; this.pending = true; requestAnimationFrame(() => { this.pending = false; this.render(); }); }
    render() {
      const vals = this.c.renderVals();
      const frag = document.createElement('div');
      const ctx = { imports: [] };
      build(this.tpl, vals, frag, ctx);
      if (!this.mounted) { while (frag.firstChild) this.root.appendChild(frag.firstChild); }
      else {
        const target = document.createElement('div');
        while (frag.firstChild) target.appendChild(frag.firstChild);
        morphdom(this.root, target, {
          childrenOnly: true,
          getNodeKey: (n) => (n && n.id) || (n && n.getAttribute && n.getAttribute('data-dcimport') ? 'dci:' + n.getAttribute('data-dcimport') : undefined),
          onBeforeElUpdated: (from, to) => {
            if (from.attributes) { for (const a of Array.from(from.attributes)) if (a.name.startsWith('data-xl') && !to.hasAttribute(a.name)) to.setAttribute(a.name, a.value); } // layout tags survive re-renders
            if (to._h) { for (const t in to._h) bind(from, t, to._h[t]); }
            if (from._h) { for (const t in from._h) if (!to._h || !(t in to._h)) from._h[t] = null; }
            if (from.hasAttribute && from.hasAttribute('data-keep')) return false; // 3D globe and other self-drawn widgets
            if (from.hasAttribute && from.hasAttribute('data-dcimport')) { /* keep child */
              for (const a of Array.from(to.attributes)) from.setAttribute(a.name, a.value);
              return false;
            }
            if (from.localName === 'input' && document.activeElement === from && !to.hasAttribute('value') && from.type !== 'checkbox' && from.type !== 'radio') {
              // a box the user is typing in that the app doesn't control (no value in the template): never wipe what they typed
              to.value = from.value;
            }
            return true;
          },
          onBeforeElChildrenUpdated: (from) => !(from.hasAttribute && (from.hasAttribute('data-dcimport') || from.hasAttribute('data-keep')))
        });
      }
      // child imports
      for (const k in this.children) { const ch = this.children[k]; if (!ch.root.isConnected) { ch.c.componentWillUnmount && ch.c.componentWillUnmount(); ch.c.__host = null; delete this.children[k]; } }
      const live = this.root.querySelectorAll('[data-dcimport]');
      ctx.imports.forEach((imp, i) => {
        const el = live[i]; if (!el) return;
        const key = imp.name + ':' + i;
        let h = this.children[key];
        if (!h || h.root !== el) { h = this.children[key] = new Host(imp.name, el, imp.props); }
        else { h.c.props = imp.props; h.schedule(); }
      });
      if (!this.mounted) { this.mounted = true; this.c.componentDidMount && this.c.componentDidMount(); }
      else this.c.componentDidUpdate && this.c.componentDidUpdate();
    }
  }
  window.DC = { mount: (name, root) => (window.__app = new Host(name, root)) };
})();
