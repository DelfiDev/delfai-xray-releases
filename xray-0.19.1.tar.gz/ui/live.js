// X-ray live data bridge. The UI asks for data while it renders (XR.quote, XR.barsFor, ...);
// anything it asked for recently is fetched from the local server and the UI repaints when it arrives.
(function () {
  'use strict';
  const XR = window.XR = {
    live: false, status: null,
    q: {}, b: {}, ex: {}, o: {}, ob: {}, gx: {}, nw: {}, sr: {}, ch: {},
    err: {}
  };
  const W = new Map(); // key -> { kind, arg, t, ttl }
  const got = {}; // key -> last fetch time
  const busy = new Set();
  const now = () => Date.now();
  let kickT = null; let kick = () => {};
  // a new chart or chain request goes out right away instead of waiting for the next poll
  const want = (key, kind, arg, ttl) => { const w = W.get(key); if (w) w.t = now(); else { W.set(key, { kind, arg, t: now(), ttl }); if ((kind === 'b' || kind === 'k' || kind === 'e' || kind === 'ob') && !kickT) kickT = setTimeout(() => { kickT = null; kick(); }, 30); } };

  let repaintTimer = null;
  const repaint = () => {
    if (repaintTimer) return;
    repaintTimer = setTimeout(() => { repaintTimer = null; try { if (window.__app && window.__app.c) window.__app.c.forceUpdate(); } catch (e) { console.error(e); } }, 120);
  };
  const api = async (path) => {
    const r = await fetch(path, { cache: 'no-store' });
    const j = await r.json().catch(() => null);
    if (!r.ok) { const e = new Error((j && (j.error || j.message)) || ('HTTP ' + r.status)); e.status = r.status; throw e; }
    return j;
  };

  // ---------- time helpers ----------
  const nyFmt = new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', hour12: false });
  XR.toET = (ms) => { const o = {}; nyFmt.formatToParts(new Date(ms)).forEach((p) => { o[p.type] = p.value; }); return new Date(Number(o.year), Number(o.month) - 1, Number(o.day), Number(o.hour) % 24, Number(o.minute)); };
  const MO = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  XR.fmtOptT = (ms, tf) => { if (tf === '1D') { const d = XR.toET(ms); return MO[d.getMonth()] + ' ' + d.getDate(); } const d = new Date(ms); return MO[d.getMonth()] + ' ' + d.getDate() + ' ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0') + (window.XRTZ && window.XRTZ.abbr ? ' ' + window.XRTZ.abbr : ''); };
  const todayET = () => { const d = XR.toET(now()); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };

  const US = /^[A-Z]{1,5}$/;
  const supported = (sym) => sym === 'SPX' || (US.test(sym) && !['IXIC', 'DJI', 'FTSE', 'N225', 'HSI'].includes(sym));

  // ---------- accessors used while rendering ----------
  XR.quote = (sym) => { if (!XR.live || !supported(sym)) return null; want('q:' + sym, 'q', sym, 3000); return XR.q[sym] || null; };

  XR.barsFor = (sym, tf) => {
    if (!XR.live || !supported(sym)) return null;
    const k = sym + '|' + tf;
    want('b:' + k, 'b', { sym, tf }, tf === '1m' ? 5000 : tf === '5m' ? 10000 : 30000);
    const d = XR.b[k];
    if (d && d.bars && d.bars.length >= 15) {
      if (!d._arr || d._arr._src !== d.bars) {
        const arr = d.bars.map((x) => ({ o: x.o, h: x.h, l: x.l, c: x.c, v: x.v, t: x.t }));
        // keep the last candle in step with the live quote
        const q = XR.q[sym];
        if (q && q.last && arr.length) { const L = arr[arr.length - 1]; L.c = q.last; L.h = Math.max(L.h, q.last); L.l = Math.min(L.l, q.last); }
        arr.live = true; arr._src = d.bars; arr.derived = d.derived || null;
        d._arr = arr;
      }
      return d._arr;
    }
    return 'loading';
  };

  // expiry keys used by the UI -> real dates
  XR.expsFor = (sym) => {
    if (!XR.live || !supported(sym)) return null;
    want('e:' + sym, 'e', sym, 30 * 60000);
    const d = XR.ex[sym];
    if (!d || !d.expiries || !d.expiries.length) return null;
    if (d._map && d._map.day === todayET()) return d._map.list;
    const t0 = new Date(todayET() + 'T12:00:00Z').getTime();
    const dte = (e) => Math.round((new Date(e + 'T12:00:00Z').getTime() - t0) / 86400000);
    const isFri = (e) => new Date(e + 'T12:00:00Z').getUTCDay() === 5;
    const isMonthly = (e) => { const x = new Date(e + 'T12:00:00Z'); return x.getUTCDay() === 5 && x.getUTCDate() >= 15 && x.getUTCDate() <= 21; };
    const lab = (e) => { const x = new Date(e + 'T12:00:00Z'); return MO[x.getUTCMonth()] + ' ' + x.getUTCDate(); };
    const ex = d.expiries;
    const used = new Set();
    const pick = (fn) => { const e = ex.find((x) => !used.has(x) && fn(x)); if (e) used.add(e); return e; };
    const e0 = pick(() => true);
    const e1 = pick(() => true);
    const wk = pick((x) => isFri(x) && dte(x) >= 2) || pick(() => true);
    const mo = pick((x) => isMonthly(x) && dte(x) >= 10) || pick((x) => dte(x) >= 14);
    const list = [];
    if (e0) list.push(['0DTE', lab(e0), Math.max(0, dte(e0)), e0]);
    if (e1) list.push(['1DTE', lab(e1), dte(e1), e1]);
    if (wk) list.push(['Weekly', lab(wk), dte(wk), wk]);
    if (mo) list.push(['Monthly', lab(mo), dte(mo), mo]);
    d._map = { day: todayET(), list };
    return list;
  };
  XR.stepFor = (sym) => { const d = XR.ex[sym]; return d && d.step ? d.step : null; };

  const occOf = (sym, date, type, strike) => (sym === 'SPX' ? 'SPXW' : sym) + date.slice(2).replace(/-/g, '') + type + String(Math.round(strike * 1000)).padStart(8, '0');
  XR.occOf = occOf;

  XR.optSnap = (o) => { if (!XR.live) return null; want('o:' + o, 'o', o, 4000); return XR.o[o] || null; };

  // overlay real quote/greeks on the UI's priced contract
  // real contracts listed for one expiry (so we only ask for options that exist, using the broker's own symbols)
  XR.chainFor = (sym, exp) => {
    if (!XR.live || !supported(sym)) return null;
    const k = sym + '|' + exp;
    want('k:' + k, 'k', { sym, exp }, 30 * 60000);
    return XR.ch[k] || null;
  };
  XR.applyOpt = (pc, spec, ex) => {
    if (!ex || !ex[3]) return pc;
    const list = XR.chainFor(spec.under, ex[3]);
    if (!list) { pc.occ = 'wait:' + spec.under; pc.est = true; return pc; }
    let best = null;
    list.forEach((c) => { if (c.type === spec.type && (!best || Math.abs(c.strike - spec.strike) < Math.abs(best.strike - spec.strike))) best = c; });
    if (!best) { pc.occ = 'none:' + spec.under; pc.est = true; return pc; } // broker lists no such contract: never show made-up candles
    if (best.strike !== spec.strike) { pc.strike = best.strike; pc.name = pc.root + ' ' + (best.strike % 1 ? best.strike.toFixed(1) : best.strike) + spec.type; }
    const o = best.occ;
    pc.occ = o;
    pc.key = pc.key + '|' + ex[3];
    pc.baseSpec = null;
    const s = XR.optSnap(o);
    if (!s) { pc.est = true; return pc; }
    const iv = s.iv ? (s.iv > 3 ? s.iv / 100 : s.iv) : pc.iv;
    const mid = s.mid !== null && s.mid !== undefined ? s.mid : pc.mid;
    const bid = s.bid !== null ? s.bid : pc.bid, ask = s.ask !== null && s.ask > 0 ? s.ask : pc.ask;
    const g = Object.assign({}, pc.g, { price: mid });
    ['delta', 'gamma', 'theta', 'vega', 'rho'].forEach((k) => { if (s[k] !== null && s[k] !== undefined && Number.isFinite(s[k])) g[k] = s[k]; });
    const S = pc.u.last;
    const bep = spec.type === 'C' ? (spec.strike + ask - S) / S * 100 : (spec.strike - ask - S) / S * 100;
    const last = Number.isFinite(s.last) && s.last > 0 ? s.last : null;
    const chgLive = last && Number.isFinite(s.prevClose) && s.prevClose > 0 ? (last / s.prevClose - 1) * 100 : (Number.isFinite(s.chgPct) ? s.chgPct : NaN);
    return Object.assign(pc, { iv, mid: Math.max(0.01, mid), last, chgLive, bid, ask, g, vol: s.volume || 0, oi: s.oi || 0, bep, live: true, est: false });
  };

  XR.optBarsFor = (o, mark) => {
    if (!XR.live || !o) return null;
    if (o.indexOf(':') < 0) want('ob:' + o, 'ob', o, 10000);
    const d = XR.ob[o];
    if (d && d.bars && d.bars.length >= 20) {
      if (!d._arr || d._arr._src !== d.bars) {
        const arr = d.bars.map((x) => ({ o: x.o, h: x.h, l: x.l, c: x.c, v: x.v, t: x.t, day: x.day, slot: x.slot, pad: x.pad }));
        arr.live = true; arr._src = d.bars; d._arr = arr;
      }
      // mirror the broker: the live candle follows the LAST TRADE (what Webull charts), never the bid/ask midpoint.
      // The cached candles are never edited; the live candle is a copy, so wicks only grow on real prints.
      const s = XR.o[o];
      const base = d._arr;
      const px = s && Number.isFinite(s.last) && s.last > 0 ? s.last : null;
      if (!px || !base.length) return base;
      const et = XR.toET(now()); const slotNow = Math.floor((et.getHours() * 60 + et.getMinutes() - 570) / 5);
      if (d._live && d._live.base === base && d._live.px === px && d._live.slot === slotNow) return d._live.out;   // same picture as last time
      const out = base.slice(); out.live = true; out._src = base._src;
      d._live = { base, px, slot: slotNow, out };
      const L0 = out[out.length - 1];
      const today = todayET(); const wk = et.getDay() > 0 && et.getDay() < 6;
      if (wk && L0.day === today && Number.isFinite(L0.slot) && slotNow > L0.slot && slotNow < 78) {
        // a new 5-minute candle has started since the last one we fetched: fill quiet slots flat, then open the new one
        let prevC = L0.c;
        for (let k = L0.slot + 1; k < slotNow; k++) out.push({ o: prevC, h: prevC, l: prevC, c: prevC, v: 0, t: (L0.t || 0) + (k - L0.slot) * 300000, day: today, slot: k, pad: true });
        out.push({ o: prevC, h: Math.max(prevC, px), l: Math.min(prevC, px), c: px, v: 0, t: (L0.t || 0) + (slotNow - L0.slot) * 300000, day: today, slot: slotNow, liveBar: true });
      } else if (wk && L0.day === today) {
        out[out.length - 1] = Object.assign({}, L0, { c: px, h: Math.max(L0.h, px), l: Math.min(L0.l, px), liveBar: true });
      }
      return out;
    }
    // loading: a flat line at the current mark, 2 sessions long, flagged so the box detector ignores it
    const m = mark || 0.05;
    const flat = [];
    for (let i = 0; i < 156; i++) flat.push({ o: m, h: m * 1.01, l: m * 0.99, c: m, v: 0, t: null, day: i < 78 ? 'a' : 'b' });
    flat.live = true; flat.loading = true;
    return flat;
  };

  // what the loading overlay on each chart says
  XR.chartMsg = (sym, tf) => { const e = XR.err['b:' + sym + '|' + tf]; return e ? 'Still trying to load ' + sym + ' (' + e + ')' : 'Loading ' + sym + ' ' + tf + ' candles…'; };
  XR.optLoading = (o) => { if (!XR.live || !o) return false; if (o.startsWith('wait:') || o.startsWith('none:')) return true; const d = XR.ob[o]; return !(d && d.bars && d.bars.length >= 20); };
  XR.optMsg = (o, name) => {
    if (!o) return '';
    if (o.startsWith('wait:')) return 'Finding real contracts for ' + o.slice(5) + '…';
    if (o.startsWith('none:')) return 'Your broker lists no contract like this one. Pick another strike or expiry.';
    const e = XR.err['ob:' + o]; const d = XR.ob[o];
    if (e) return 'No premium history for ' + name + ' (' + e + ')';
    if (d && d.bars && d.bars.length < 20) return name + ' has barely traded, not enough candles to chart yet.';
    return 'Loading ' + name + ' premium…';
  };
  XR.gexFor = (sym) => {
    if (!XR.live || !supported(sym)) return null;
    want('g:' + sym, 'g', sym, 60000);
    const d = XR.gx[sym];
    return d && d.strikes ? d : null;
  };

  XR.levelsFor = (sym, base) => {
    if (!XR.live) return base;
    const q = XR.q[sym];
    const out = Object.assign({}, base);
    if (q && q.last) out.last = q.last;
    const G = XR.gexFor(sym);
    if (G && G.levels) { out.flip = G.levels.flip; out.cw = G.levels.cw; out.pw = G.levels.pw; out.maxPain = G.levels.maxPain; out.em = G.levels.em; }
    const D = XR.barsFor(sym, '1D');
    if (Array.isArray(D) && D.length > 2) { out.pdh = D[D.length - 2].h; out.pdl = D[D.length - 2].l; }
    return out;
  };

  XR.liveSD = (sd) => {
    if (!XR.live) return sd;
    const out = {};
    Object.keys(sd).forEach((sym) => {
      const r = Object.assign({}, sd[sym]);
      const q = XR.quote(sym);
      if (q && q.last) r.spot = q.last;
      const G = XR.gexFor(sym);
      if (G && G.levels) {
        r.flip = G.levels.flip; r.cw = G.levels.cw; r.pw = G.levels.pw; r.step = G.step;
        r.lo = Math.min(r.pw, r.spot || r.pw) - G.step; r.hi = Math.max(r.cw, r.spot || r.cw) + G.step;
      } else if (q && q.last) {
        // until the gamma model loads, keep the sample levels proportional to the real price
        const k = q.last / sd[sym].spot;
        ['flip', 'cw', 'pw', 'lo', 'hi'].forEach((f) => { r[f] = sd[sym][f] * k; });
      }
      out[sym] = r;
    });
    return out;
  };

  const lex = { up: /\b(beat|beats|surge|surges|jump|jumps|rall(y|ies)|record|upgrade[sd]?|soar|soars|gain[s]?|rise[s]?|strong|bullish|raises?|tops?)\b/i, down: /\b(miss|misses|fall[s]?|drop[s]?|plunge[s]?|slump[s]?|downgrade[sd]?|cut[s]?|weak|bearish|lawsuit|probe|recall|sink[s]?|tumble[s]?|warn[s]?)\b/i };
  XR.newsFor = (sym, sn) => {
    if (!XR.live) return null;
    want('n:' + sym, 'n', sym, 5 * 60000);
    const d = XR.nw[sym];
    if (!d) return [{ title: 'Loading ' + sym + ' headlines…', src: '', time: '', sent: '', color: '#8796A3' }];
    if (!d.length) return [{ title: 'No recent headlines for ' + sym + '.', src: '', time: '', sent: '', color: '#8796A3' }];
    const ago = (t) => { if (!t) return ''; const m = Math.round((now() - t) / 60000); return m < 60 ? m + 'm ago' : m < 1440 ? Math.round(m / 60) + 'h ago' : Math.round(m / 1440) + 'd ago'; };
    return d.slice(0, 6).map((x) => Object.assign({ title: x.title, src: x.src, time: ago(x.time), link: x.link }, sn(lex.up.test(x.title) && !lex.down.test(x.title) ? 1 : lex.down.test(x.title) && !lex.up.test(x.title) ? -1 : 0)));
  };

  // ---------- Catalysts & News page (free sources, works without a broker) ----------
  const side = {}; // key -> {v, t, busy, err}
  const sideGet = (key, url, ttl) => {
    const e = side[key]; const t = now();
    if (!e || (!e.busy && t - e.t > (e.err ? 60000 : ttl))) {
      side[key] = Object.assign({}, e || {}, { busy: true, t });
      api(url).then((v) => { side[key] = { v, t: now() }; repaint(); }).catch((err) => { side[key] = Object.assign({}, side[key], { busy: false, err: err.message, t: now() }); });
    }
    return side[key] && side[key].v;
  };
  const MOD = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const dLab = (iso) => { const d = new Date(iso + 'T12:00:00Z'); return MOD[d.getUTCMonth()] + ' ' + d.getUTCDate(); };
  const thirdFriday = (iso) => { const d = new Date(iso + 'T12:00:00Z'); return d.getUTCDay() === 5 && d.getUTCDate() >= 15 && d.getUTCDate() <= 21; };
  XR.catalysts = (tag) => {
    let watch = []; try { watch = XR.knownList ? XR.knownList().slice(0, 30) : []; } catch (e) { watch = []; }
    const d = sideGet('cat', '/api/catalysts?watch=' + encodeURIComponent(watch.join(',')), 30 * 60000);
    if (!d) { const e = side.cat; return e && e.err ? null : [{ day: '', time: '', title: 'Loading this week\'s calendar…', note: 'Macro events and earnings dates.', ...tag('MACRO') }]; }
    const items = [];
    (d.macro || []).forEach((m) => items.push({ k: m.date + ' ' + (m.time === 'ALL' ? '00:00' : m.time), day: m.day, time: m.time, title: m.title, note: [m.forecast ? 'Forecast ' + m.forecast : '', m.previous ? 'prev ' + m.previous : '', m.impact === 'High' ? 'High impact: expect IV to drop on 0DTE right after' : 'Medium impact'].filter(Boolean).join(' · '), ...tag('MACRO') }));
    (d.earnings || []).forEach((r) => items.push({ k: r.date + (r.when === 'BMO' ? ' 07:00' : r.when === 'AMC' ? ' 16:05' : ' 12:00'), day: r.day, time: r.when === 'BMO' ? 'AM' : r.when === 'AMC' ? 'PM' : '—', title: r.sym + ' earnings', note: r.name + (r.eps ? ' · EPS est ' + r.eps : '') + (r.when === 'AMC' ? ' · after the close' : r.when === 'BMO' ? ' · before the open' : ''), ...tag(r.cap >= 500e9 ? 'HIGH IV' : 'EARNINGS') }));
    // monthly options expiration if this week's Friday is the 3rd Friday
    const fri = (() => { const t = new Date(); for (let i = 0; i < 7; i++) { const x = new Date(t.getTime() + i * 86400000); if (x.getDay() === 5) return x.getFullYear() + '-' + String(x.getMonth() + 1).padStart(2, '0') + '-' + String(x.getDate()).padStart(2, '0'); } return null; })();
    if (fri && thirdFriday(fri)) items.push({ k: fri + ' 16:00', day: 'FRI', time: 'ALL', title: 'Monthly OpEx', note: 'Large gamma roll-off. Pin risk into the close.', ...tag('MACRO') });
    if (!items.length) return [{ day: '', time: '', title: 'Quiet week', note: 'No high-impact US data or mega-cap earnings left this week.', ...tag('MACRO') }];
    return items.sort((a, b) => (a.k < b.k ? -1 : 1)).slice(0, 10);
  };
  XR.marketNews = (cat, sentFn) => {
    const d = sideGet('mn:' + cat, '/api/marketnews?cat=' + cat, 5 * 60000);
    if (!d || !d.length) return null;
    const ago = (t) => { if (!t) return ''; const m = Math.round((now() - t) / 60000); return m < 60 ? m + 'm ago' : m < 1440 ? Math.round(m / 60) + 'h ago' : Math.round(m / 1440) + 'd ago'; };
    return d.slice(0, 8).map((x) => Object.assign({ sym: x.sym, title: x.title, src: x.src, time: ago(x.time), link: x.link }, sentFn(lex.up.test(x.title) && !lex.down.test(x.title) ? 1 : lex.down.test(x.title) && !lex.up.test(x.title) ? -1 : 0)));
  };
  // next earnings + dividend dates for the ticker on the chart
  XR.tickerCats = (sym) => {
    if (!sym || !/^[A-Z.]{1,6}$/.test(sym)) return null;
    const d = sideGet('tc:' + sym, '/api/tickercat?symbol=' + encodeURIComponent(sym), 60 * 60000);
    if (!d) return [{ title: 'Checking ' + sym + ' calendar…', when: '', tag: '', tagColor: '#8796A3', tagBorder: '#22303F' }];
    const T = { EARNINGS: ['#F0A04B', '#4A3A24'], DIVIDEND: ['#34D399', '#1F4A3A'], NONE: ['#8796A3', '#22303F'] };
    const rows = (d.items || []).map((x) => ({ title: x.title, when: x.when, tag: x.tag, tagColor: (T[x.tag] || T.NONE)[0], tagBorder: (T[x.tag] || T.NONE)[1] }));
    return rows.length ? rows : [{ title: 'No earnings or dividend dates in the next 6 weeks', when: 'Calendar: Nasdaq · dividends: Schwab', tag: '', tagColor: '#8796A3', tagBorder: '#22303F' }];
  };
  // Economic Indicators: real series from FRED (and the broker for VIX9D / VIX1D / VVIX / gold), laid out on
  // the same monthly / daily / weekly grids the page draws.
  let econRaw = null, econShaped = null, econTimer = null;
  XR.econLoading = () => !econShaped;
  // one line for the page header: loading, partly loaded, failing, or the source
  XR.econStatus = () => {
    const e = side.econ; const d = e && e.v;
    if (!d) return e && e.err ? 'Could not reach the X-ray data server: ' + e.err + '. Retrying…' : 'Loading economic data from FRED…';
    const errs = Object.values(d.errors || {});
    if (!d.have) return d.pending ? 'Downloading economic data from FRED… the first time takes about a minute.' : 'Could not download from FRED' + (errs[0] ? ' (' + errs[0] + ')' : '') + '. Retrying every minute.';
    const src = 'Data: FRED (St. Louis Fed)' + (d.broker && (d.broker.VIX9D || d.broker.VIX1D) ? ', VIX9D / VIX1D / VVIX from Schwab' : '');
    if (d.pending) return src + ' · loading ' + d.have + ' of ' + d.total + ' series…';
    return src + (d.have < d.total ? ' · ' + (d.total - d.have) + ' series could not load' + (errs[0] ? ' (' + errs[0] + ')' : '') : '') + '. Drag across a chart to zoom. Hover for values.';
  };
  XR.econ = () => {
    const prev = side.econ && side.econ.v;
    const fast = !prev || prev.pending || !prev.have;
    const d = sideGet('econ', '/api/econ', fast ? 3000 : 15 * 60000);
    if (fast && !econTimer) econTimer = setTimeout(() => { econTimer = null; repaint(); }, 3100); // keep checking while it downloads
    if (!d || !d.series || !Object.keys(d.series).length) return null;
    if (d === econRaw && econShaped) return econShaped;
    const S = d.series, B = d.broker || {};
    const MN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    // value of a [[ms, v], ...] series at each grid time: last observation at or before it (first value before it starts)
    const onGrid = (obs, grid) => { if (!obs || !obs.length) return null; let k = 0; return grid.map((t) => { while (k + 1 < obs.length && obs[k + 1][0] <= t) k++; return obs[k][0] <= t ? obs[k][1] : obs[0][1]; }); };
    const yoy = (vals) => vals.map((v, i) => (i >= 12 && vals[i - 12] ? (v / vals[i - 12] - 1) * 100 : (vals[12] && vals[0] ? (vals[12] / vals[0] - 1) * 100 : 0)));
    const lastT = (id) => { const o = S[id]; return o && o.length ? o[o.length - 1][0] : 0; };
    // monthly: Jan 1990 to the latest month any key series has
    const endM = new Date(Math.max(lastT('UNRATE'), lastT('CPIAUCSL'), lastT('FEDFUNDS'), Date.UTC(2020, 0, 1)));
    const mGrid = [], ecoLabels = [];
    for (let y = 1990; y <= endM.getUTCFullYear(); y++) for (let m = 0; m < 12; m++) { if (y === endM.getUTCFullYear() && m > endM.getUTCMonth()) break; mGrid.push(Date.UTC(y, m + 1, 1) - 1); ecoLabels.push(MN[m] + ' ' + y); }
    const E = (key, label, unit, id, f) => { let v = onGrid(S[id], mGrid); if (!v) return null; if (f) v = f(v); return { key, label, unit, vals: v }; };
    const eco = [
      E('gdp', 'GDP', 'usdB', 'GDP'), E('realGDP', 'Real GDP', 'usdB', 'GDPC1'), E('nomPot', 'Nominal Potential GDP', 'usdB', 'NGDPPOT'), E('realPc', 'Real GDP Per Capita', 'usd', 'A939RX0Q048SBEA'),
      E('fedFunds', 'Federal Funds', 'pct', 'FEDFUNDS'), E('cpi', 'CPI', 'idx', 'CPIAUCSL'), E('inflRate', 'Inflation Rate (CPI, year over year)', 'pct', 'CPIAUCSL', yoy), E('infl', 'Core Inflation (core PCE, year over year)', 'pct', 'PCEPILFE', yoy),
      E('retail', 'Retail Sales', 'usdM', 'RSAFS'), E('sentiment', 'Consumer Sentiment', 'idx', 'UMCSENT'), E('durable', 'Durable Goods', 'usdM', 'DGORDER'), E('unemp', 'Unemployment Rate', 'pct', 'UNRATE'),
      E('payroll', 'Total Nonfarm Payroll', 'thou', 'PAYEMS'), E('claims', 'Initial Claims', 'thou', 'ICSA', (v) => v.map((x) => x / 1000)), E('indProd', 'Industrial Production: Total Index', 'idx', 'INDPRO'),
      E('housing', 'New Privately-Owned Housing Units Started: Total Units', 'thou', 'HOUST'), E('vehicles', 'Total Vehicle Sales', 'mil', 'TOTALSA'), E('moneyFunds', 'Retail Money Funds', 'usdB', 'RMFSL'),
      E('recProb', 'Smoothed U.S. Recession Probabilities', 'pct', 'RECPROUSM156N'), E('cd3m', '3-Month or 90-Day Rates and Yields: Certificates of Deposit', 'pct', 'IR3TCD01USM156N'),
      E('creditCard', 'Commercial Bank Interest Rate on Credit Card Plans, All Accounts', 'pct', 'TERMCBCCALLNS'), E('mort30', '30-Year Fixed Rate Mortgage Average', 'pct', 'MORTGAGE30US'), E('mort15', '15-Year Fixed Rate Mortgage Average', 'pct', 'MORTGAGE15US')
    ].filter(Boolean);
    // daily: business days over the last year, up to the latest treasury print
    const endD = lastT('DGS10') || Date.now();
    const dGrid = [], tsyLabels = [];
    for (let t = endD - 365 * 86400000; t <= endD; t += 86400000) { const dd = new Date(t); const wd = dd.getUTCDay(); if (wd !== 0 && wd !== 6) { dGrid.push(t + 86399000); tsyLabels.push(MN[dd.getUTCMonth()] + ' ' + dd.getUTCDate() + ', ' + dd.getUTCFullYear()); } }
    const Dly = (key, label, unit, obs, f) => { let v = onGrid(obs, dGrid); if (!v) return null; if (f) v = f(v); return { key, label, unit, vals: v }; };
    const tsy = [['m1', '1 Month', 'DGS1MO'], ['m3', '3 Months', 'DGS3MO'], ['m6', '6 Months', 'DGS6MO'], ['y1', '1 Year', 'DGS1'], ['y2', '2 Years', 'DGS2'], ['y3', '3 Years', 'DGS3'], ['y5', '5 Years', 'DGS5'], ['y7', '7 Years', 'DGS7'], ['y10', '10 Years', 'DGS10'], ['y20', '20 Years', 'DGS20'], ['y30', '30 Years', 'DGS30']]
      .map(([k, l, id]) => Dly(k, l, 'pct', S[id])).filter(Boolean);
    const tv = (k) => (tsy.find((x) => x.key === k) || {}).vals;
    if (tv('y10') && tv('y2')) tsy.push({ key: 's210', label: '2s10s Spread', unit: 'spr', vals: tv('y10').map((v, i) => v - tv('y2')[i]) });
    if (tv('y10') && tv('m3')) tsy.push({ key: 's3m10', label: '3m10y Spread', unit: 'spr', vals: tv('y10').map((v, i) => v - tv('m3')[i]) });
    const vol = [Dly('vix', 'VIX', 'idx2', S.VIXCLS), Dly('vix9d', 'VIX9D', 'idx2', B.VIX9D), Dly('vix1d', 'VIX1D', 'idx2', B.VIX1D), Dly('vvix', 'VVIX', 'idx2', B.VVIX)].filter(Boolean);
    const mkt = [Dly('dxy', 'U.S. Dollar Index (Fed broad)', 'idx2', S.DTWEXBGS), Dly('oil', 'WTI Crude Oil', 'usd2', S.DCOILWTICO), Dly('gold', 'Gold (GLD ETF)', 'usd2', B.GLD), Dly('hyOas', 'High Yield Credit Spread (OAS)', 'pct', S.BAMLH0A0HYM2)].filter(Boolean);
    // weekly liquidity, 2018 to now ($ billions)
    const endW = Math.max(lastT('WALCL'), Date.UTC(2020, 0, 1));
    const wGrid = [], liqLabels = [];
    for (let t = Date.UTC(2018, 0, 3); t <= endW; t += 7 * 86400000) { const dd = new Date(t); wGrid.push(t + 86399000); liqLabels.push(MN[dd.getUTCMonth()] + ' ' + dd.getUTCDate() + ', ' + dd.getUTCFullYear()); }
    const W = (obs, k) => { const v = onGrid(obs, wGrid); return v ? v.map((x) => x * k) : null; };
    const bs = W(S.WALCL, 1 / 1000), rrp = W(S.RRPONTSYD, 1), tga = W(S.WTREGEN, 1 / 1000);
    const liq = [];
    if (bs && rrp && tga) liq.push({ key: 'netLiq', label: 'Net Liquidity (Fed BS − RRP − TGA)', unit: 'usdB', vals: bs.map((v, i) => v - rrp[i] - tga[i]) });
    if (bs) liq.push({ key: 'fedBS', label: 'Fed Balance Sheet', unit: 'usdB', vals: bs });
    if (rrp) liq.push({ key: 'rrp', label: 'Reverse Repo (RRP)', unit: 'usdB', vals: rrp });
    if (tga) liq.push({ key: 'tga', label: 'Treasury General Account (TGA)', unit: 'usdB', vals: tga });
    econRaw = d;
    econShaped = { eco, ecoLabels, tsy, tsyLabels, vol, mkt, liq, liqLabels, live: true, missing: Object.keys(d.errors || {}) };
    return econShaped;
  };

  XR.globeLive = false;
  XR.globeEvents = () => {
    const d = sideGet('globe', '/api/globe', 10 * 60000);
    if (!d || !d.length) return null;
    XR.globeLive = true;
    return d;
  };
  XR.bigCatsReal = false;
  XR.bigCats = () => {
    const d = sideGet('big', '/api/bigcats', 30 * 60000);
    if (!d) { const e = side.big; if (e && e.err) return null; XR.bigCatsReal = true; return []; } // loading: empty rather than sample dates
    if (!d.length) return null;
    XR.bigCatsReal = true;
    return d.map((r) => [r.sym, r.ev, dLab(r.date), r.when === 'TBD' ? 'ALL' : r.when, Math.max(0, r.days), r.em || 0, r.grp]);
  };

  // ---------- ticker directory (every US stock + curated ETFs) and tickers the user has opened ----------
  XR.dir = new Map(); XR.dirList = [];
  fetch('tickers.json').then((r) => r.json()).then((d) => {
    (d.etf || []).forEach((r) => { const e = { sym: r[0], name: r[1], type: 'ETF', lev: r[4] || '' }; XR.dir.set(e.sym, e); XR.dirList.push(e); });
    (d.stock || []).forEach((r) => { if (XR.dir.has(r[0])) return; const e = { sym: r[0], name: r[1], type: 'STOCK', lev: '' }; XR.dir.set(e.sym, e); XR.dirList.push(e); });
    repaint();
  }).catch(() => {});
  XR.dirInfo = (sym) => XR.dir.get(sym) || null;
  // built-in list + live broker search + "look up this exact ticker" so any listed symbol can be opened
  XR.searchAll = (q, n, skip) => {
    const raw = String(q || '').trim(), Q = raw.toUpperCase().replace('^', '');
    const out = XR.searchDir(raw, n, skip);
    if (!XR.live || !Q) return out;
    const seen = new Set((skip || []).concat(out.map((e) => e.sym)));
    want('s:' + Q, 's', Q, 10 * 60000);
    (XR.sr[Q] || []).forEach((e) => { if (out.length < n && !seen.has(e.sym)) { seen.add(e.sym); out.push(e); } });
    if (US.test(Q) && !seen.has(Q)) { const lq = XR.quote(Q); out.push({ sym: Q, name: lq && lq.last ? Q : 'Look up ' + Q + ' live', type: 'STOCK', lev: '', guess: !(lq && lq.last) }); }
    return out;
  };
  XR.dirName = (sym) => { const e = XR.dir.get(sym); return e ? (e.lev ? e.name + ' · ' + e.lev : e.name) : sym; };
  // search the directory: exact symbol, symbol prefix, then name prefix, then name contains (directory is sorted by size)
  XR.searchDir = (q, n, skip) => {
    const Q = String(q || '').trim().toUpperCase().replace('^', '');
    if (!Q || !XR.dirList.length) return [];
    const out = [], seen = new Set(skip || []);
    const add = (e) => { if (out.length < n && !seen.has(e.sym)) { seen.add(e.sym); out.push(e); } };
    const ex = XR.dir.get(Q); if (ex) add(ex);
    for (const e of XR.dirList) { if (out.length >= n) break; if (e.sym.startsWith(Q)) add(e); }
    if (Q.length >= 2) for (const e of XR.dirList) { if (out.length >= n) break; if (e.name.toUpperCase().startsWith(Q)) add(e); }
    if (Q.length >= 3) for (const e of XR.dirList) { if (out.length >= n) break; if (e.name.toUpperCase().includes(Q)) add(e); }
    return out;
  };
  const KEY = 'xr-known-v1';
  let known = {};
  try { known = JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { known = {}; }
  const saveKnown = () => { try { localStorage.setItem(KEY, JSON.stringify(known)); } catch (e) { /* storage off */ } };
  XR.addTicker = (sym) => { if (!US.test(sym)) return; if (!known[sym]) { known[sym] = { last: 0, t: now() }; saveKnown(); } want('q:' + sym, 'q', sym, 3000); repaint(); };
  XR.knownList = () => Object.keys(known).sort((a, b) => known[b].t - known[a].t).slice(0, 60);
  XR.cachedLast = (sym) => (XR.q[sym] && XR.q[sym].last) || (known[sym] && known[sym].last) || 0;
  const rememberQuotes = (r) => { let ch = false; Object.keys(r || {}).forEach((s) => { if (known[s] && r[s] && r[s].last && Math.abs((known[s].last || 0) - r[s].last) > 1e-9) { known[s].last = r[s].last; ch = true; } }); if (ch) saveKnown(); };
  XR.lookupState = (sym) => (XR.q[sym] && XR.q[sym].last ? 'ok' : XR.err['q:' + sym] ? 'none' : 'loading');

  XR.srcName = () => ((XR.status && XR.status.sources && XR.status.sources.length) ? XR.status.sources.join(' + ') : 'Webull');
  XR.badge = () => (XR.live ? 'LIVE · ' + XR.srcName().toUpperCase() : 'DEMO · SAMPLE DATA');
  XR.foot = () => (XR.live ? 'Live data from your ' + XR.srcName() + ' account (personal use). Smart Money Flow, dark pool, globe and journal stats are still sample data. Educational tool, not financial advice.' : 'Demo mode: sample data. Connect Webull or Schwab under Data connection to go live. Educational tool, not financial advice.');

  // ---------- fetch loop ----------
  const fetchOne = async (key, w) => {
    busy.add(key);
    try {
      if (w.kind === 'b') { XR.b[w.arg.sym + '|' + w.arg.tf] = await api('/api/bars?symbol=' + encodeURIComponent(w.arg.sym) + '&tf=' + encodeURIComponent(w.arg.tf)); }
      else if (w.kind === 'e') { XR.ex[w.arg] = await api('/api/expirations?symbol=' + encodeURIComponent(w.arg)); }
      else if (w.kind === 'k') { const r = await api('/api/chain?symbol=' + encodeURIComponent(w.arg.sym) + '&exp=' + encodeURIComponent(w.arg.exp) + '&pct=0.12'); XR.ch[w.arg.sym + '|' + w.arg.exp] = (Array.isArray(r) ? r : []).map((c) => ({ occ: c.occ, type: c.type, strike: Number(c.strike) })).filter((c) => c.occ && Number.isFinite(c.strike)); }
      else if (w.kind === 'ob') { XR.ob[w.arg] = await api('/api/option-bars?occ=' + encodeURIComponent(w.arg)); }
      else if (w.kind === 'g') { XR.gx[w.arg] = await api('/api/gex?symbol=' + encodeURIComponent(w.arg)); }
      else if (w.kind === 'n') { const di = XR.dirInfo ? XR.dirInfo(w.arg) : null; XR.nw[w.arg] = await api('/api/news?symbol=' + encodeURIComponent(w.arg) + (di && di.name && di.type !== 'ETF' && di.type !== 'INDEX' ? '&name=' + encodeURIComponent(di.name) : '')); }
      else if (w.kind === 's') { const r = await api('/api/search?q=' + encodeURIComponent(w.arg)); XR.sr[w.arg] = Array.isArray(r) ? r : []; XR.sr[w.arg].forEach((e) => { if (!XR.dir.has(e.sym)) { const d = { sym: e.sym, name: e.name, type: e.type, lev: '' }; XR.dir.set(e.sym, d); XR.dirList.push(d); } }); }
      delete XR.err[key];
      got[key] = now();
      repaint();
    } catch (e) {
      XR.err[key] = e.message; got[key] = now() - (w.ttl || 0) + 15000; // retry in ~15s
      if (e.status === 409) checkStatus();
    } finally { busy.delete(key); }
  };

  const tick = async () => {
    if (!XR.live) return;
    const t = now();
    const due = [];
    W.forEach((w, key) => {
      if (t - w.t > 20000) { W.delete(key); return; } // no longer on screen
      if (busy.has(key)) return;
      if (!got[key] || t - got[key] > w.ttl) due.push([key, w]);
    });
    // batch quotes
    const qs = due.filter(([, w]) => w.kind === 'q').map(([, w]) => w.arg).slice(0, 80);
    if (qs.length) {
      qs.forEach((s) => busy.add('q:' + s));
      api('/api/quotes?symbols=' + qs.join(',')).then((r) => { Object.assign(XR.q, r); rememberQuotes(r); qs.forEach((s) => { got['q:' + s] = now(); if (r && r[s] && r[s].last) delete XR.err['q:' + s]; else XR.err['q:' + s] = 'no quote'; }); repaint(); })
        .catch((e) => { qs.forEach((s) => { got['q:' + s] = now(); }); if (e.status === 409) checkStatus(); })
        .finally(() => qs.forEach((s) => busy.delete('q:' + s)));
    }
    // batch option snapshots, most recently wanted first
    const os = due.filter(([, w]) => w.kind === 'o').sort((a, b) => b[1].t - a[1].t).map(([, w]) => w.arg).slice(0, 120);
    if (os.length) {
      os.forEach((o) => busy.add('o:' + o));
      api('/api/options?occ=' + os.join(',')).then((r) => { Object.assign(XR.o, r); os.forEach((o) => { got['o:' + o] = now(); }); repaint(); })
        .catch(() => { os.forEach((o) => { got['o:' + o] = now(); }); })
        .finally(() => os.forEach((o) => busy.delete('o:' + o)));
    }
    const pri = { s: 0, b: 0, e: 1, k: 1, ob: 2, g: 3, n: 4 };
    const inFlight = Array.from(busy).filter((k) => !k.startsWith('q:') && !k.startsWith('o:') && !k.startsWith('n:')).length; // slow headline fetches never hold up charts
    due.filter(([, w]) => w.kind !== 'q' && w.kind !== 'o')
      .sort((a, b) => (pri[a[1].kind] - pri[b[1].kind]) || (b[1].t - a[1].t))
      .slice(0, Math.max(0, 6 - inFlight)).forEach(([key, w]) => fetchOne(key, w));
  };

  let lastLive = null;
  const checkStatus = async () => {
    try {
      const s = await api('/api/status');
      XR.status = s;
      const live = s.mode === 'live';
      if (live !== lastLive) { lastLive = live; XR.live = live; repaint(); }
    } catch (e) { /* server not ready */ }
  };
  // Futures rollover dates from each exchange's published contract rules (CME/NYMEX/COMEX/CBOT).
  // Exchange holidays can move a date by a day, so these are close guides, not exchange notices.
  XR.rolls = (nowMs) => {
    const CODES = 'FGHJKMNQUVXZ', MN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const D = (y, m, d) => new Date(Date.UTC(y, m, d));
    const biz = (d) => d.getUTCDay() !== 0 && d.getUTCDay() !== 6;
    const addBiz = (d, n) => { const x = new Date(d); const st = n < 0 ? -1 : 1; let k = Math.abs(n); while (k > 0) { x.setUTCDate(x.getUTCDate() + st); if (biz(x)) k--; } return x; };
    const lastBiz = (y, m) => { const x = D(y, m + 1, 0); while (!biz(x)) x.setUTCDate(x.getUTCDate() - 1); return x; };
    const thirdFri = (y, m) => { const x = D(y, m, 1); while (x.getUTCDay() !== 5) x.setUTCDate(x.getUTCDate() + 1); x.setUTCDate(x.getUTCDate() + 14); return x; };
    const today = D(new Date(nowMs || Date.now()).getUTCFullYear(), new Date(nowMs || Date.now()).getUTCMonth(), new Date(nowMs || Date.now()).getUTCDate());
    const code = (root, y, m) => root + CODES[m] + String(y).slice(-1);
    const defs = [
      { sym: '/ES /NQ', name: 'S&P and Nasdaq', roots: ['ES', 'NQ'], months: [2, 5, 8, 11], roll: (y, m) => { const e = thirdFri(y, m); const r = new Date(e); r.setUTCDate(r.getUTCDate() - 8); return r; }, note: (y, m) => 'Quarterly roll, about a week before the ' + MN[m] + ' ' + thirdFri(y, m).getUTCDate() + ' expiry.' },
      { sym: '/CL', name: 'Crude oil', roots: ['CL'], months: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], roll: (y, m) => { const p = D(y, m - 1, 25); const ltd = addBiz(p, biz(p) ? -3 : -4); return addBiz(ltd, -2); }, note: (y, m) => { const p = D(y, m - 1, 25); const ltd = addBiz(p, biz(p) ? -3 : -4); return 'Last trade day ' + MN[ltd.getUTCMonth()] + ' ' + ltd.getUTCDate() + '. Volume shifts a few days early.'; } },
      { sym: '/NG', name: 'Natural gas', roots: ['NG'], months: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], roll: (y, m) => addBiz(addBiz(D(y, m, 1), -3), -2), note: (y, m) => { const ltd = addBiz(D(y, m, 1), -3); return 'Expires ' + MN[ltd.getUTCMonth()] + ' ' + ltd.getUTCDate() + ', 3 business days before the month.'; } },
      { sym: '/GC', name: 'Gold', roots: ['GC'], months: [1, 3, 5, 7, 9, 11], roll: (y, m) => addBiz(lastBiz(y, m - 1), -3), note: (y, m) => { const f = lastBiz(y, m - 1); return 'Roll ahead of first notice day ' + MN[f.getUTCMonth()] + ' ' + f.getUTCDate() + '.'; } },
      { sym: '/ZN', name: '10-year note', roots: ['ZN'], months: [2, 5, 8, 11], roll: (y, m) => addBiz(lastBiz(y, m - 1), -4), note: (y, m) => { const f = lastBiz(y, m - 1); return 'Roll ahead of first notice day ' + MN[f.getUTCMonth()] + ' ' + f.getUTCDate() + '.'; } }
    ];
    const out = defs.map((d) => {
      const list = []; const y0 = today.getUTCFullYear();
      for (let y = y0; y <= y0 + 1; y++) d.months.forEach((m) => list.push({ y, m, r: d.roll(y, m) }));
      list.sort((a, b) => a.r - b.r);
      const k = list.findIndex((c) => c.r >= today); if (k < 0 || k + 1 >= list.length) return null;
      const a = list[k], b = list[k + 1];
      const days = Math.round((a.r - today) / 86400000);
      return { sym: d.sym, name: d.name, from: d.roots.map((r) => code(r, a.y, a.m)).join(' / ') + ' (' + MN[a.m] + ')', to: d.roots.map((r) => code(r, b.y, b.m)).join(' / ') + ' (' + MN[b.m] + ')', date: MN[a.r.getUTCMonth()] + ' ' + a.r.getUTCDate(), note: d.note(a.y, a.m), soon: days <= 14, days, color: days <= 14 ? '#F0A04B' : '#8796A3', badge: days === 0 ? 'TODAY' : days <= 14 ? 'IN ' + days + ' DAY' + (days === 1 ? '' : 'S') : 'UPCOMING' };
    }).filter(Boolean);
    return out.sort((a, b) => a.days - b.days);
  };

  // Smart Money Flow: scan your flow tickers quietly in the background (when Schwab is connected, which pulls a
  // whole expiry per call) so the page is ready the moment you open it
  const warmFlow = () => {
    const st = XR.status;
    if (!XR.live || !st || !st.schwab || !st.schwab.live) return;
    let ticks = ['SPY', 'QQQ', 'SPX', 'NVDA', 'TSLA', 'AAPL'];
    try { const sv = JSON.parse(localStorage.getItem('xr-pflow') || 'null'); if (sv && Array.isArray(sv.ticks) && sv.ticks.length) ticks = sv.ticks; } catch (e) { /* defaults */ }
    fetch('/api/premflow?symbols=' + encodeURIComponent(ticks.join(',')), { cache: 'no-store' }).catch(() => {});
  };
  setTimeout(warmFlow, 12000); setInterval(warmFlow, 4 * 60000);

  // ---------- VIP access ----------
  // Free: Dashboard, Catalysts & News, Economic Indicators (plus Profile, Support, Data connection).
  // Everything else needs VIP (checked through "Sign in with Discord").
  XR.VIP_PAGES = { watch: 'Watchlist', journal: 'Journal', gamma: 'Gamma Core', dealer: 'Dealer Hedging', pulse: 'Market Pulse', screen: 'Options Screener', flow: 'Smart Money Flow' };
  XR.vip = null;
  window.XRLock = (page) => !!XR.VIP_PAGES[page] && !(XR.vip && XR.vip.xray);   // X-ray access only, Discord VIP never unlocks these
  const vipSig = (v) => (v ? [v.signedIn, v.vip, v.xray, v.inServer, v.busy, v.offline, v.user && v.user.id].join('|') : '');
  XR.checkVip = (how) => fetch(how === 'refresh' ? '/api/vip/refresh' : '/api/vip', { method: how === 'refresh' ? 'POST' : 'GET', cache: 'no-store' })
    .then((r) => r.json()).then((v) => { const changed = vipSig(v) !== vipSig(XR.vip); XR.vip = v; if (changed) { window.dispatchEvent(new CustomEvent('xr-vip', { detail: v })); repaint(); } return v; })
    .catch(() => XR.vip);
  XR.vipSignIn = () => fetch('/api/vip/login', { cache: 'no-store' }).then((r) => r.json()).then((j) => {
    window.open(j.url, '_blank');
    // pick up the result as soon as the browser hands it back
    let n = 0; const iv = setInterval(() => { n++; XR.checkVip().then((v) => { if ((v && v.signedIn) || n > 90) clearInterval(iv); }); }, 2000);
  });
  XR.vipSignOut = () => fetch('/api/vip/logout', { method: 'POST' }).then(() => XR.checkVip());
  XR.checkVip();
  setInterval(() => XR.checkVip(), 60000);

  checkStatus();
  setInterval(checkStatus, 4000);
  kick = tick;
  setInterval(tick, 800);
})();
