// Schwab login reminder: Schwab ends every API login after 7 days. A banner shows from 24 hours before
// that until the user reconnects. It lives outside the app root so re-renders never touch it.
(function () {
  'use strict';
  const SNOOZE_KEY = 'xr-schwab-snooze';
  const H = 3600000;
  let el = null;
  const snoozedUntil = () => { try { return Number(localStorage.getItem(SNOOZE_KEY)) || 0; } catch (e) { return 0; } };
  const snooze = (ms) => { try { localStorage.setItem(SNOOZE_KEY, String(Date.now() + ms)); } catch (e) { /* fine */ } hide(); };
  const left = (ms) => { const h = Math.floor(ms / H); if (h >= 1) return h + (h === 1 ? ' hour' : ' hours'); const m = Math.max(1, Math.round(ms / 60000)); return m + ' min'; };
  const hide = () => { if (el) { el.remove(); el = null; } document.body.classList.remove('xr-has-notice'); };
  const show = (urgent, text) => {
    if (!el) {
      el = document.createElement('div');
      el.setAttribute('role', 'alert');
      el.style.cssText = 'position:fixed;bottom:calc(16px + env(safe-area-inset-bottom,0px));right:calc(16px + env(safe-area-inset-right,0px));z-index:9999;display:flex;flex-wrap:wrap;align-items:center;gap:10px 14px;max-width:min(460px,calc(100% - 32px));box-sizing:border-box;padding:10px 12px 10px 16px;border-radius:12px;font:14px/1.4 "IBM Plex Sans",system-ui,sans-serif;box-shadow:0 16px 40px rgba(0,0,0,.55)';
      el.innerHTML = '<span data-t style="flex:1 1 260px;min-width:0"></span>' +
        '<a href="/setup.html#schwab" style="text-decoration:none;border-radius:8px;padding:7px 12px;font-weight:600;background:#F0A04B;color:#1A1206;white-space:nowrap">Reconnect Schwab</a>' +
        '<button type="button" data-later style="border:0;border-radius:8px;padding:7px 10px;background:transparent;color:#C9B79F;cursor:pointer;font:inherit;white-space:nowrap">Later</button>';
      el.querySelector('[data-later]').addEventListener('click', () => snooze(urgent ? H : 4 * H));
      document.body.appendChild(el); document.body.classList.add('xr-has-notice');
    }
    el.style.background = urgent ? '#3A1F14' : '#2E2414';
    el.style.border = '1px solid ' + (urgent ? '#F2555A' : '#F0A04B');
    el.style.color = '#F4E6D2';
    el.querySelector('[data-t]').textContent = text;
  };
  const check = async () => {
    let s;
    try { const r = await fetch('/api/status', { cache: 'no-store' }); s = await r.json(); } catch (e) { return; }
    const sw = s && s.schwab;
    if (!sw || !sw.hasKeys) return hide();
    const exp = sw.loginExpires; const now = Date.now();
    const expired = !exp || exp <= now || (!sw.live && /login/i.test(sw.message || ''));
    if (expired) {
      if (snoozedUntil() > now) return hide();
      return show(true, exp ? '🔔 Your Schwab login expired. Schwab makes you sign in again every 7 days. Takes 15 seconds.' : '🔔 Schwab keys are saved. Log in with Schwab to finish connecting.');
    }
    if (exp - now < 24 * H) {
      if (snoozedUntil() > now) return hide();
      return show(false, '🔔 Schwab login expires in ' + left(exp - now) + '. Reconnect now so it doesn\'t cut out mid-trade.');
    }
    hide();
  };
  const start = () => { check(); setInterval(check, 60000); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
