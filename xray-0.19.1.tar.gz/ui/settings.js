// X-ray settings: saved on this computer, read anywhere through window.XRSet.
// Also applies the theme and plays alert sounds.
(function () {
  'use strict';
  const KEY = 'xr-settings';
  const DEF = {
    sound: 'ping',          // ping | chime | pulse | lockon | shimmer | scan
    volume: 0.7,            // 0..1
    mute: false,
    desktop: true,          // Windows / Mac pop-up when an alert hits
    theme: 'dark',          // dark | light (beta)
    startPage: '',          // '' = wherever you left off
    tfStock: '',            // '' = remember the last one
    tfOpt: '',
    skipIntro: false,
    logs: true              // attach X-ray's log to support tickets by default
  };
  let cur = Object.assign({}, DEF);
  try { cur = Object.assign({}, DEF, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (e) { /* private mode: defaults */ }

  const SOUNDS = [
    { id: 'ping', name: 'Ping', note: 'One clean ping' },
    { id: 'chime', name: 'Chime', note: 'Two rising notes' },
    { id: 'pulse', name: 'Pulse', note: 'Three quick blips' },
    { id: 'lockon', name: 'Lock-on', note: 'Sweep into a beep' },
    { id: 'shimmer', name: 'Shimmer', note: 'Soft bell chord' },
    { id: 'scan', name: 'Scan', note: 'Low thump + ping' }
  ];

  const applyTheme = () => { document.documentElement.setAttribute('data-theme', cur.theme === 'light' ? 'light' : 'dark'); };
  applyTheme();

  const audio = {};
  const play = (id, force) => {
    if (cur.mute && !force) return;
    const s = SOUNDS.find((x) => x.id === id) ? id : 'ping';
    try {
      const a = audio[s] || (audio[s] = new Audio('sounds/' + s + '.wav'));
      a.volume = Math.max(0, Math.min(1, Number(cur.volume)));
      a.currentTime = 0;
      const p = a.play(); if (p && p.catch) p.catch(() => {});
    } catch (e) { /* no audio device */ }
  };

  window.XRSet = {
    SOUNDS, DEF,
    get: (k) => (k in cur ? cur[k] : DEF[k]),
    all: () => Object.assign({}, cur),
    set: (k, v) => {
      cur[k] = v;
      try { localStorage.setItem(KEY, JSON.stringify(cur)); } catch (e) { /* not saved, still applied */ }
      if (k === 'theme') applyTheme();
      window.dispatchEvent(new CustomEvent('xr-settings', { detail: { k, v } }));
    },
    reset: () => { cur = Object.assign({}, DEF); try { localStorage.removeItem(KEY); } catch (e) { /* fine */ } applyTheme(); window.dispatchEvent(new CustomEvent('xr-settings', { detail: {} })); },
    play: (id) => play(id || cur.sound, true),     // preview button: plays even when muted
    alertSound: () => play(cur.sound, false)
  };

  // start page and default timeframes, applied once when the app first mounts
  let applied = false;
  const boot = () => {
    if (applied) return;
    const c = window.__app && window.__app.c;
    if (!c) { setTimeout(boot, 300); return; }
    applied = true;
    const p = {};
    if (cur.startPage) p.page = cur.startPage;
    if (cur.tfStock) p.tf = cur.tfStock;
    if (cur.tfOpt) p.optTf = cur.tfOpt;
    if (Object.keys(p).length) setTimeout(() => c.setState(p), 400);   // after saved state is restored
  };
  if (!/[#&]pop=/.test(location.hash)) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  }
})();
