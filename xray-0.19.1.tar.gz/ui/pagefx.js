// Page switching: every tab opens at the top, and <body data-xr-page> tells the styles which page is showing.
(function () {
  'use strict';
  if (/[#&]pop=/.test(location.hash)) return;
  const top = () => { window.scrollTo(0, 0); const m = document.querySelector('#app main'); if (m) m.scrollTop = 0; };
  const hook = () => {
    const c = window.__app && window.__app.c;
    if (!c) { setTimeout(hook, 150); return; }
    document.body.setAttribute('data-xr-page', c.state.page || 'dash');
    const orig = c.setState.bind(c);
    c.setState = (p) => {
      const was = c.state.page;
      orig(p);
      const now = c.state.page;
      if (now !== was) {
        document.body.setAttribute('data-xr-page', now);
        // a jump to a section (search results etc.) does its own scrolling after this
        top();
      }
    };
  };
  hook();
})();
