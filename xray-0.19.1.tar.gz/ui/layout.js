// Page layouts: on any page, move widgets around, make them wider or narrower, or hide them.
// It works on top of the pages without changing them: once a page has a custom layout, its main area
// becomes a 12-column grid and every widget gets a slot. Saved per page on this computer.
(function () {
  'use strict';
  const KEY = 'xr-layout-v1';
  let all = {}; try { all = JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { all = {}; }
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(all)); } catch (e) { /* private mode */ } };
  let editing = false;
  const page = () => (window.__app && window.__app.c && window.__app.c.state && window.__app.c.state.page) || 'dash';
  const mainEl = () => document.querySelector('#app main');
  const CARD_SEL = 'section[style*="background: #141C27"], aside[style*="background: #141C27"], section[aria-label="Global news globe"]';

  const cardId = (el, used) => {
    let id = el.getAttribute('aria-label') || '';
    if (!id || id.indexOf('{{') >= 0) { const h = el.querySelector('h1,h2,h3'); id = h ? h.textContent.trim().replace(/\s+/g, ' ').slice(0, 40) : 'Widget'; }
    let k = id, n = 2; while (used.has(k)) k = id + ' ' + n++;
    used.add(k); return k;
  };
  // every top-level widget on the page (not widgets nested inside other widgets)
  const cards = () => {
    const m = mainEl(); if (!m) return [];
    const list = Array.from(m.querySelectorAll(CARD_SEL)).filter((el) => getComputedStyle(el).display !== 'none' || el.hasAttribute('data-xl-card')).filter((el) => { let p = el.parentElement; while (p && p !== m) { if (p.matches && p.matches(CARD_SEL)) return false; p = p.parentElement; } return true; });
    const used = new Set();
    return list.map((el) => ({ el, id: cardId(el, used) }));
  };

  let style = document.getElementById('xr-layout-css');
  if (!style) { style = document.createElement('style'); style.id = 'xr-layout-css'; document.head.appendChild(style); }

  // tag the DOM (attributes survive re-renders thanks to the runtime) and write the grid rules
  const apply = () => {
    const m = mainEl(); if (!m) return;
    const pg = page(); const L = all[pg];
    const on = !!(L || editing);
    if (!on) { if (m.hasAttribute('data-xl-grid')) { m.removeAttribute('data-xl-grid'); m.querySelectorAll('[data-xl-wrap],[data-xl-item],[data-xl-card]').forEach((e) => { e.removeAttribute('data-xl-wrap'); e.removeAttribute('data-xl-item'); e.removeAttribute('data-xl-card'); }); } style.textContent = ''; return; }
    // re-tag from scratch: elements get reused between renders and pages
    m.querySelectorAll('[data-xl-wrap],[data-xl-item],[data-xl-card]').forEach((e) => { e.removeAttribute('data-xl-wrap'); e.removeAttribute('data-xl-item'); e.removeAttribute('data-xl-card'); });
    const cs = cards();
    // measure natural widths once, before the grid takes over
    if (!m.hasAttribute('data-xl-grid')) {
      const mw = m.getBoundingClientRect().width || 1;
      const nat = {};
      cs.forEach((c, i) => { nat[c.id] = { span: Math.max(3, Math.min(12, Math.round(c.el.getBoundingClientRect().width / mw * 12))), order: i }; });
      if (!all[pg]) all[pg] = { cards: nat, hidden: [], natural: nat };
      else all[pg].natural = Object.assign({}, nat, all[pg].natural || {});
    }
    if (!all[pg]) all[pg] = { cards: {}, hidden: [], natural: {} }; // page reached while the grid was already on (e.g. switching pages in edit mode)
    const P = all[pg]; P.cards = P.cards || {}; P.hidden = P.hidden || [];
    // wrappers between main and each widget dissolve into the grid; loose bits (headers, toggles) span the full row
    const wraps = new Set();
    cs.forEach((c) => { c.el.setAttribute('data-xl-card', c.id); let p = c.el.parentElement; while (p && p !== m) { wraps.add(p); p = p.parentElement; } });
    wraps.forEach((w) => { w.setAttribute('data-xl-wrap', ''); Array.from(w.children).forEach((ch) => { if (!wraps.has(ch) && !ch.hasAttribute('data-xl-card')) ch.setAttribute('data-xl-item', ''); }); });
    Array.from(m.children).forEach((ch) => { if (!wraps.has(ch) && !ch.hasAttribute('data-xl-card')) ch.setAttribute('data-xl-item', ''); });
    m.setAttribute('data-xl-grid', '');
    // order: loose items keep their place; widgets fill the widget slots in the user's order
    const seq = [];
    const walk = (el) => { Array.from(el.children).forEach((ch) => { if (ch.hasAttribute('data-xl-card') || ch.hasAttribute('data-xl-item')) seq.push(ch); else if (ch.hasAttribute('data-xl-wrap')) walk(ch); }); };
    walk(m);
    const slots = []; const rules = [];
    seq.forEach((el, i) => { if (el.hasAttribute('data-xl-card')) slots.push(i * 10); else { el.setAttribute('data-xl-item', String(i * 10)); rules.push('[data-xl-item="' + (i * 10) + '"]{order:' + (i * 10) + '}'); } });
    const ids = cs.map((c) => c.id);
    ids.forEach((id) => { if (!P.cards[id]) P.cards[id] = (P.natural && P.natural[id]) || { span: 12, order: 999 }; });
    const ordered = ids.slice().sort((a, b) => (P.cards[a].order - P.cards[b].order) || (ids.indexOf(a) - ids.indexOf(b)));
    const q = (s) => s.replace(/["\\]/g, '\\$&');
    ordered.forEach((id, k) => { const c = P.cards[id]; rules.push('[data-xl-card="' + q(id) + '"]{order:' + (slots[k] !== undefined ? slots[k] : 900 + k) + ';grid-column:span ' + c.span + '}'); if (c.h) rules.push('[data-xl-card="' + q(id) + '"]{height:' + c.h + 'px!important;overflow:auto;display:flex!important;flex-direction:column}[data-xl-card="' + q(id) + '"] #xr-plot,[data-xl-card="' + q(id) + '"] #xr-oplot{flex:1 1 0!important;height:auto!important;min-height:160px}'); if ((P.hidden || []).includes(id) && !editing) rules.push('[data-xl-card="' + q(id) + '"]{display:none!important}'); if ((P.hidden || []).includes(id) && editing) rules.push('[data-xl-card="' + q(id) + '"]{opacity:.35}'); });
    // a widget with a custom height: the chart area inside it grows to fill
    m.querySelectorAll('[data-xl-grow]').forEach((e) => { e.removeAttribute('data-xl-grow'); e.removeAttribute('data-xl-blk'); });
    const isFlex = (e) => /flex/.test(getComputedStyle(e).display);
    const dirOf = (e) => (isFlex(e) && /row/.test(getComputedStyle(e).flexDirection) ? 'row' : 'col');
    cs.forEach((c) => { if (!P.cards[c.id] || !P.cards[c.id].h) return; const plot = c.el.querySelector('#xr-plot,#xr-oplot'); if (!plot) return;
      const chain = []; let e = plot; while (e && e !== c.el) { chain.push(e); e = e.parentElement; }
      const info = chain.map((x) => ({ x, pdir: dirOf(x.parentElement), flex: isFlex(x) }));
      info.forEach((i) => { i.x.setAttribute('data-xl-grow', (i.x === plot ? 'p' : 'w') + i.pdir); if (i.x !== plot && !i.flex) i.x.setAttribute('data-xl-blk', ''); }); });
    style.textContent = rules.join('\n');
    if (editing) drawTools(cs, P);
  };

  // ---------- edit mode tools ----------
  const layer = document.createElement('div'); layer.className = 'xl-layer'; document.body.appendChild(layer);
  const bar = document.createElement('div'); bar.className = 'xl-bar'; document.body.appendChild(bar);
  const btn = document.createElement('button'); btn.type = 'button'; btn.className = 'xl-toggle'; btn.textContent = '✎ Edit layout'; document.body.appendChild(btn);
  btn.addEventListener('click', () => { editing = !editing; refresh(); });
  const names = { dash: 'Dashboard', watch: 'Watchlist', news: 'Catalysts & News', econ: 'Economic Indicators', journal: 'Journal', gamma: 'Gamma Core', screen: 'Options Screener', flow: 'Smart Money Flow', dealer: 'Dealer Hedging', pulse: 'Market Pulse', support: 'Support' };
  const refresh = () => {
    btn.textContent = editing ? '✓ Done' : '✎ Edit layout'; btn.classList.toggle('on', editing);
    document.body.classList.toggle('xl-editing', editing);
    if (!editing) { layer.innerHTML = ''; bar.style.display = 'none'; }
    apply();
    if (editing) {
      const P = all[page()] || { hidden: [] };
      bar.style.display = 'flex';
      bar.innerHTML = '<span><b>Editing ' + (names[page()] || 'page') + '</b> · grab a widget to move it · pull its right edge, bottom or corner to resize · 👁 to hide</span>' +
        ((P.hidden || []).length ? '<span class="xl-hid">Hidden: ' + P.hidden.map((h) => '<button type="button" data-show="' + h.replace(/"/g, '&quot;') + '">＋ ' + h + '</button>').join('') + '</span>' : '') +
        '<button type="button" data-reset>Reset this page</button>';
      bar.querySelectorAll('[data-show]').forEach((b) => b.addEventListener('click', () => { P.hidden = P.hidden.filter((h) => h !== b.getAttribute('data-show')); save(); refresh(); }));
      bar.querySelector('[data-reset]').addEventListener('click', () => { delete all[page()]; save(); const m = mainEl(); if (m) m.removeAttribute('data-xl-grid'); refresh(); });
    }
  };
  let tools = new Map();
  // in edit mode every widget gets a frame on top of it: grab it anywhere to move it, pull the right edge,
  // bottom edge or corner to resize it. Width snaps to the 12-column grid, height snaps to 10px.
  const drawTools = (cs, P) => {
    const seen = new Set();
    cs.forEach((c) => {
      seen.add(c.id);
      let t = tools.get(c.id);
      if (!t) {
        t = document.createElement('div'); t.className = 'xl-frame';
        t.innerHTML = '<div class="xl-tool"><span class="xl-move" title="Drag anywhere on the widget to move it">⠿</span><span class="xl-name"></span><span class="xl-span"></span><button type="button" data-auto title="Back to its normal height">↕ auto</button><button type="button" data-hide title="Hide or show">👁</button></div>' +
          '<span class="xl-h xl-h-r" data-rs="r" title="Drag to resize"></span><span class="xl-h xl-h-b" data-rs="b" title="Drag to resize"></span><span class="xl-h xl-h-br" data-rs="rb" title="Drag to resize"></span>';
        t.querySelector('.xl-name').textContent = c.id;
        t.querySelector('[data-hide]').addEventListener('click', () => { const Q = all[page()]; Q.hidden = Q.hidden || []; Q.hidden = Q.hidden.includes(c.id) ? Q.hidden.filter((h) => h !== c.id) : Q.hidden.concat([c.id]); save(); refresh(); });
        t.querySelector('[data-auto]').addEventListener('click', () => { const Q = all[page()]; delete Q.cards[c.id].h; save(); apply(); });
        t.querySelectorAll('[data-rs]').forEach((h) => h.addEventListener('mousedown', (e) => startResize(e, c.id, h.getAttribute('data-rs'))));
        t.addEventListener('mousedown', (e) => { if (e.button !== 0 || e.target.closest('button,[data-rs]')) return; startMove(e, c.id); });
        layer.appendChild(t); tools.set(c.id, t);
      }
      const cc = P.cards[c.id];
      t.querySelector('.xl-span').textContent = cc.span + '/12' + (cc.h ? ' · ' + cc.h + 'px' : '');
      t.querySelector('[data-auto]').style.display = cc.h ? '' : 'none';
      t.classList.toggle('xl-off', (P.hidden || []).includes(c.id));
    });
    tools.forEach((t, id) => { if (!seen.has(id)) { t.remove(); tools.delete(id); } });
  };
  const place = () => {
    if (editing) {
      const m = mainEl(); if (m) {
        m.querySelectorAll('[data-xl-card]').forEach((el) => { const t = tools.get(el.getAttribute('data-xl-card')); if (!t) return; const r = el.getBoundingClientRect(); t.style.transform = 'translate(' + Math.round(r.left) + 'px,' + Math.round(r.top) + 'px)'; t.style.width = Math.round(r.width) + 'px'; t.style.height = Math.round(r.height) + 'px'; t.style.display = r.width ? 'block' : 'none'; });
      }
    }
    requestAnimationFrame(place);
  };
  requestAnimationFrame(place);

  // auto-scroll the page when dragging near the top or bottom edge
  let scrollV = 0; const scroller = () => { const m = mainEl(); let el = m; while (el && el !== document.body && !(el.scrollHeight > el.clientHeight + 4 && /auto|scroll/.test(getComputedStyle(el).overflowY))) el = el.parentElement; return el && el !== document.body ? el : document.scrollingElement; };
  const edgeScroll = (y) => { scrollV = y < 70 ? -14 : y > window.innerHeight - 70 ? 14 : 0; };
  let scrollRaf = 0; const scrollLoop = () => { if (scrollV) { const sc = scroller(); if (sc) sc.scrollTop += scrollV; } scrollRaf = requestAnimationFrame(scrollLoop); };

  // drag a widget to a new spot: it lands before or after whichever widget the pointer is over
  const startMove = (e, id) => {
    e.preventDefault();
    const P = all[page()]; const m = mainEl(); if (!P || !m) return;
    const ghost = document.createElement('div'); ghost.className = 'xl-ghost'; ghost.textContent = '⠿ ' + id; document.body.appendChild(ghost);
    const els = () => Array.from(m.querySelectorAll('[data-xl-card]'));
    const self = els().find((el) => el.getAttribute('data-xl-card') === id); if (self) self.classList.add('xl-lifted');
    let target = null; scrollRaf = requestAnimationFrame(scrollLoop);
    const mv = (ev) => {
      ghost.style.transform = 'translate(' + (ev.clientX + 12) + 'px,' + (ev.clientY + 12) + 'px)';
      edgeScroll(ev.clientY);
      target = null;
      els().forEach((el) => { const r = el.getBoundingClientRect(); const isIn = ev.clientX >= r.left && ev.clientX <= r.right && ev.clientY >= r.top && ev.clientY <= r.bottom && el.getAttribute('data-xl-card') !== id; const after = isIn && (r.width > m.getBoundingClientRect().width * 0.75 ? ev.clientY > r.top + r.height / 2 : ev.clientX > r.left + r.width / 2); el.classList.toggle('xl-drop-before', isIn && !after); el.classList.toggle('xl-drop-after', isIn && after); if (isIn) target = { id: el.getAttribute('data-xl-card'), after }; });
    };
    const up = () => {
      window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', up); ghost.remove(); cancelAnimationFrame(scrollRaf); scrollV = 0;
      els().forEach((el) => el.classList.remove('xl-drop-before', 'xl-drop-after', 'xl-lifted'));
      if (!target || target.id === id) return;
      const order = Object.keys(P.cards).filter((k) => els().some((el) => el.getAttribute('data-xl-card') === k)).sort((a, b) => P.cards[a].order - P.cards[b].order).filter((k) => k !== id);
      let at = order.indexOf(target.id); if (target.after) at += 1;
      order.splice(at, 0, id);
      order.forEach((k, i) => { P.cards[k].order = i; });
      save(); apply();
    };
    window.addEventListener('mousemove', mv); window.addEventListener('mouseup', up);
  };

  // pull an edge or the corner
  const startResize = (e, id, mode) => {
    e.preventDefault(); e.stopPropagation();
    const P = all[page()]; const m = mainEl(); if (!P || !m) return;
    const el = m.querySelector('[data-xl-card="' + id.replace(/["\\]/g, '\\$&') + '"]'); if (!el) return;
    const r0 = el.getBoundingClientRect(); const mw = m.getBoundingClientRect().width;
    const gap = parseFloat(getComputedStyle(m).columnGap) || 18; const col = (mw - gap * 11) / 12;
    const cc = P.cards[id]; const x0 = e.clientX, y0 = e.clientY;
    document.body.classList.add('xl-resizing'); scrollRaf = requestAnimationFrame(scrollLoop);
    const mv = (ev) => {
      if (mode.indexOf('r') >= 0) { const w = r0.width + (ev.clientX - x0); cc.span = Math.max(3, Math.min(12, Math.round((w + gap) / (col + gap)))); }
      if (mode.indexOf('b') >= 0) { cc.h = Math.max(140, Math.round((r0.height + (ev.clientY - y0)) / 10) * 10); edgeScroll(ev.clientY); }
      apply();
    };
    const up = () => { window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', up); document.body.classList.remove('xl-resizing'); cancelAnimationFrame(scrollRaf); scrollV = 0; save(); apply(); window.dispatchEvent(new Event('resize')); };
    window.addEventListener('mousemove', mv); window.addEventListener('mouseup', up);
  };

  // re-apply after every page render (cheap) and when the page changes
  let pend = false, lastPage = null;
  const mo = new MutationObserver(() => {
    if (pend) return; pend = true;
    queueMicrotask(() => { pend = false; if (page() !== lastPage) { lastPage = page(); tools.forEach((t) => t.remove()); tools = new Map(); const mm = mainEl(); if (mm) { mm.removeAttribute('data-xl-grid'); style.textContent = ''; } if (editing) refresh(); } if (all[page()] || editing) apply(); });
  });
  const start = () => { const a = document.getElementById('app'); if (!a) return setTimeout(start, 200); mo.observe(a, { childList: true, subtree: true }); lastPage = page(); apply(); };
  start();
})();
