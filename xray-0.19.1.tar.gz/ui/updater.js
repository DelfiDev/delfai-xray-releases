// "Update ready" popup. The server downloads and verifies updates in the background;
// this just asks it every minute and offers a restart when a new version is ready.
(function () {
  'use strict';
  if (/[#&]pop=/.test(location.hash)) return;
  const XR = window.XR || (window.XR = {});
  const SKIP = 'xr-update-later';
  let st = null, el = null;
  const css = '#xr-upd{position:fixed;right:18px;top:74px;z-index:9000;width:330px;background:#0E151E;border:1px solid rgba(143,210,236,.45);border-radius:14px;box-shadow:0 18px 50px rgba(0,0,0,.5),0 0 24px rgba(143,210,236,.12);padding:14px 16px;display:flex;flex-direction:column;gap:10px;font-family:"IBM Plex Sans",sans-serif;color:#E8EEF2;animation:xrupin .3s ease-out}'
    + '#xr-upd .h{display:flex;align-items:center;gap:8px;font:600 11px "JetBrains Mono",monospace;letter-spacing:.16em;color:#8FD2EC}'
    + '#xr-upd .v{font-size:15px;font-weight:600}#xr-upd .n{font-size:12.5px;color:#9AA8B4;line-height:1.45;max-height:72px;overflow:auto}'
    + '#xr-upd .b{display:flex;gap:8px}#xr-upd button{border-radius:9px;padding:8px 14px;font-size:13px;cursor:pointer;border:1px solid #2C3D52;background:transparent;color:#9AA8B4}'
    + '#xr-upd button.go{background:#8FD2EC;border-color:#8FD2EC;color:#0E131B;font-weight:600}#xr-upd button.go:hover{filter:brightness(1.08)}'
    + '@keyframes xrupin{from{transform:translateY(-10px);opacity:0}to{transform:none;opacity:1}}';
  const later = () => { try { return sessionStorage.getItem(SKIP); } catch (e) { return null; } };
  const close = () => { if (el) { el.remove(); el = null; } };
  const show = () => {
    if (!st || !st.ready || later() === st.ready || el) return;
    if (!document.getElementById('xr-upd-css')) { const s = document.createElement('style'); s.id = 'xr-upd-css'; s.textContent = css; document.head.appendChild(s); }
    el = document.createElement('div'); el.id = 'xr-upd'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-label', 'Update ready');
    el.innerHTML = '<div class="h">⬆ UPDATE READY</div><div class="v"></div><div class="n"></div><div class="b"><button type="button" class="go">Restart now</button><button type="button" class="l">Later</button></div>';
    el.querySelector('.v').textContent = 'DELFAi X-ray v' + st.ready;
    el.querySelector('.n').textContent = st.notes || 'Fixes and improvements. Takes a few seconds.';
    el.querySelector('.go').addEventListener('click', () => { el.querySelector('.go').textContent = 'Restarting…'; fetch('/api/update/restart', { method: 'POST' }).catch(() => {}); });
    el.querySelector('.l').addEventListener('click', () => { try { sessionStorage.setItem(SKIP, st.ready); } catch (e) { /* fine */ } close(); });
    document.body.appendChild(el);
  };
  const poll = () => fetch('/api/update', { cache: 'no-store' }).then((r) => r.json()).then((j) => { st = j; XR.update = j; show(); window.dispatchEvent(new CustomEvent('xr-update', { detail: j })); }).catch(() => {});
  // "Check for updates" buttons (profile menu, Settings) call this; resolves with a sentence to show
  XR.checkUpdate = () => fetch('/api/update/check', { method: 'POST' }).then((r) => r.json()).then((j) => {
    st = j; XR.update = j; window.dispatchEvent(new CustomEvent('xr-update', { detail: j }));
    try { sessionStorage.removeItem(SKIP); } catch (e) { /* fine */ }
    if (j.ready) { show(); return 'v' + j.ready + ' is ready. Restart to update.'; }
    if (j.error) return 'Could not check right now (' + j.error + ').';
    return 'You’re on the latest version (v' + j.current + ').';
  }).catch(() => 'Could not check right now.');
  setTimeout(poll, 4000); setInterval(poll, 60000);
})();
