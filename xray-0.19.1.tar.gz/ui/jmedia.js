// Journal screenshots + voice notes.
//  XRJMedia: attach pictures to a trade (file picker, drag & drop or paste), view them full size.
//  XRMic: talk instead of type. Uses the browser's speech engine where it exists (phone),
//         otherwise opens the computer's own voice typing (Windows: Win+H; Mac: Fn twice).
(function () {
  'use strict';
  const MAX = 10 * 1024 * 1024;
  const TYPES = { 'image/png': 1, 'image/jpeg': 1, 'image/webp': 1, 'image/gif': 1 };

  const toast = (msg, ms) => {
    let t = document.getElementById('xr-jm-toast');
    if (!t) { t = document.createElement('div'); t.id = 'xr-jm-toast'; t.className = 'xr-jm-toast'; t.setAttribute('role', 'status'); document.body.appendChild(t); }
    t.textContent = msg; t.style.display = 'block';
    clearTimeout(t._h); t._h = setTimeout(() => { t.style.display = 'none'; }, ms || 4000);
  };

  const upload = async (files) => {
    const ids = [];
    for (const f of Array.from(files || [])) {
      if (!TYPES[f.type]) { toast(f.name + ' is not a picture (PNG, JPG, WEBP or GIF).'); continue; }
      if (f.size > MAX) { toast(f.name + ' is over 10 MB.'); continue; }
      try {
        const r = await fetch('/api/jmedia', { method: 'POST', headers: { 'Content-Type': f.type }, body: f });
        const j = await r.json();
        if (r.ok && j.id) ids.push(j.id); else toast(j.error || 'Could not save that picture.');
      } catch (e) { toast('Could not save that picture.'); }
    }
    return ids;
  };

  const pick = (cb) => {
    const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/png,image/jpeg,image/webp,image/gif'; inp.multiple = true;
    inp.onchange = async () => { const ids = await upload(inp.files); if (ids.length) cb(ids); };
    inp.click();
  };

  // full-size viewer
  const view = (list, start, onRemove) => {
    let i = start || 0;
    const ov = document.createElement('div'); ov.className = 'xr-jm-view'; ov.setAttribute('role', 'dialog'); ov.setAttribute('aria-label', 'Trade screenshot');
    const draw = () => {
      ov.innerHTML = '<img alt="Trade screenshot" src="/api/jmedia/' + encodeURIComponent(list[i]) + '">' +
        '<div class="xr-jm-bar">' + (list.length > 1 ? '<button type="button" data-a="prev" aria-label="Previous">‹</button><span>' + (i + 1) + ' / ' + list.length + '</span><button type="button" data-a="next" aria-label="Next">›</button>' : '') +
        (onRemove ? '<button type="button" data-a="del">Remove</button>' : '') + '<button type="button" data-a="close">✕ Close</button></div>';
    };
    const close = () => { ov.remove(); window.removeEventListener('keydown', key, true); };
    const key = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } else if (e.key === 'ArrowRight' && list.length > 1) { i = (i + 1) % list.length; draw(); } else if (e.key === 'ArrowLeft' && list.length > 1) { i = (i - 1 + list.length) % list.length; draw(); } };
    ov.addEventListener('click', (e) => {
      const a = e.target.getAttribute && e.target.getAttribute('data-a');
      if (e.target === ov || a === 'close') close();
      else if (a === 'next') { i = (i + 1) % list.length; draw(); }
      else if (a === 'prev') { i = (i - 1 + list.length) % list.length; draw(); }
      else if (a === 'del') { const id = list[i]; onRemove(id); list = list.filter((x) => x !== id); if (!list.length) close(); else { i = Math.min(i, list.length - 1); draw(); } }
    });
    window.addEventListener('keydown', key, true);
    draw(); document.body.appendChild(ov);
  };

  // paste a screenshot (Ctrl/Cmd+V) or drop files while the "Log trade" form is open
  const formOpen = () => { const c = window.__app && window.__app.c; return !!(c && c.state.page === 'journal' && c.state.jFormOpen); };
  const addToForm = (ids) => { const c = window.__app && window.__app.c; if (c && ids.length) c.setState({ jfMedia: (c.state.jfMedia || []).concat(ids) }); };
  window.addEventListener('paste', async (e) => {
    if (!formOpen() || !e.clipboardData) return;
    const files = Array.from(e.clipboardData.files || []).filter((f) => TYPES[f.type]);
    if (!files.length) return;
    e.preventDefault(); addToForm(await upload(files)); toast('Screenshot attached.', 2000);
  });
  window.addEventListener('dragover', (e) => { if (formOpen()) e.preventDefault(); });
  window.addEventListener('drop', async (e) => {
    if (!formOpen() || !e.dataTransfer || !e.dataTransfer.files.length) return;
    e.preventDefault(); addToForm(await upload(e.dataTransfer.files));
  });

  window.XRJMedia = { pick, view, upload, toast };

  // ---------- voice notes ----------
  const isElectron = /Electron/i.test(navigator.userAgent);
  const isMac = /Mac/i.test(navigator.platform || navigator.userAgent);
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  let rec = null, mode = null, target = null, idleT = null, lastLen = 0;
  const insert = (el, text) => {
    const v = el.value || ''; const s = el.selectionStart != null ? el.selectionStart : v.length, e2 = el.selectionEnd != null ? el.selectionEnd : v.length;
    const pre = v.slice(0, s); const add = (pre && !/\s$/.test(pre) ? ' ' : '') + text;
    el.value = pre + add + v.slice(e2); el.selectionStart = el.selectionEnd = (pre + add).length;
    el.dispatchEvent(new Event('input', { bubbles: true }));
  };

  // the "I'm listening" look: glowing screen edges (like Siri) + a pill at the bottom
  let glow = null;
  const showGlow = () => {
    if (!glow) {
      glow = document.createElement('div'); glow.className = 'xr-listen'; glow.setAttribute('aria-hidden', 'true');
      glow.innerHTML = '<i class="xr-listen-blur"><i class="xr-listen-band"></i></i><i class="xr-listen-edge"></i>';
      const pill = document.createElement('button'); pill.type = 'button'; pill.className = 'xr-listen-pill'; pill.setAttribute('aria-label', 'Stop listening');
      pill.innerHTML = '<span class="xr-listen-bars"><i></i><i></i><i></i><i></i><i></i></span><span>Listening… talk now</span><b>Stop</b>';
      pill.addEventListener('mousedown', (e) => e.preventDefault());   // keep the cursor in the note
      pill.addEventListener('click', () => stop(true));
      glow.appendChild(pill);
    }
    const lbl = glow.querySelector('.xr-listen-pill span:not(.xr-listen-bars)'); if (lbl) lbl.textContent = mode === 'mac' ? 'Tap Fn twice (or 🎤), then talk' : 'Listening… talk now';
    const tt = document.getElementById('xr-jm-toast'); if (tt) tt.style.display = 'none';
    document.body.appendChild(glow); document.body.classList.add('xr-listening');
    requestAnimationFrame(() => glow.classList.add('on'));
  };
  const hideGlow = () => {
    document.body.classList.remove('xr-listening');
    if (glow) { glow.classList.remove('on'); setTimeout(() => { if (glow && !glow.classList.contains('on')) glow.remove(); }, 400); }
  };
  // words arriving (from any engine) = still listening; quiet for a while = it stopped on its own
  const heard = () => {
    if (!mode) return;
    if (glow) { glow.classList.add('heard'); clearTimeout(glow._h); glow._h = setTimeout(() => glow && glow.classList.remove('heard'), 500); }
    arm(9000);
  };
  const arm = (ms) => { clearTimeout(idleT); idleT = setTimeout(() => stop(false), ms); };
  const onInput = () => { if (target && (target.value || '').length !== lastLen) { lastLen = (target.value || '').length; heard(); } };
  const start = (el, how) => {
    mode = how; target = el; lastLen = (el.value || '').length;
    el.addEventListener('input', onInput);
    showGlow(); arm(how === 'browser' ? 30000 : 12000);
  };
  const stop = (byUser) => {
    if (!mode) return;
    const how = mode; mode = null; clearTimeout(idleT);
    if (target) target.removeEventListener('input', onInput);
    hideGlow();
    if (how === 'browser' && rec) { try { rec.stop(); } catch (e) { /* already stopped */ } }
    if (how === 'windows' && byUser) fetch('/api/dictate', { method: 'POST' }).catch(() => {});   // Win+H again closes Windows voice typing
    if (target) setTimeout(() => target && target.focus(), 30);
  };
  // the note closed or lost the page: stop
  setInterval(() => { if (mode && target && !target.isConnected) stop(true); }, 700);
  window.addEventListener('keydown', (e) => { if (e.key === 'Escape' && mode) stop(true); }, true);

  const osDictation = async (el) => {
    el.focus();
    if (isMac) { start(el, 'mac'); return; }
    try {
      const r = await fetch('/api/dictate', { method: 'POST' });
      const j = await r.json().catch(() => ({}));
      if (r.ok && j.ok) { setTimeout(() => el.focus(), 50); start(el, 'windows'); return; }
    } catch (e) { /* fall through */ }
    toast('Press Windows key + H and start talking. Your words go right into the note.', 6000);
  };
  const mic = (el) => {
    if (!el) return;
    if (mode) { stop(true); return; }
    if (!SR || isElectron) { osDictation(el); return; }
    rec = new SR(); rec.lang = navigator.language || 'en-US'; rec.interimResults = true; rec.continuous = true;
    rec.onresult = (e) => { heard(); for (let i = e.resultIndex; i < e.results.length; i++) if (e.results[i].isFinal) insert(el, e.results[i][0].transcript.trim()); };
    rec.onspeechstart = heard;
    rec.onerror = (e) => { const m = mode; stop(false); if (e.error === 'not-allowed' || e.error === 'service-not-allowed') toast('Allow the microphone to talk your notes.'); else if (e.error === 'network' && m) osDictation(el); };
    rec.onend = () => { rec = null; if (mode === 'browser') stop(false); };
    try { rec.start(); start(el, 'browser'); } catch (e) { rec = null; osDictation(el); }
  };
  window.XRMic = { start: mic, stop: () => stop(true), on: () => !!mode };
})();
