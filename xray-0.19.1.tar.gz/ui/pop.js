// Bigger charts, two ways:
//  - Expand: the stock chart or premium chart fills this window (Esc or ✕ to go back).
//  - Pop out: opens it in its own window you can drag to another screen and size however you want.
(function () {
  'use strict';
  const TARGET = { S: '#xr-chart', O: 'section[aria-label="Premium chart"]' };
  const m = /[#&]pop=([SO])/.exec(location.hash);
  const css = document.createElement('style'); document.head.appendChild(css);
  let mode = m ? m[1] : null; // which chart is filling the window right now
  let lastH = 0, tries = 0, t0 = Date.now();

  // make the chart fill the window and give the extra height to the candles
  const fit = () => {
    if (!mode) return;
    const sec = document.querySelector(TARGET[mode]);
    if (!sec) {
      if (m) {
        // popped window: the chart lives on another page, hop there; never leave the window blank
        const pages = mode === 'S' ? ['dash', 'gamma'] : ['watch', 'screen', 'dash'];
        if (window.__app && window.__app.c && tries < pages.length) window.__app.c.setState({ page: pages[tries++] });
        else if (Date.now() - t0 > 6000) { document.body.classList.remove('xr-pop'); mode = null; }
      } else close();
      return;
    }
    document.querySelectorAll('[data-xl-pop]').forEach((e) => { if (e !== sec) e.removeAttribute('data-xl-pop'); });
    if (!sec.hasAttribute('data-xl-pop')) sec.setAttribute('data-xl-pop', '');
    const plot = sec.querySelector('#xr-plot,#xr-oplot'); if (!plot) return;
    const kids = Array.from(sec.children).filter((k) => k.getClientRects().length);
    const sr = sec.getBoundingClientRect(); const pad = parseFloat(getComputedStyle(sec).paddingBottom) || 0;
    const contentH = kids.length ? Math.max(...kids.map((k) => k.getBoundingClientRect().bottom)) - sr.top + sec.scrollTop + pad : sec.scrollHeight;
    const h = Math.max(220, Math.floor(window.innerHeight - (contentH - plot.offsetHeight) - 2));
    if (Math.abs(h - lastH) > 2) { lastH = h; css.textContent = 'body.xr-pop #xr-plot, body.xr-pop #xr-oplot { height: ' + h + 'px !important; }'; }
  };
  window.addEventListener('resize', () => { lastH = 0; css.textContent = ''; requestAnimationFrame(fit); });
  // the price axis next to a chart has a fixed height: keep it the same height as the chart whenever the chart grows
  const axCss = document.createElement('style'); document.head.appendChild(axCss); let axKey = '';
  const syncAxes = () => {
    const rules = [];
    [['S', '#xr-plot'], ['O', '#xr-oplot']].forEach(([k, sel]) => {
      const plot = document.querySelector(sel); if (!plot) return;
      const sec = plot.closest('section'); if (!sec) return;
      const ax = sec.querySelector('div[title^="Drag up or down to scale price"]'); if (!ax) return;
      if (ax.getAttribute('data-xl-yaxis') !== k) ax.setAttribute('data-xl-yaxis', k);
      const h = plot.offsetHeight; const natural = k === 'S' ? 340 : 320;
      if (h && Math.abs(h - natural) > 3) rules.push('[data-xl-yaxis="' + k + '"]{height:' + h + 'px!important}');
    });
    const key = rules.join(''); if (key !== axKey) { axKey = key; axCss.textContent = key; }
  };
  setInterval(() => { fit(); syncAxes(); }, 400);
  window.addEventListener('resize', () => setTimeout(syncAxes, 50));

  const closeBtn = document.createElement('button'); closeBtn.type = 'button'; closeBtn.className = 'xr-pop-close'; closeBtn.textContent = '✕ Close'; closeBtn.title = 'Back to the page (Esc)';
  const close = () => { mode = null; document.body.classList.remove('xr-pop'); document.querySelectorAll('[data-xl-pop]').forEach((e) => e.removeAttribute('data-xl-pop')); css.textContent = ''; lastH = 0; closeBtn.remove(); window.dispatchEvent(new Event('resize')); };
  closeBtn.addEventListener('click', close);
  window.addEventListener('keydown', (e) => { if (e.key === 'Escape' && mode && !m) close(); });

  if (m) {
    document.body.classList.add('xr-pop', 'xr-popwin');
    document.title = (mode === 'S' ? 'Chart' : 'Premium chart') + ' · DELFAi X-ray';
    setTimeout(fit, 100);
    return;
  }

  const expand = (which) => { mode = which; lastH = 0; document.body.classList.add('xr-pop'); document.body.appendChild(closeBtn); fit(); setTimeout(() => { fit(); syncAxes(); }, 60); };
  const popOut = (which) => {
    try { localStorage.setItem('xr-pop-handoff', JSON.stringify(window.__xrStateSnapshot ? window.__xrStateSnapshot() : {})); } catch (e) { /* fine */ }
    const w = window.open(location.origin + location.pathname + '#pop=' + which, 'xrpop' + which + Date.now(), 'width=1200,height=760');
    if (!w) expand(which); // popups blocked: at least make it big here
  };

  // small tabs on the top edge of each chart
  const layer = document.createElement('div'); layer.className = 'xr-pop-layer'; document.body.appendChild(layer);
  const ICON_EXP = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"></path></svg>';
  const ICON_POP = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 4h6v6M20 4l-8 8M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"></path></svg>';
  const tabs = {};
  ['S', 'O'].forEach((w) => {
    const box = document.createElement('div'); box.className = 'xr-poptabs';
    const name = w === 'S' ? 'price chart' : 'premium chart';
    box.innerHTML = '<button type="button" data-a="exp" title="Fill the window with the chart (Esc to go back)" aria-label="Expand the ' + name + '">' + ICON_EXP + ' Expand</button>';
    box.querySelector('[data-a="exp"]').addEventListener('click', () => expand(w));
    layer.appendChild(box); tabs[w] = box;
  });
  // what is really on top at a point, ignoring our own tabs
  const topAt = (px, py) => { const list = document.elementsFromPoint(px, py) || []; return list.find((e) => !layer.contains(e)) || null; };
  const covered = (sec, x, y, w) => {
    const pts = [[x + 6, y + 18], [x + w - 6, y + 18], [x + w / 2, y + 18], [x + 6, y + 4], [x + w - 6, y + 4]];
    return pts.some(([px, py]) => {
      if (px < 0 || py < 0 || px > window.innerWidth || py > window.innerHeight) return false;
      const t = topAt(px, py); if (!t) return false;
      // fine: the chart itself, or the page behind the chart's top edge
      if (sec.contains(t) || t.contains(sec)) return false;
      return true;
    });
  };
  const place = () => {
    const hide = document.body.classList.contains('xl-editing') || !!mode;
    Object.keys(tabs).forEach((w) => {
      const b = tabs[w]; const sec = document.querySelector(TARGET[w]);
      const r = sec && sec.getBoundingClientRect();
      if (hide || !r || !r.width || r.bottom < 0 || r.top > window.innerHeight) { b.style.display = 'none'; return; }
      const x = Math.round(r.right - (b.offsetWidth || 90) - 22), y = Math.round(r.top - 11);
      // only show the tab when nothing (menus, search results, notes, pop-ups) is sitting on top of that corner of the chart
      if (covered(sec, x, y, b.offsetWidth || 90)) { b.style.display = 'none'; return; }
      b.style.display = 'flex'; b.style.transform = 'translate(' + x + 'px,' + y + 'px)';
    });
    requestAnimationFrame(place);
  };
  requestAnimationFrame(place);
})();
