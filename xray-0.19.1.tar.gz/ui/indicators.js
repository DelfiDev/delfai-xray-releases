// X-ray chart indicators: everything that can be built from the broker's candles (open, high, low, close, volume, time).
// Computed once per candle update (cached), drawn on the price chart or in panels under it.
(function () {
  'use strict';
  const NaNs = (n) => new Array(n).fill(NaN);
  const sma = (a, n) => { const o = NaNs(a.length); let s = 0, c = 0; for (let i = 0; i < a.length; i++) { const x = a[i]; if (Number.isFinite(x)) { s += x; c++; } if (i >= n) { const y = a[i - n]; if (Number.isFinite(y)) { s -= y; c--; } } if (i >= n - 1 && c > 0) o[i] = s / c; } return o; };
  const ema = (a, n) => { const o = NaNs(a.length); const k = 2 / (n + 1); let e = NaN; for (let i = 0; i < a.length; i++) { const x = a[i]; if (!Number.isFinite(x)) { o[i] = e; continue; } e = Number.isFinite(e) ? x * k + e * (1 - k) : x; o[i] = e; } return o; };
  const rma = (a, n) => { const o = NaNs(a.length); let e = NaN, s = 0, c = 0; for (let i = 0; i < a.length; i++) { const x = a[i]; if (!Number.isFinite(x)) { o[i] = e; continue; } if (!Number.isFinite(e)) { s += x; c++; if (c === n) { e = s / n; o[i] = e; } continue; } e = (e * (n - 1) + x) / n; o[i] = e; } return o; };
  const stdev = (a, n) => { const o = NaNs(a.length); for (let i = n - 1; i < a.length; i++) { let m = 0; for (let j = i - n + 1; j <= i; j++) m += a[j]; m /= n; let v = 0; for (let j = i - n + 1; j <= i; j++) v += (a[j] - m) * (a[j] - m); o[i] = Math.sqrt(v / n); } return o; };
  const hh = (a, n) => a.map((_, i) => (i >= n - 1 ? Math.max(...a.slice(i - n + 1, i + 1)) : NaN));
  const ll = (a, n) => a.map((_, i) => (i >= n - 1 ? Math.min(...a.slice(i - n + 1, i + 1)) : NaN));
  const trs = (h, l, c) => h.map((x, i) => (i ? Math.max(x - l[i], Math.abs(x - c[i - 1]), Math.abs(l[i] - c[i - 1])) : x - l[i]));
  const linregAt = (a, end, n) => { let sx = 0, sy = 0, sxy = 0, sxx = 0; for (let k = 0; k < n; k++) { const y = a[end - n + 1 + k]; sx += k; sy += y; sxy += k * y; sxx += k * k; } const slope = (n * sxy - sx * sy) / (n * sxx - sx * sx || 1); const icpt = (sy - slope * sx) / n; return { slope, icpt }; };
  const lsma = (a, n) => { const o = NaNs(a.length); for (let i = n - 1; i < a.length; i++) { let ok = true; for (let k = i - n + 1; k <= i; k++) if (!Number.isFinite(a[k])) { ok = false; break; } if (!ok) continue; const r = linregAt(a, i, n); o[i] = r.icpt + r.slope * (n - 1); } return o; };
  const shift = (a, k) => { const o = NaNs(a.length); for (let i = 0; i < a.length; i++) { const j = i - k; if (j >= 0 && j < a.length) o[i] = a[j]; } return o; };

  // ET date + minute of day for each candle (sessions, prior day, pre-market, opening range)
  const etFmt = new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false });
  const etCache = new WeakMap();
  const etOf = (cs) => {
    if (!cs.length || !cs[0].t) return null;
    let r = etCache.get(cs); if (r) return r;
    r = cs.map((b) => { const o = {}; etFmt.formatToParts(new Date(b.t)).forEach((p) => { o[p.type] = p.value; }); return { d: o.year + '-' + o.month + '-' + o.day, m: (Number(o.hour) % 24) * 60 + Number(o.minute) }; });
    etCache.set(cs, r); return r;
  };
  // completed regular-session days: [{d, h, l, c, first, last}]
  const days = (cs, et) => {
    const out = []; let cur = null;
    cs.forEach((b, i) => { const e = et[i]; if (e.m < 570 || e.m >= 960) return; if (!cur || cur.d !== e.d) { cur = { d: e.d, h: b.h, l: b.l, c: b.c, o: b.o, first: i, last: i }; out.push(cur); } else { cur.h = Math.max(cur.h, b.h); cur.l = Math.min(cur.l, b.l); cur.c = b.c; cur.last = i; } });
    return out;
  };

  const C = { cyan: '#8FD2EC', orange: '#F0A04B', pink: '#F472B6', white: '#E8EEF2', blue: '#4E7EBE', violet: '#A78BFA', green: '#34D399', red: '#F2555A', yellow: '#F2C14E', teal: '#2DD4BF', grey: '#8796A3', lime: '#A3E635' };

  // ---- catalog: id, name, group, kind ('line' overlays, 'level' horizontal levels, 'pane' lower panels), params, color ----
  const MA = (id, name, type, len, color) => ({ id, name, group: 'Moving averages', params: { len }, color, calc: (d, p) => ({ lines: [{ arr: (type === 'ema' ? ema : type === 'sma' ? sma : rma)(d.c, Math.max(1, p.len | 0)), color, w: 1.5 }], legend: [{ label: name.split(' ')[0] + ' ' + p.len, color, i: 0 }] }) });
  const CAT = [
    MA('ema9', 'EMA', 'ema', 9, C.cyan), MA('ema21', 'EMA', 'ema', 21, C.lime), MA('ema50', 'EMA', 'ema', 50, C.orange), MA('ema200', 'EMA', 'ema', 200, C.violet),
    MA('sma20', 'SMA', 'sma', 20, C.yellow), MA('sma50', 'SMA', 'sma', 50, C.teal), MA('sma200', 'SMA', 'sma', 200, C.red), MA('smma200', 'SMMA', 'smma', 200, C.white),
    { id: 'vwap', name: 'VWAP', group: 'VWAP & key levels', params: {}, color: C.pink, calc: (d) => ({ lines: [{ arr: vwap(d).v, color: C.pink, w: 1.5 }], legend: [{ label: 'VWAP', color: C.pink, i: 0 }] }) },
    { id: 'vwapb', name: 'VWAP bands', group: 'VWAP & key levels', params: { mult: 2 }, color: C.pink, calc: (d, p) => { const r = vwap(d); const m = +p.mult || 2; const up1 = r.v.map((x, i) => x + r.sd[i]), lo1 = r.v.map((x, i) => x - r.sd[i]), up2 = r.v.map((x, i) => x + m * r.sd[i]), lo2 = r.v.map((x, i) => x - m * r.sd[i]); return { lines: [{ arr: up1, color: 'rgba(244,114,182,.55)', w: 1, dash: '3 3' }, { arr: lo1, color: 'rgba(244,114,182,.55)', w: 1, dash: '3 3' }, { arr: up2, color: 'rgba(244,114,182,.8)', w: 1 }, { arr: lo2, color: 'rgba(244,114,182,.8)', w: 1 }], fills: [{ up: up2, lo: lo2, color: 'rgba(244,114,182,.05)' }], legend: [{ label: 'VWAP ±' + m + 'σ', color: C.pink, i: 2, j: 3 }] }; } },
    { id: 'avwap', name: 'Anchored VWAP', group: 'VWAP & key levels', params: {}, color: C.yellow, anchor: true, calc: (d, p, x) => { const a = x.anchor; if (a == null) return { note: 'Click "Pick" then a candle' }; let i0 = d.t ? d.t.findIndex((t) => t >= a) : a; if (i0 < 0) return {}; const v = NaNs(d.N); let pv = 0, vv = 0; for (let i = i0; i < d.N; i++) { const tp = (d.h[i] + d.l[i] + d.c[i]) / 3; pv += tp * d.v[i]; vv += d.v[i]; v[i] = vv ? pv / vv : NaN; } return { lines: [{ arr: v, color: C.yellow, w: 1.6 }], legend: [{ label: 'AVWAP', color: C.yellow, i: 0 }] }; } },
    { id: 'pdhl', name: 'Previous day high / low / close', group: 'VWAP & key levels', params: {}, color: C.white, needT: true, calc: (d) => { const D = d.days; if (!D || D.length < 2) return {}; const pdIdx = D[D.length - 1].d === d.et[d.N - 1].d ? D.length - 2 : D.length - 1; const p = D[pdIdx]; if (!p) return {}; return { levels: [{ v: p.h, color: C.green, label: 'PDH', dash: '6 4' }, { v: p.l, color: C.red, label: 'PDL', dash: '6 4' }, { v: p.c, color: C.grey, label: 'PDC', dash: '2 4' }] }; } },
    { id: 'pm', name: 'Pre-market high / low', group: 'VWAP & key levels', params: {}, color: C.violet, needT: true, calc: (d) => { const day = d.et[d.N - 1].d; let h = -Infinity, l = Infinity; for (let i = d.N - 1; i >= 0 && d.et[i].d === day; i--) { if (d.et[i].m >= 240 && d.et[i].m < 570) { h = Math.max(h, d.h[i]); l = Math.min(l, d.l[i]); } } if (!Number.isFinite(h)) return { note: 'No pre-market candles from your broker on this timeframe' }; return { levels: [{ v: h, color: C.violet, label: 'PM high', dash: '4 3' }, { v: l, color: C.violet, label: 'PM low', dash: '4 3' }] }; } },
    { id: 'orb', name: 'Opening range', group: 'VWAP & key levels', params: { min: 15 }, color: C.teal, needT: true, calc: (d, p) => { const mins = Math.max(1, +p.min || 15); const day = d.et[d.N - 1].d; let h = -Infinity, l = Infinity; for (let i = d.N - 1; i >= 0 && d.et[i].d === day; i--) { const m = d.et[i].m; if (m >= 570 && m < 570 + mins) { h = Math.max(h, d.h[i]); l = Math.min(l, d.l[i]); } } if (!Number.isFinite(h)) return { note: 'Opening range shows on intraday timeframes once the session opens' }; return { levels: [{ v: h, color: C.teal, label: 'OR ' + mins + 'm high', dash: '' }, { v: l, color: C.teal, label: 'OR ' + mins + 'm low', dash: '' }] }; } },
    { id: 'piv', name: 'Pivot points (daily)', group: 'VWAP & key levels', params: {}, color: C.orange, needT: true, calc: (d) => { const D = d.days; if (!D || D.length < 2) return {}; const p = D[D[D.length - 1].d === d.et[d.N - 1].d ? D.length - 2 : D.length - 1]; if (!p) return {}; const P = (p.h + p.l + p.c) / 3; return { levels: [{ v: P + (p.h - p.l), color: C.red, label: 'R2', dash: '2 3' }, { v: 2 * P - p.l, color: C.red, label: 'R1', dash: '2 3' }, { v: P, color: C.orange, label: 'Pivot', dash: '2 3' }, { v: 2 * P - p.h, color: C.green, label: 'S1', dash: '2 3' }, { v: P - (p.h - p.l), color: C.green, label: 'S2', dash: '2 3' }] }; } },
    { id: 'bb', name: 'Bollinger Bands', group: 'Bands & channels', params: { len: 20, mult: 2 }, color: C.blue, calc: (d, p) => { const n = Math.max(2, p.len | 0), m = +p.mult || 2; const mid = sma(d.c, n), sd = stdev(d.c, n); const up = mid.map((x, i) => x + m * sd[i]), lo = mid.map((x, i) => x - m * sd[i]); return { lines: [{ arr: up, color: C.blue, w: 1.2 }, { arr: mid, color: 'rgba(78,126,190,.7)', w: 1, dash: '4 3' }, { arr: lo, color: C.blue, w: 1.2 }], fills: [{ up, lo, color: 'rgba(78,126,190,.10)' }], legend: [{ label: 'BB', color: C.blue, i: 0, j: 2 }] }; } },
    { id: 'kc', name: 'Keltner Channels', group: 'Bands & channels', params: { len: 20, mult: 2 }, color: C.teal, calc: (d, p) => { const n = Math.max(2, p.len | 0), m = +p.mult || 2; const mid = ema(d.c, n), a = rma(trs(d.h, d.l, d.c), 10); const up = mid.map((x, i) => x + m * a[i]), lo = mid.map((x, i) => x - m * a[i]); return { lines: [{ arr: up, color: C.teal, w: 1.1 }, { arr: mid, color: 'rgba(45,212,191,.6)', w: 1, dash: '4 3' }, { arr: lo, color: C.teal, w: 1.1 }], fills: [{ up, lo, color: 'rgba(45,212,191,.06)' }], legend: [{ label: 'KC', color: C.teal, i: 0, j: 2 }] }; } },
    { id: 'dc', name: 'Donchian Channels', group: 'Bands & channels', params: { len: 20 }, color: C.yellow, calc: (d, p) => { const n = Math.max(2, p.len | 0); const up = hh(d.h, n), lo = ll(d.l, n), mid = up.map((x, i) => (x + lo[i]) / 2); return { lines: [{ arr: up, color: C.yellow, w: 1.1 }, { arr: mid, color: 'rgba(242,193,78,.5)', w: 1, dash: '4 3' }, { arr: lo, color: C.yellow, w: 1.1 }], legend: [{ label: 'DC', color: C.yellow, i: 0, j: 2 }] }; } },
    { id: 'linreg', name: 'Linear regression channel', group: 'Bands & channels', params: { len: 100, mult: 2 }, color: C.cyan, calc: (d, p) => { const n = Math.min(d.N, Math.max(10, p.len | 0)), m = +p.mult || 2; const end = d.N - 1; const { slope, icpt } = linregAt(d.c, end, n); const mid = NaNs(d.N), up = NaNs(d.N), lo = NaNs(d.N); let ss = 0; for (let k = 0; k < n; k++) { const f = icpt + slope * k; ss += (d.c[end - n + 1 + k] - f) * (d.c[end - n + 1 + k] - f); } const sd = Math.sqrt(ss / n); for (let k = 0; k < n; k++) { const i = end - n + 1 + k, f = icpt + slope * k; mid[i] = f; up[i] = f + m * sd; lo[i] = f - m * sd; } return { lines: [{ arr: up, color: C.cyan, w: 1.2 }, { arr: mid, color: C.cyan, w: 1.4, dash: '5 4' }, { arr: lo, color: C.cyan, w: 1.2 }], fills: [{ up, lo, color: 'rgba(143,210,236,.06)' }], legend: [{ label: 'LinReg', color: C.cyan, i: 1 }] }; } },
    { id: 'st', name: 'Supertrend', group: 'Trend', params: { len: 10, mult: 3 }, color: C.green, calc: (d, p) => { const n = Math.max(1, p.len | 0), m = +p.mult || 3; const a = rma(trs(d.h, d.l, d.c), n); const upL = NaNs(d.N), dnL = NaNs(d.N); let fu = NaN, fl = NaN, dir = 1; for (let i = 0; i < d.N; i++) { if (!Number.isFinite(a[i])) continue; const mid = (d.h[i] + d.l[i]) / 2, bu = mid + m * a[i], bl = mid - m * a[i]; fu = !Number.isFinite(fu) || bu < fu || d.c[i - 1] > fu ? bu : fu; fl = !Number.isFinite(fl) || bl > fl || d.c[i - 1] < fl ? bl : fl; if (dir === 1 && d.c[i] < fl) dir = -1; else if (dir === -1 && d.c[i] > fu) dir = 1; if (dir === 1) upL[i] = fl; else dnL[i] = fu; } return { lines: [{ arr: upL, color: C.green, w: 1.8 }, { arr: dnL, color: C.red, w: 1.8 }], legend: [{ label: 'ST', color: C.green, i: 0, alt: 1, altColor: C.red }] }; } },
    { id: 'psar', name: 'Parabolic SAR', group: 'Trend', params: { step: 0.02, max: 0.2 }, color: C.white, calc: (d, p) => { const st0 = +p.step || 0.02, mx = +p.max || 0.2; const s = NaNs(d.N); if (d.N < 3) return {}; let up = d.c[1] >= d.c[0], af = st0, ep = up ? d.h[0] : d.l[0], sar = up ? d.l[0] : d.h[0]; const col = []; for (let i = 1; i < d.N; i++) { sar = sar + af * (ep - sar); if (up) { sar = Math.min(sar, d.l[i - 1], i > 1 ? d.l[i - 2] : d.l[i - 1]); if (d.l[i] < sar) { up = false; sar = ep; ep = d.l[i]; af = st0; } else if (d.h[i] > ep) { ep = d.h[i]; af = Math.min(mx, af + st0); } } else { sar = Math.max(sar, d.h[i - 1], i > 1 ? d.h[i - 2] : d.h[i - 1]); if (d.h[i] > sar) { up = true; sar = ep; ep = d.h[i]; af = st0; } else if (d.l[i] < ep) { ep = d.l[i]; af = Math.min(mx, af + st0); } } s[i] = sar; col[i] = up ? C.green : C.red; } return { dots: [{ arr: s, colors: col }], legend: [{ label: 'SAR', color: C.white, dot: 0 }] }; } },
    { id: 'ichi', name: 'Ichimoku Cloud', group: 'Trend', params: { conv: 9, base: 26, span: 52 }, color: C.violet, calc: (d, p) => { const a = Math.max(2, p.conv | 0), b = Math.max(2, p.base | 0), c = Math.max(2, p.span | 0); const mid = (n) => { const H = hh(d.h, n), L = ll(d.l, n); return H.map((x, i) => (x + L[i]) / 2); }; const ten = mid(a), kij = mid(b); const sa = shift(ten.map((x, i) => (x + kij[i]) / 2), b), sb = shift(mid(c), b), chi = shift(d.c, -b); return { lines: [{ arr: ten, color: C.cyan, w: 1.1 }, { arr: kij, color: C.red, w: 1.1 }, { arr: sa, color: 'rgba(52,211,153,.7)', w: 1 }, { arr: sb, color: 'rgba(242,85,90,.7)', w: 1 }, { arr: chi, color: 'rgba(167,139,250,.6)', w: 1 }], fills: [{ up: sa, lo: sb, color: 'rgba(167,139,250,.08)' }], legend: [{ label: 'Tenkan', color: C.cyan, i: 0 }, { label: 'Kijun', color: C.red, i: 1 }] }; } },
    { id: 'vprof', name: 'Volume profile (visible range)', group: 'Volume', params: { rows: 24 }, color: C.blue, profile: true, calc: () => ({}) },
    { id: 'lsma', name: 'Linear regression curve (LSMA)', group: 'Bands & channels', params: { len: 25 }, color: C.lime, calc: (d, p) => ({ lines: [{ arr: lsma(d.c, Math.max(2, p.len | 0)), color: C.lime, w: 1.5 }], legend: [{ label: 'LSMA ' + (p.len | 0), color: C.lime, i: 0 }] }) },
    { id: 'lrc', name: 'Linear regression candles', group: 'Bands & channels', params: { len: 11, sig: 7 }, color: C.white, calc: (d, p) => { const n = Math.max(2, p.len | 0); const o = lsma(d.o, n), c = lsma(d.c, n), h0 = lsma(d.h, n), l0 = lsma(d.l, n); const h = h0.map((x, i) => Math.max(x, o[i], c[i])), l = l0.map((x, i) => Math.min(x, o[i], c[i])); const sig = sma(c, Math.max(1, p.sig | 0)); return { candles: { o, h, l, c }, lines: [{ arr: sig, color: C.white, w: 1.2 }], legend: [{ label: 'LR signal', color: C.white, i: 0 }] }; } },
    { id: 'vector', name: 'Vector candles (volume colors)', group: 'Volume', params: { len: 10 }, color: C.lime, vector: true, calc: () => ({}) },
    // ---- lower panels ----
    { id: 'rsi', name: 'RSI', group: 'Lower panels', pane: true, params: { len: 14 }, color: C.violet, calc: (d, p) => { const n = Math.max(2, p.len | 0); const ch = d.c.map((x, i) => (i ? x - d.c[i - 1] : 0)); const g = rma(ch.map((x) => Math.max(0, x)), n), l = rma(ch.map((x) => Math.max(0, -x)), n); const r = g.map((x, i) => (l[i] === 0 ? 100 : 100 - 100 / (1 + x / l[i]))); return { pane: { name: 'RSI ' + n, min: 0, max: 100, lines: [{ arr: r, color: C.violet }], levels: [70, 30], fill: [30, 70] } }; } },
    { id: 'macd', name: 'MACD', group: 'Lower panels', pane: true, params: { fast: 12, slow: 26, sig: 9 }, color: C.cyan, calc: (d, p) => { const f = ema(d.c, p.fast | 0 || 12), s = ema(d.c, p.slow | 0 || 26); const m = f.map((x, i) => x - s[i]); const sg = ema(m, p.sig | 0 || 9); const h = m.map((x, i) => x - sg[i]); return { pane: { name: 'MACD ' + (p.fast | 0) + ' ' + (p.slow | 0) + ' ' + (p.sig | 0), lines: [{ arr: m, color: C.cyan }, { arr: sg, color: C.orange }], hist: { arr: h, up: 'rgba(52,211,153,.6)', dn: 'rgba(242,85,90,.6)' }, levels: [0] } }; } },
    { id: 'stoch', name: 'Stochastic', group: 'Lower panels', pane: true, params: { k: 14, smooth: 3, d: 3 }, color: C.cyan, calc: (d, p) => { const n = Math.max(2, p.k | 0); const H = hh(d.h, n), L = ll(d.l, n); const raw = d.c.map((x, i) => (H[i] - L[i] ? (x - L[i]) / (H[i] - L[i]) * 100 : 50)); const k = sma(raw, Math.max(1, p.smooth | 0)), dd = sma(k, Math.max(1, p.d | 0)); return { pane: { name: 'Stoch ' + n, min: 0, max: 100, lines: [{ arr: k, color: C.cyan }, { arr: dd, color: C.orange }], levels: [80, 20], fill: [20, 80] } }; } },
    { id: 'atr', name: 'ATR', group: 'Lower panels', pane: true, params: { len: 14 }, color: C.orange, calc: (d, p) => ({ pane: { name: 'ATR ' + (p.len | 0), lines: [{ arr: rma(trs(d.h, d.l, d.c), Math.max(1, p.len | 0)), color: C.orange }] } }) },
    { id: 'adx', name: 'ADX / DMI', group: 'Lower panels', pane: true, params: { len: 14 }, color: C.yellow, calc: (d, p) => { const n = Math.max(2, p.len | 0); const up = d.h.map((x, i) => (i ? x - d.h[i - 1] : 0)), dn = d.l.map((x, i) => (i ? d.l[i - 1] - x : 0)); const pdm = up.map((x, i) => (x > dn[i] && x > 0 ? x : 0)), ndm = dn.map((x, i) => (x > up[i] && x > 0 ? x : 0)); const tr = rma(trs(d.h, d.l, d.c), n); const pdi = rma(pdm, n).map((x, i) => 100 * x / tr[i]), ndi = rma(ndm, n).map((x, i) => 100 * x / tr[i]); const dx = pdi.map((x, i) => (x + ndi[i] ? 100 * Math.abs(x - ndi[i]) / (x + ndi[i]) : 0)); return { pane: { name: 'ADX ' + n, min: 0, lines: [{ arr: rma(dx, n), color: C.yellow }, { arr: pdi, color: C.green }, { arr: ndi, color: C.red }], levels: [25] } }; } },
    { id: 'obv', name: 'On-balance volume', group: 'Lower panels', pane: true, params: {}, color: C.teal, calc: (d) => { let o = 0; const a = d.c.map((x, i) => (o += i ? (x > d.c[i - 1] ? d.v[i] : x < d.c[i - 1] ? -d.v[i] : 0) : 0)); return { pane: { name: 'OBV', lines: [{ arr: a, color: C.teal }], fmt: 'k' } }; } },
    { id: 'mfi', name: 'Money Flow Index', group: 'Lower panels', pane: true, params: { len: 14 }, color: C.green, calc: (d, p) => { const n = Math.max(2, p.len | 0); const tp = d.c.map((x, i) => (d.h[i] + d.l[i] + x) / 3); const pos = tp.map((x, i) => (i && x > tp[i - 1] ? x * d.v[i] : 0)), neg = tp.map((x, i) => (i && x < tp[i - 1] ? x * d.v[i] : 0)); const ps = sma(pos, n), ns = sma(neg, n); const r = ps.map((x, i) => (ns[i] === 0 ? 100 : 100 - 100 / (1 + x / ns[i]))); return { pane: { name: 'MFI ' + n, min: 0, max: 100, lines: [{ arr: r, color: C.green }], levels: [80, 20] } }; } },
    { id: 'cci', name: 'CCI', group: 'Lower panels', pane: true, params: { len: 20 }, color: C.pink, calc: (d, p) => { const n = Math.max(2, p.len | 0); const tp = d.c.map((x, i) => (d.h[i] + d.l[i] + x) / 3); const m = sma(tp, n); const r = tp.map((x, i) => { if (i < n - 1) return NaN; let md = 0; for (let j = i - n + 1; j <= i; j++) md += Math.abs(tp[j] - m[i]); md /= n; return md ? (x - m[i]) / (0.015 * md) : 0; }); return { pane: { name: 'CCI ' + n, lines: [{ arr: r, color: C.pink }], levels: [100, -100] } }; } },
    { id: 'willr', name: 'Williams %R', group: 'Lower panels', pane: true, params: { len: 14 }, color: C.cyan, calc: (d, p) => { const n = Math.max(2, p.len | 0); const H = hh(d.h, n), L = ll(d.l, n); return { pane: { name: '%R ' + n, min: -100, max: 0, lines: [{ arr: d.c.map((x, i) => (H[i] - L[i] ? (H[i] - x) / (H[i] - L[i]) * -100 : -50)), color: C.cyan }], levels: [-20, -80] } }; } },
    { id: 'rvol', name: 'Relative volume', group: 'Lower panels', pane: true, params: { len: 20 }, color: C.blue, calc: (d, p) => { const a = sma(d.v, Math.max(2, p.len | 0)); const r = d.v.map((x, i) => (a[i] ? x / a[i] : NaN)); return { pane: { name: 'RVOL ' + (p.len | 0), min: 0, hist: { arr: r, up: 'rgba(143,210,236,.55)', dn: 'rgba(143,210,236,.55)', hot: 2, hotColor: 'rgba(240,160,75,.85)' }, levels: [1], fmt: 'x' } }; } },
    { id: 'sqz', name: 'Squeeze momentum', group: 'Lower panels', pane: true, params: { len: 20 }, color: C.lime, calc: (d, p) => { const n = Math.max(2, p.len | 0); const mid = sma(d.c, n), sd = stdev(d.c, n), a = rma(trs(d.h, d.l, d.c), n); const on = mid.map((x, i) => (Number.isFinite(sd[i]) && Number.isFinite(a[i]) ? 2 * sd[i] < 1.5 * a[i] : false)); const H = hh(d.h, n), L = ll(d.l, n); const base = d.c.map((x, i) => x - ((H[i] + L[i]) / 2 + mid[i]) / 2); const mom = base.map((_, i) => { if (i < 2 * n) return NaN; const { slope, icpt } = linregAt(base, i, n); return icpt + slope * (n - 1); }); return { pane: { name: 'Squeeze ' + n, hist: { arr: mom, up: 'rgba(52,211,153,.7)', dn: 'rgba(242,85,90,.7)' }, levels: [0], zeroDots: on } }; } }
  ];
  const BYID = {}; CAT.forEach((x) => { BYID[x.id] = x; });

  function vwap(d) {
    if (d._vw) return d._vw;
    const v = NaNs(d.N), sd = NaNs(d.N); let pv = 0, vv = 0, p2 = 0;
    for (let i = 0; i < d.N; i++) {
      const reset = d.et ? (i === 0 || d.et[i].d !== d.et[i - 1].d) : (i % d.perSession === 0);
      if (reset) { pv = 0; vv = 0; p2 = 0; }
      const tp = (d.h[i] + d.l[i] + d.c[i]) / 3; pv += tp * d.v[i]; vv += d.v[i]; p2 += tp * tp * d.v[i];
      v[i] = vv ? pv / vv : tp; sd[i] = vv ? Math.sqrt(Math.max(0, p2 / vv - v[i] * v[i])) : 0;
    }
    d._vw = { v, sd }; return d._vw;
  }

  // ---- settings helpers ----
  const DEFAULT_ON = { ema9: true, ema50: true, vwap: true };
  const defOf = (st) => st._def || DEFAULT_ON;
  const isOn = (st, id) => (st.ind && id in st.ind ? !!st.ind[id] : !!defOf(st)[id]);
  const paramsOf = (st, x) => Object.assign({}, x.params, (st.indP && st.indP[x.id]) || {});

  // ---- compute (cached per candle set + settings) ----
  const caches = {};
  function compute(cs, st, opt) {
    const on = CAT.filter((x) => isOn(st, x.id));
    const anchor = st.indA && st.indA[st.chartSym];
    const key = cs.length + '|' + (cs.length ? cs[cs.length - 1].t + ':' + cs[cs.length - 1].c + ':' + cs[0].c : '') + '|' + st.chartSym + '|' + st.tf + '|' + on.map((x) => x.id + JSON.stringify(paramsOf(st, x))).join(',') + '|' + anchor;
    const ns = opt.ns || 'S'; const cc = caches[ns];
    if (cc && cc.key === key && cc.val.cs === cs) return cc.val;
    const N = cs.length;
    const d = { N, o: cs.map((b) => b.o), h: cs.map((b) => b.h), l: cs.map((b) => b.l), c: cs.map((b) => b.c), v: cs.map((b) => b.v || 0), t: cs[0] && cs[0].t ? cs.map((b) => b.t) : null, perSession: opt.perSession || N };
    d.et = etOf(cs); d.days = d.et ? days(cs, d.et) : null;
    const res = [];
    on.forEach((x) => {
      if (x.needT && !d.et) { res.push({ x, out: { note: 'Needs live candles' } }); return; }
      let out = {};
      try { out = x.calc(d, paramsOf(st, x), { anchor }) || {}; } catch (e) { out = { note: 'Could not calculate' }; }
      res.push({ x, out });
    });
    const val = { cs, d, res, on }; caches[ns] = { key, val };
    return val;
  }

  // ---- turn results into things the chart template can draw (percent coordinates of the visible window) ----
  function build(app, st, cs, o) {
    const { start, n, Y, f2, habs, master } = o;
    const out = { gLines: [], gFills: [], gDots: [], gLevels: [], gProf: [], panes: [], legend: [], notes: [] };
    const X = (i) => ((i - start + 0.5) / n * 100).toFixed(2);
    const segs = (arr, yf) => { const s = []; let cur = []; for (let j = 0; j < n; j++) { const v = arr[start + j]; if (Number.isFinite(v)) cur.push(X(start + j) + ',' + yf(v).toFixed(2)); else if (cur.length) { s.push(cur.join(' ')); cur = []; } } if (cur.length) s.push(cur.join(' ')); return s.filter((x) => x.indexOf(' ') > 0); };
    const R = compute(cs, st, o);
    const fmtK = (v) => (Math.abs(v) >= 1e9 ? (v / 1e9).toFixed(2) + 'B' : Math.abs(v) >= 1e6 ? (v / 1e6).toFixed(2) + 'M' : Math.abs(v) >= 1e3 ? (v / 1e3).toFixed(1) + 'K' : v.toFixed(0));
    if (master) R.res.forEach(({ x, out: r }) => {
      if (r.note) out.notes.push(x.name + ': ' + r.note);
      (r.fills || []).forEach((f) => { const a = [], b = []; for (let j = 0; j < n; j++) { const u = f.up[start + j], w = f.lo[start + j]; if (Number.isFinite(u) && Number.isFinite(w)) { a.push(X(start + j) + ',' + Y(u).toFixed(2)); b.push(X(start + j) + ',' + Y(w).toFixed(2)); } } if (a.length > 1) out.gFills.push({ pts: a.concat(b.reverse()).join(' '), color: f.color }); });
      (r.lines || []).forEach((L) => segs(L.arr, Y).forEach((p) => out.gLines.push({ pts: p, color: L.color, w: String(L.w || 1.4), dash: L.dash || '' })));
      (r.dots || []).forEach((D) => { for (let j = 0; j < n; j++) { const v = D.arr[start + j]; if (Number.isFinite(v)) out.gDots.push({ x: X(start + j), y: Y(v).toFixed(2), color: (D.colors && D.colors[start + j]) || x.color }); } });
      (r.levels || []).forEach((L) => { const top = Y(L.v); if (top < -2 || top > 102) return; out.gLevels.push({ top: top.toFixed(2), color: L.color, label: L.label + ' ' + f2(L.v), dash: L.dash ? 'dashed' : 'solid' }); });
      (r.legend || []).forEach((g) => { const L = r.lines || []; const v = (k) => (L[k] ? L[k].arr[habs] : NaN); let val = ''; if (g.dot !== undefined) val = f2((r.dots[0].arr[habs]) || 0); else if (g.j !== undefined) val = Number.isFinite(v(g.i)) ? f2(v(g.i)) + ' / ' + f2(v(g.j)) : '—'; else { const a = v(g.i), b = g.alt !== undefined ? v(g.alt) : NaN; val = Number.isFinite(a) ? f2(a) : Number.isFinite(b) ? f2(b) : '—'; } out.legend.push({ label: g.label, color: Number.isFinite(v(g.i)) || g.alt === undefined ? g.color : g.altColor, value: val }); });
      if (r.candles) out.lrc = r.candles;
      if (r.pane) {
        const P = r.pane; const vals = [];
        for (let j = 0; j < n; j++) { (P.lines || []).forEach((L) => { const v = L.arr[start + j]; if (Number.isFinite(v)) vals.push(v); }); if (P.hist) { const v = P.hist.arr[start + j]; if (Number.isFinite(v)) vals.push(v); } }
        (P.levels || []).forEach((v) => vals.push(v));
        let lo = P.min !== undefined ? P.min : Math.min(...vals), hi = P.max !== undefined ? P.max : Math.max(...vals);
        if (!Number.isFinite(lo) || !Number.isFinite(hi)) { lo = 0; hi = 1; } if (hi - lo < 1e-9) { hi += 1; lo -= 1; }
        if (P.min === undefined || P.max === undefined) { const pd = (hi - lo) * 0.08; if (P.min === undefined) lo -= pd; if (P.max === undefined) hi += pd; }
        const py = (v) => (hi - v) / (hi - lo) * 100;
        const fmt = (v) => (!Number.isFinite(v) ? '—' : P.fmt === 'k' ? fmtK(v) : P.fmt === 'x' ? v.toFixed(2) + 'x' : Math.abs(v) >= 100 ? v.toFixed(1) : v.toFixed(2));
        const lines = []; (P.lines || []).forEach((L) => segs(L.arr, py).forEach((p) => lines.push({ pts: p, color: L.color })));
        const bars = [];
        if (P.hist) { const z = py(Math.max(lo, Math.min(hi, 0))); for (let j = 0; j < n; j++) { const v = P.hist.arr[start + j]; if (!Number.isFinite(v)) continue; const t = py(v); const col = P.hist.hot && v >= P.hist.hot ? P.hist.hotColor : v >= 0 ? P.hist.up : P.hist.dn; bars.push({ x: ((j + 0.2) / n * 100).toFixed(3), w: (0.6 / n * 100).toFixed(3), top: Math.min(t, z).toFixed(2), h: Math.max(0.6, Math.abs(z - t)).toFixed(2), color: col }); } }
        if (P.zeroDots) { const z = py(0); for (let j = 0; j < n; j++) bars.push({ x: ((j + 0.35) / n * 100).toFixed(3), w: (0.3 / n * 100).toFixed(3), top: (z - 1.5).toFixed(2), h: '3', color: P.zeroDots[start + j] ? '#F2555A' : 'rgba(52,211,153,.6)' }); }
        const levels = (P.levels || []).map((v) => ({ top: py(v).toFixed(2), label: String(v) }));
        const band = P.fill ? { top: py(P.fill[1]).toFixed(2), h: (py(P.fill[0]) - py(P.fill[1])).toFixed(2), on: true } : { top: '0', h: '0', on: false };
        const cur = (P.lines || []).map((L) => '<b style="color:' + L.color + '">' + fmt(L.arr[habs]) + '</b>').join(' ') + (P.hist ? ' <b style="color:#8796A3">' + fmt(P.hist.arr[habs]) + '</b>' : '');
        out.panes.push({ id: x.id, name: P.name, cur: (P.lines || []).map((L) => fmt(L.arr[habs])).concat(P.hist ? [fmt(P.hist.arr[habs])] : []).join('  '), curHtml: cur, lines, bars, levels, band, hiLabel: fmt(hi), loLabel: fmt(lo), close: () => app.setState({ ind: Object.assign({}, defOf(st), st.ind || {}, { [x.id]: false }) }) });
      }
    });
    if (out.panes.length > 4) { out.notes.push('Showing 4 lower panels at a time (' + out.panes.slice(4).map((x) => x.name).join(', ') + ' hidden)'); out.panes = out.panes.slice(0, 4); }
    // volume profile of what's on screen
    if (master && isOn(st, 'vprof')) {
      const rows = Math.max(8, Math.min(60, paramsOf(st, BYID.vprof).rows | 0));
      let lo = Infinity, hi2 = -Infinity; for (let j = 0; j < n; j++) { const b = cs[start + j]; if (!b) continue; lo = Math.min(lo, b.l); hi2 = Math.max(hi2, b.h); }
      const bins = new Array(rows).fill(0), step = (hi2 - lo) / rows || 1;
      for (let j = 0; j < n; j++) { const b = cs[start + j]; if (!b) continue; const a = Math.max(0, Math.floor((b.l - lo) / step)), z = Math.min(rows - 1, Math.floor((b.h - lo) / step)); const per = (b.v || 0) / (z - a + 1); for (let k = a; k <= z; k++) bins[k] += per; }
      const mx = Math.max(...bins) || 1; const poc = bins.indexOf(Math.max(...bins));
      // value area: 70% of volume around the point of control
      const tot = bins.reduce((x, y) => x + y, 0); let va = bins[poc], a = poc, z = poc; while (va < tot * 0.7 && (a > 0 || z < rows - 1)) { const dn = a > 0 ? bins[a - 1] : -1, up = z < rows - 1 ? bins[z + 1] : -1; if (up >= dn) { z++; va += up; } else { a--; va += dn; } }
      bins.forEach((v, k) => { const top = Y(lo + (k + 1) * step), bot = Y(lo + k * step); out.gProf.push({ top: top.toFixed(2), h: Math.max(0.3, bot - top - 0.15).toFixed(2), w: (v / mx * 22).toFixed(2), color: k === poc ? 'rgba(240,160,75,.55)' : k >= a && k <= z ? 'rgba(78,126,190,.38)' : 'rgba(78,126,190,.18)' }); });
      out.legend.push({ label: 'POC', color: '#F0A04B', value: f2(lo + (poc + 0.5) * step) });
    }
    // menu
    const q = String(st.indQ || '').trim().toLowerCase();
    const groups = [];
    CAT.forEach((x) => {
      if (q && (x.name + ' ' + x.group).toLowerCase().indexOf(q) < 0) return;
      let g = groups.find((y) => y.title === x.group); if (!g) { g = { title: x.group, items: [] }; groups.push(g); }
      const p = paramsOf(st, x); const on = isOn(st, x.id);
      g.items.push({
        id: x.id, label: x.name, color: x.color, on, opacity: master ? '1' : '0.45',
        toggle: () => app.setState({ ind: Object.assign({}, defOf(st), st.ind || {}, { [x.id]: !on }) }),
        ps: Object.keys(x.params).map((k) => ({ k, v: String(p[k]), title: { len: 'Length', mult: 'Multiplier', min: 'Minutes', rows: 'Rows', step: 'Step', max: 'Max', fast: 'Fast', slow: 'Slow', sig: 'Signal', k: '%K', smooth: 'Smooth', d: '%D', conv: 'Conversion', base: 'Base', span: 'Span' }[k] || k, set: (e) => { const val = parseFloat(e.target.value); if (!Number.isFinite(val) || val <= 0) return; app.setState({ indP: Object.assign({}, st.indP || {}, { [x.id]: Object.assign({}, (st.indP || {})[x.id] || {}, { [k]: val }) }) }); } })),
        hasPick: !!x.anchor, pickTxt: st.indPick === 'avwap' ? 'Click a candle…' : (st.indA && st.indA[st.chartSym] != null ? 'Move' : 'Pick'),
        pick: () => app.setState({ indPick: st.indPick === 'avwap' ? null : 'avwap', ind: Object.assign({}, defOf(st), st.ind || {}, { avwap: true }) })
      });
    });
    const active = CAT.filter((x) => isOn(st, x.id)).length;
    return Object.assign(out, { groups, hasGroups: groups.length > 0, q: st.indQ || '', onQ: (e) => app.setState({ indQ: e.target.value }), countLabel: master ? active + ' on' : 'hidden', notesTxt: out.notes.join(' · '), hasNotes: out.notes.length > 0, picking: st.indPick === 'avwap', resetAll: () => app.setState({ ind: Object.assign({}, defOf(st)), indP: {}, indA: {}, indQ: '' }) });
  }

  // vector candles: PVSRA-style colors from volume vs its recent average
  function vector(cs, st) {
    if (st.indOn === false || !isOn(st, 'vector')) return null;
    const n = Math.max(3, paramsOf(st, BYID.vector).len | 0);
    const v = cs.map((b) => b.v || 0); const avg = sma(v, n);
    return (i, up) => { const a = avg[i - 1] || avg[i]; if (!a) return null; const r = v[i] / a; if (r >= 2) return up ? '#00E676' : '#FF1744'; if (r >= 1.5) return up ? '#2979FF' : '#D500F9'; return up ? 'rgba(160,170,180,.75)' : 'rgba(95,105,115,.9)'; };
  }

  // linear regression candles: the candle body itself is redrawn from rolling regressions of open/high/low/close
  const lrcCache = new WeakMap();
  function lrc(cs, st) {
    if (st.indOn === false || !isOn(st, 'lrc') || !cs.length) return null;
    const p = paramsOf(st, BYID.lrc); const k = (p.len | 0) + ':' + (p.sig | 0);
    const hit = lrcCache.get(cs); if (hit && hit.k === k) return hit.v;
    const d = { N: cs.length, o: cs.map((b) => b.o), h: cs.map((b) => b.h), l: cs.map((b) => b.l), c: cs.map((b) => b.c) };
    const v = BYID.lrc.calc(d, p).candles; lrcCache.set(cs, { k, v }); return v;
  }
  window.XRInd = { CAT, build, vector, isOn, defOf, lrc };
})();
