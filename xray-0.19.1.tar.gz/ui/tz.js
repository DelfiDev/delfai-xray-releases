// Time helpers: everything the user reads is in THEIR time zone (LA sees 6:30 AM, New York sees 9:30 AM).
// Market rules (open, close, which session) still run on New York time behind the scenes.
(function () {
  'use strict';
  const pad = (n) => String(n).padStart(2, '0');
  const zone = (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) { return ''; } })();
  // short zone name: PT, ET, CT, MT for the US, otherwise what the system gives (GMT+1, CET…)
  const abbr = (() => {
    const us = { 'America/Los_Angeles': 'PT', 'America/New_York': 'ET', 'America/Chicago': 'CT', 'America/Denver': 'MT', 'America/Phoenix': 'MT', 'America/Anchorage': 'AKT', 'Pacific/Honolulu': 'HT', 'America/Detroit': 'ET', 'America/Indiana/Indianapolis': 'ET' };
    if (us[zone]) return us[zone];
    try { const p = new Intl.DateTimeFormat('en-US', { timeZoneName: 'short' }).formatToParts(new Date()).find((x) => x.type === 'timeZoneName'); return p ? p.value : ''; } catch (e) { return ''; }
  })();
  // minutes New York is ahead of UTC at a given moment (handles daylight saving)
  const nyOffset = (ms) => {
    const o = {}; new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', hourCycle: 'h23' }).formatToParts(new Date(ms)).forEach((p) => { o[p.type] = p.value; });
    return Math.round((Date.UTC(+o.year, +o.month - 1, +o.day, +o.hour % 24, +o.minute) - ms) / 60000);
  };
  // the real moment of HH:MM New York time on the New York date of `ms`
  const nyAt = (ms, h, m) => {
    const o = {}; new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', year: 'numeric', month: 'numeric', day: 'numeric' }).formatToParts(new Date(ms)).forEach((p) => { o[p.type] = p.value; });
    const guess = Date.UTC(+o.year, +o.month - 1, +o.day, h, m);
    return guess - nyOffset(guess) * 60000;
  };
  const clock = (ms) => new Intl.DateTimeFormat('en-US', { hour: 'numeric', minute: '2-digit' }).format(new Date(ms));
  const MO = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  window.XRTZ = {
    zone, abbr, nyAt, clock,
    // today's date where the user is, as 2026-10-29
    today: () => { const d = new Date(); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); },
    // when the next 9:30 ET open happens, said in the user's time: "6:30 AM" today or "Mon 6:30 AM"
    nextOpen: () => {
      let t = Date.now();
      for (let i = 0; i < 8; i++) {
        const open = nyAt(t, 9, 30);
        const wd = new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', weekday: 'short' }).format(new Date(open));
        if (open > Date.now() && wd !== 'Sat' && wd !== 'Sun') {
          const sameDay = new Date(open).toDateString() === new Date().toDateString();
          return (sameDay ? '' : new Intl.DateTimeFormat('en-US', { weekday: 'short' }).format(new Date(open)) + ' ') + clock(open);
        }
        t += 86400000;
      }
      return clock(nyAt(Date.now(), 9, 30));
    },
    // chart time label in the user's time
    label: (ms, withDate) => { const d = new Date(ms); return (withDate ? MO[d.getMonth()] + ' ' + d.getDate() + ' ' : '') + pad(d.getHours()) + ':' + pad(d.getMinutes()); },
    stamp: () => new Intl.DateTimeFormat('en-US', { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(new Date()) + (abbr ? ' ' + abbr : '')
  };
})();
