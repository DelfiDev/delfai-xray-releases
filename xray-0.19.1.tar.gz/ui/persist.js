// Keeps your X-ray setup (watchlists, options list, alerts, journal, drawings, notes, layout) between launches.
(function () {
  'use strict';
  const KEY = 'xray-state-v1';
  // a popped-out chart window starts from the main window's exact state and never writes back over it
  const POP = /[#&]pop=/.test(location.hash); window.__xrPop = POP;
  const SKIP = new Set(['gpDate', 'jf', 'jFormOpen', 'jMsg', 'hi', 'dragging', 'gsOpen', 'gsSel', 'gsJump', 'q', 'chartMsg', 'optHi', 'ecoHov', 'ecoOpen', 'newsOpen', 'dSel', 'gxPlay', 'gxT', 'yScale', 'optY', 'optWin', 'start', 'indOpen', 'oindOpen', 'oindPick', 'chColsOpen', 'supSent', 'supErr', 'wlMsg', 'alMsg', 'optMsg']);
  const load = () => { try { const s = JSON.parse(localStorage.getItem(KEY) || 'null'); return s && typeof s === 'object' ? s : null; } catch (e) { return null; } };
  let timer = null, target = null;
  const save = () => {
    timer = null;
    if (!target || POP) return;
    const out = {};
    Object.keys(target.state || {}).forEach((k) => {
      if (SKIP.has(k)) return;
      const v = target.state[k];
      if (typeof v === 'function') return;
      out[k] = v;
    });
    try { localStorage.setItem(KEY, JSON.stringify(out)); } catch (e) { /* storage full or blocked */ }
  };
  const orig = window.DCLogic.prototype.setState;
  window.DCLogic.prototype.setState = function (p) {
    orig.call(this, p);
    if (this.__persist) { target = this; if (!timer) timer = setTimeout(save, 800); }
  };
  const Base = window.__C.Main;
  window.__C.Main = class extends Base {
    constructor(props) {
      super(props);
      const saved = load();
      if (saved) {
        // one-time cleanup: drop the example journal trades and game plans that older versions saved
        try {
          if (!localStorage.getItem('xr-mig-0107')) {
            if (Array.isArray(saved.jTrades)) saved.jTrades = saved.jTrades.filter((t) => !(t && /^j\d{1,2}$/.test(String(t.id)) && String(t.date) <= '2026-10-09'));
            const SAMPLE_PLAN = /^(SPX holding the 3-day box|Choppy open expected|SPY and SPX both basing|Big multi-day base on SPX premium|QQQ weak into the open|SPX swept the box floor premarket)/;
            if (saved.jPlans && typeof saved.jPlans === 'object') Object.keys(saved.jPlans).forEach((k) => { const p = saved.jPlans[k]; if (p && SAMPLE_PLAN.test(String(p.read || ''))) delete saved.jPlans[k]; });
            delete saved.gpDate; delete saved.jf;
            localStorage.setItem('xr-mig-0107', '1');
          }
        } catch (e) { /* fine */ }
        delete saved.jMsg; delete saved.gpDate; delete saved.jf;
        if (!POP) saved.page = 'dash'; // X-ray always opens on the Dashboard // one-off notes and the day being edited always start fresh
        this.state = Object.assign({}, this.state, saved);
      }
      if (POP) { try { const h = JSON.parse(localStorage.getItem('xr-pop-handoff') || 'null'); if (h) this.state = Object.assign({}, this.state, h); } catch (e) { /* fine */ } }
      this.__persist = true;
    }
  };
  window.__xrStateSnapshot = () => { const out = {}; Object.keys((target && target.state) || (window.__app && window.__app.c && window.__app.c.state) || {}).forEach((k) => { const st = (target && target.state) || window.__app.c.state; const v = st[k]; if (typeof v !== 'function' && !SKIP.has(k)) out[k] = v; }); return out; };
  window.addEventListener('beforeunload', () => { if (timer) { clearTimeout(timer); save(); } });
})();
