// The box on the premium chart, watchlist and checklist.
// No box rules live in the app: we send a contract's daily candles to the local server,
// it asks VENOM OS (which checks X-ray access), and we draw whatever comes back.
(function () {
  'use strict';
  const XR = window.XR || (window.XR = {});
  const cache = new Map();          // contract -> { at, res, busy }
  const queue = [];
  let running = 0;
  const MAX_RUNNING = 2, MAX_QUEUE = 40, TTL = 60000;

  let repaintT = null;
  const repaint = () => {
    if (repaintT) return;
    repaintT = setTimeout(() => { repaintT = null; try { if (window.__app && window.__app.c) window.__app.c.forceUpdate(); } catch (e) { console.error(e); } }, 150);
  };
  const run = () => {
    while (running < MAX_RUNNING && queue.length) {
      const job = queue.shift();
      running++;
      job().finally(() => { running--; run(); });
    }
  };

  // 5m candles -> daily candles, remembering where each day starts so the chart knows where to begin the box
  const daily = (bars) => {
    const out = [], first = new Map();
    const lab = (i) => (bars[i].day || ('S' + String(Math.floor((i + (78 - bars.length % 78) % 78) / 78)).padStart(3, '0')));
    for (let i = 0; i < bars.length; i++) {
      const b = bars[i];
      if (!b || b.pad) continue;
      const k = lab(i);
      const last = out[out.length - 1];
      if (!last || last.day !== k) { out.push({ t: b.t || null, day: k, o: b.o, h: b.h, l: b.l, c: b.c, v: b.v || 0 }); first.set(k, i); }
      else { last.h = Math.max(last.h, b.h); last.l = Math.min(last.l, b.l); last.c = b.c; last.v += b.v || 0; }
    }
    return { days: out, first };
  };

  // older screens use these state names; the new ones ride along as v2State
  const LEGACY = { 'Expanding': 'Breakout', 'Above box': 'Breakout', 'Sweep': 'Sweep + reclaim', 'In box': 'Inside base', 'Dead': 'Below base', 'Breaking down': 'Below base' };

  XR.box = { locked: null };

  XR.boxFor = (bars, pc) => {
    if (!pc || !bars || bars.loading || bars.length < 2) return null;
    const live = !!(bars.live && pc.occ && XR.live);
    const key = live ? pc.occ : 'sample:' + pc.key;
    let e = cache.get(key);
    if ((!e || Date.now() - e.at > TTL) && !(e && e.busy) && queue.length < MAX_QUEUE) {
      e = e || { at: 0, res: null };
      e.busy = true; e.at = Date.now(); cache.set(key, e);
      const req = live
        ? fetch('/api/box?occ=' + encodeURIComponent(pc.occ), { cache: 'no-store' })
        : fetch('/api/box', { method: 'POST', cache: 'no-store', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key: pc.key, days: daily(bars).days }) });
      queue.push(() => req.then((r) => r.json()).then((j) => {
        if (j && j.error === 'slow') { e.at = Date.now() + 60000; return; }   // back off a minute
        if (j && (j.box !== undefined || j.locked)) {
          e.res = j;
          const was = XR.box.locked;
          XR.box.locked = j.locked || null;
          if (was !== XR.box.locked) window.dispatchEvent(new CustomEvent('xr-box-access', { detail: XR.box.locked }));
          repaint();
        }
      }).catch(() => {}).finally(() => { e.busy = false; }));
      run();
    }
    const b = e && e.res && e.res.box;
    if (!b) return null;
    // where the box starts on this chart: the first 5m candle of the anchor day (0 when it's older than the chart)
    const d = daily(bars);
    const startBar = b.anchorDay && d.first.has(b.anchorDay) ? d.first.get(b.anchorDay) : 0;
    return {
      lo: b.lo, hi: b.hi, days: b.days, startBar, anchorDay: b.anchorDay || null, state: LEGACY[b.state] || b.state, v2State: b.state,
      grade: b.grade, tags: b.tags || [], sweepLow: b.sweepLow, targets: b.targets || [], intraday: !!b.intraday, kind: b.kind,
    };
  };

  // the contract's full daily history for the 1D premium chart (you trade off the daily)
  const dcache = new Map();
  XR.dailyFor = (occ) => {
    if (!occ || !XR.live) return null;
    let e = dcache.get(occ);
    if ((!e || Date.now() - e.at > TTL) && !(e && e.busy)) {
      e = e || { at: 0, arr: null }; e.busy = true; e.at = Date.now(); dcache.set(occ, e);
      fetch('/api/option-daily?occ=' + encodeURIComponent(occ), { cache: 'no-store' }).then((r) => r.json()).then((j) => {
        if (j && Array.isArray(j.days) && j.days.length >= 2) {
          const arr = j.days.map((d) => ({ t: d.t, day: d.day, o: d.o, h: d.h, l: d.l, c: d.c, v: d.v || 0 }));
          arr.live = true; arr.daily = true; e.arr = arr; repaint();
        }
      }).catch(() => {}).finally(() => { e.busy = false; });
    }
    return e && e.arr;
  };
})();
