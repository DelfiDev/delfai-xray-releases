// Hologram globe: the real Earth (NASA Blue Marble + city lights) with a hologram finish.
// Mounts itself into any #xr-globe[data-keep="holo"] element; the Globe component feeds it through window.__holo.
(function () {
  'use strict';
  const D2R = Math.PI / 180;
  const posOf = (lat, lon, r) => { const a = lat * D2R, b = lon * D2R; return new THREE.Vector3(r * Math.cos(a) * Math.cos(b), r * Math.sin(a), -r * Math.cos(a) * Math.sin(b)); };
  const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // One globe for the whole session: built once (warmed up in the background right after launch), then moved
  // into whichever page shows it, so opening Catalysts & News doesn't rebuild WebGL or reload the Earth images.
  let inst = null, warmHost = null;
  function mount(el) {
    if (!window.THREE) return;
    if (inst) { inst.attach(el); return; }
    inst = build(el);
  }
  function build(el) {
    const wrap = document.createElement('div'); wrap.className = 'xr-holo-wrap';
    el.innerHTML = '';
    el.classList.add('xr-holo'); el.appendChild(wrap);
    // projector base, light cone and orbit rings sit behind the canvas
    wrap.insertAdjacentHTML('beforeend', '<svg class="xr-holo-under" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="xrhc" x1="0" x2="0" y1="1" y2="0"><stop offset="0" stop-color="rgba(143,210,236,.42)"/><stop offset=".6" stop-color="rgba(143,210,236,.05)"/><stop offset="1" stop-color="rgba(143,210,236,0)"/></linearGradient></defs><polygon points="40,95 60,95 82,48 18,48" fill="url(#xrhc)"/></svg>' +
      '<div class="xr-holo-base"><i></i><b></b><u></u></div><div class="xr-holo-orbit"></div><div class="xr-holo-orbit two"></div>');
    const canvas = document.createElement('canvas'); canvas.className = 'xr-holo-gl'; wrap.appendChild(canvas);
    const labels = document.createElement('div'); labels.className = 'xr-holo-labels'; wrap.appendChild(labels);


    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(30, 1, 0.1, 100);
    const tilt = new THREE.Group(); scene.add(tilt);
    const earthG = new THREE.Group(); tilt.add(earthG);
    const loader = new THREE.TextureLoader();
    const day = loader.load('vendor/earth-day.jpg'), night = loader.load('vendor/earth-night.jpg');
    const uniforms = { day: { value: day }, night: { value: night }, sun: { value: new THREE.Vector3(1, 0, 0) }, time: { value: 0 } };
    const earth = new THREE.Mesh(new THREE.SphereGeometry(1, 96, 96), new THREE.ShaderMaterial({
      uniforms, transparent: true,
      vertexShader: 'varying vec2 vUv; varying vec3 vN; varying vec3 vObjN; varying vec3 vV; void main(){ vUv = uv; vObjN = normalize(position); vec4 mv = modelViewMatrix * vec4(position, 1.0); vN = normalize(normalMatrix * normal); vV = normalize(-mv.xyz); gl_Position = projectionMatrix * mv; }',
      fragmentShader: [
        'uniform sampler2D day; uniform sampler2D night; uniform vec3 sun; uniform float time; varying vec2 vUv; varying vec3 vN; varying vec3 vObjN; varying vec3 vV;',
        'void main(){',
        '  vec3 d = texture2D(day, vUv).rgb; vec3 n = texture2D(night, vUv).rgb;',
        '  float lit = smoothstep(-0.12, 0.25, dot(normalize(vObjN), normalize(sun)));',
        '  vec3 dayC = d * (0.35 + 0.75 * lit);',
        '  vec3 nightC = n * vec3(1.0, 0.85, 0.6) * 1.4 * (1.0 - lit) + d * 0.10;',
        '  vec3 c = mix(nightC, dayC, lit);',
        '  float l = dot(c, vec3(0.3, 0.59, 0.11));',
        '  vec3 holo = mix(c, vec3(0.35, 0.85, 1.0) * l * 1.7, 0.36);',
        '  float fr = pow(1.0 - max(dot(vN, vV), 0.0), 2.4);',
        '  float scan = 0.88 + 0.12 * sin(gl_FragCoord.y * 1.5 - time * 2.0);',
        '  gl_FragColor = vec4(holo * scan + vec3(0.45, 0.85, 1.0) * fr * 1.25, 0.94);',
        '}'].join('\n')
    }));
    earthG.add(earth);
    const atmo = new THREE.Mesh(new THREE.SphereGeometry(1.09, 64, 64), new THREE.ShaderMaterial({
      side: THREE.BackSide, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false,
      vertexShader: 'varying vec3 vN; void main(){ vN = normalize(normalMatrix * normal); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
      fragmentShader: 'varying vec3 vN; void main(){ float i = pow(0.72 - dot(vN, vec3(0.0, 0.0, 1.0)), 3.0); gl_FragColor = vec4(0.45, 0.85, 1.0, 1.0) * i * 1.4; }'
    }));
    tilt.add(atmo);
    // faint latitude / longitude grid
    const gridMat = new THREE.LineBasicMaterial({ color: 0x8fd2ec, transparent: true, opacity: 0.18 });
    for (let la = -60; la <= 60; la += 30) { const p = []; for (let lo = -180; lo <= 180; lo += 4) p.push(posOf(la, lo, 1.003)); earthG.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(p), gridMat)); }
    for (let lo = -180; lo < 180; lo += 30) { const p = []; for (let la = -88; la <= 88; la += 4) p.push(posOf(la, lo, 1.003)); earthG.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(p), gridMat)); }

    // event beams
    const beams = new THREE.Group(); earthG.add(beams);
    let beamKey = '', pickables = [];
    const buildBeams = (H) => {
      const key = (H.events || []).map((e) => e.id + e.color + (e.id === H.sel ? '*' : '')).join('|');
      if (key === beamKey) return; beamKey = key;
      while (beams.children.length) { const c = beams.children.pop(); c.geometry && c.geometry.dispose(); }
      pickables = [];
      (H.events || []).forEach((e) => {
        const h = 0.08 + e.imp * 0.07 + (e.id === H.sel ? 0.08 : 0);
        const a = posOf(e.lat, e.lon, 1.0), b = posOf(e.lat, e.lon, 1.0 + h);
        const col = new THREE.Color(e.color);
        beams.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints([a, b]), new THREE.LineBasicMaterial({ color: col, transparent: true, opacity: 0.95 })));
        const cyl = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.004, h, 8, 1, true), new THREE.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.32, blending: THREE.AdditiveBlending, depthWrite: false }));
        cyl.position.copy(a.clone().add(b).multiplyScalar(0.5)); cyl.lookAt(0, 0, 0); cyl.rotateX(Math.PI / 2); beams.add(cyl);
        const dot = new THREE.Mesh(new THREE.SphereGeometry(e.id === H.sel ? 0.024 : 0.016, 12, 12), new THREE.MeshBasicMaterial({ color: col }));
        dot.position.copy(a); dot.userData = { id: e.id, top: b, ev: e }; beams.add(dot); pickables.push(dot);
      });
    };

    // interaction: drag to spin, click a beam, wheel zoom comes from the Globe component (k)
    let rotY = -(90 + 10) * D2R, rotX = 22 * D2R, vY = 0, dragging = false, last = null, pausedUntil = 0, moved = 0, target = null, lastSel = null;
    const ray = new THREE.Raycaster(), mouse = new THREE.Vector2();
    const hit = (ev) => {
      const r = canvas.getBoundingClientRect(); mouse.set(((ev.clientX - r.left) / r.width) * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1);
      ray.setFromCamera(mouse, camera);
      let best = null, bd = 0.05;
      pickables.forEach((d) => { const w = d.getWorldPosition(new THREE.Vector3()); if (w.clone().normalize().dot(camera.position.clone().normalize()) < 0.1) return; const dist = ray.ray.distanceToPoint(w); if (dist < bd) { bd = dist; best = d; } });
      return best;
    };
    canvas.addEventListener('mousedown', (ev) => { if (ev.button !== 0) return; dragging = true; moved = 0; last = { x: ev.clientX, y: ev.clientY }; target = null; ev.preventDefault(); });
    window.addEventListener('mousemove', (ev) => {
      if (dragging) { const dx = ev.clientX - last.x, dy = ev.clientY - last.y; moved += Math.abs(dx) + Math.abs(dy); rotY += dx * 0.006; rotX = Math.max(-1.2, Math.min(1.2, rotX + dy * 0.006)); vY = dx * 0.006; last = { x: ev.clientX, y: ev.clientY }; pausedUntil = Date.now() + 6000; return; }
      if (ev.target === canvas) canvas.style.cursor = hit(ev) ? 'pointer' : 'grab';
    });
    window.addEventListener('mouseup', (ev) => {
      if (!dragging) return; dragging = false;
      if (moved < 5) { const d = hit(ev); const H = window.__holo; if (d && H && H.pick) H.pick(d.userData.id); }
    });

    const flyTo = (lat, lon) => { target = { y: -(90 + lon) * D2R, x: Math.max(-1.1, Math.min(1.1, lat * D2R)) }; pausedUntil = Date.now() + 9000; };
    const size = () => { const w = el.clientWidth || 600, h = el.clientHeight || w; renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); };
    const ro = new ResizeObserver(size); ro.observe(el); size();

    const labelEls = new Map();
    const t0 = performance.now();
    const frame = () => {
      if (!el.isConnected || (el === warmHost && performance.now() - t0 > 2500)) { setTimeout(() => requestAnimationFrame(frame), 250); return; } // parked: keep everything loaded, draw nothing
      const H = window.__holo || {};
      const t = (performance.now() - t0) / 1000;
      uniforms.time.value = t;
      // sun position from the real clock
      const now = new Date(); const utcH = now.getUTCHours() + now.getUTCMinutes() / 60;
      const doy = Math.floor((now - new Date(Date.UTC(now.getUTCFullYear(), 0, 0))) / 86400000);
      const decl = -23.44 * Math.cos(2 * Math.PI / 365 * (doy + 10));
      uniforms.sun.value.copy(posOf(decl, (12 - utcH) * 15, 1));
      buildBeams(H);
      if (H.sel && H.sel !== lastSel) { const e = (H.events || []).find((x) => x.id === H.sel); if (e) flyTo(e.lat, e.lon); }
      if (H.hubFly && H.hubFly !== lastSel) { const hb = (H.hubs || []).find((x) => x.code === H.hubFly); if (hb) flyTo(hb.lat, hb.lon); }
      lastSel = H.sel || H.hubFly || null;
      if (H.resetN !== undefined && H.resetN !== resetN) { resetN = H.resetN; target = { y: -(90 + 10) * D2R, x: 22 * D2R }; }
      if (target) {
        let dy = target.y - rotY; dy = ((dy + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI;
        rotY += dy * 0.08; rotX += (target.x - rotX) * 0.08;
        if (Math.abs(dy) < 0.002 && Math.abs(target.x - rotX) < 0.002) target = null;
      } else if (!dragging) {
        if (Math.abs(vY) > 0.0001) { rotY += vY; vY *= 0.94; }
        if (H.auto !== false && Date.now() > pausedUntil && !reduce) rotY += 0.0018;
      }
      earthG.rotation.y = rotY; tilt.rotation.x = rotX;
      camera.position.set(0, 0, 4.4 / Math.max(0.85, Math.min(2.8, H.k || 1))); camera.lookAt(0, 0, 0);
      // breaking / selected beams pulse
      beams.children.forEach((c) => { if (c.userData && c.userData.ev && (c.userData.ev.breaking || c.userData.id === H.sel)) c.scale.setScalar(1 + 0.35 * Math.abs(Math.sin(t * 3))); });
      renderer.render(scene, camera);
      // labels: the most important stories facing us, plus the selected one and market codes
      const W = el.clientWidth, Hh = el.clientHeight;
      const show = new Set();
      const facing = (v) => v.clone().normalize().dot(camera.position.clone().normalize()) > 0.18;
      const put = (key, world, html, cls, onClick) => {
        const p = world.clone().project(camera); const x = (p.x + 1) / 2 * W, y = (1 - p.y) / 2 * Hh;
        let s = labelEls.get(key);
        if (!s) { s = document.createElement(onClick ? 'button' : 'span'); s.className = cls; if (onClick) { s.type = 'button'; s.addEventListener('click', onClick); } labels.appendChild(s); labelEls.set(key, s); }
        if (s._html !== html) { s.innerHTML = html; s._html = html; }
        s.style.transform = 'translate(' + x.toFixed(1) + 'px,' + y.toFixed(1) + 'px)'; show.add(key);
      };
      const ranked = pickables.map((d) => d.userData).sort((a, b) => (b.id === H.sel) - (a.id === H.sel) || b.ev.imp - a.ev.imp).slice(0, 9);
      const seenWhere = new Set();
      ranked.forEach((u) => { if (seenWhere.has(u.ev.where)) return; seenWhere.add(u.ev.where); const w = u.top.clone().applyMatrix4(earthG.matrixWorld); if (!facing(w)) return; put('e' + u.id, w, '<span style="color:' + u.ev.color + ';text-shadow:0 0 6px ' + u.ev.color + '">' + (u.ev.where || '').toUpperCase().slice(0, 26) + '</span>', 'xr-holo-lab'); });
      (H.hubs || []).forEach((hb) => { const w = posOf(hb.lat, hb.lon, 1.01).applyMatrix4(earthG.matrixWorld); if (!facing(w)) return; put('h' + hb.code, w, '<i style="background:' + (hb.open ? '#34D399' : '#5B6B7A') + ';box-shadow:' + (hb.open ? '0 0 8px #34D399' : 'none') + '"></i>' + hb.code, 'xr-holo-hub' + (hb.open ? ' open' : ''), () => { const G = window.__holo; if (G && G.pickHub) G.pickHub(hb.code); }); });
      labelEls.forEach((s, k) => { s.style.display = show.has(k) ? '' : 'none'; });
      requestAnimationFrame(frame);
    };
    let resetN;
    requestAnimationFrame(frame);
    return {
      attach(next) {
        if (next === el) return;
        const old = el; ro.disconnect();
        el = next; next.innerHTML = ''; next.classList.add('xr-holo'); next.appendChild(wrap);
        ro.observe(el); size();
        if (old === warmHost) { old.remove(); warmHost = null; }
      }
    };
  }
  // warm it up off screen shortly after launch, so the first visit to the globe is instant
  setTimeout(() => {
    if (inst || !window.THREE) return;
    warmHost = document.createElement('div');
    warmHost.setAttribute('aria-hidden', 'true');
    warmHost.style.cssText = 'position:fixed;left:-10000px;top:0;width:640px;height:640px;pointer-events:none;';
    document.body.appendChild(warmHost);
    try { inst = build(warmHost); } catch (e) { console.error('holo warm', e); }
  }, 2500);

  // watch for the globe container (pages and widgets come and go)
  const scan = () => document.querySelectorAll('[data-keep="holo"]').forEach((el) => { if (!el._holo) { el._holo = true; try { mount(el); } catch (e) { console.error('holo', e); } } });
  setInterval(scan, 1000);
  // attach the moment the page puts the globe container in, not on the next timer tick
  new MutationObserver(() => { const el = document.querySelector('[data-keep="holo"]'); if (el && !el._holo) scan(); }).observe(document.documentElement, { childList: true, subtree: true });
})();
