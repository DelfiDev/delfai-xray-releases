// Alert engine: checks your alerts against live prices every few seconds.
// An alert fires once when price CROSSES its level (not just because it already sits past it),
// then it's marked hit and paused. Hits go to the sidebar card, a sound, and a desktop pop-up.
(function () {
  'use strict';
  if (/[#&]pop=/.test(location.hash)) return;   // popped-out chart windows don't run their own engine
  const XR = window.XR || (window.XR = {});
  const FKEY = 'xr-alert-feed';
  const last = {};          // alert id -> last price seen
  let feed = [];
  try { feed = JSON.parse(localStorage.getItem(FKEY) || '[]'); if (!Array.isArray(feed)) feed = []; } catch (e) { feed = []; }
  const saveFeed = () => { try { localStorage.setItem(FKEY, JSON.stringify(feed.slice(0, 3))); } catch (e) { /* fine */ } };
  const emit = () => window.dispatchEvent(new CustomEvent('xr-alerts'));

  const app = () => window.__app && window.__app.c;
  const userAlerts = () => { const c = app(); return c && Array.isArray(c.state.alerts) ? c.state.alerts : []; };
  const armed = () => userAlerts().filter((a) => a.on && !a.hit && Number.isFinite(Number(a.price)));

  const fmt = (v) => (v >= 1000 ? v.toLocaleString('en-US', { maximumFractionDigits: 2 }) : v.toFixed(2));
  const timeTxt = () => new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });

  const fire = (a, px) => {
    const now = userAlerts().find((x) => x.id === a.id);
    if (!now || !now.on || now.hit) return;   // already hit, paused or deleted: never fires twice
    const at = timeTxt();
    // same ticker, same level, same direction a moment ago (e.g. call wall and put wall both at 330): one card, one sound
    const twin = feed.find((f) => f.sym === a.sym && f.dir === a.dir && Math.abs(Number(f.price) - Number(a.price)) < 1e-9 && Date.now() - (f.ts || 0) < 120000);
    if (twin) {
      const c0 = app();
      if (c0) c0.setState({ alerts: userAlerts().map((x) => (x.id === a.id ? Object.assign({}, x, { hit: 'Hit ' + at, on: false }) : x)) });
      const lab = a.label || 'Price alert';
      if (String(twin.label).split(' + ').indexOf(lab) < 0) twin.label = twin.label + ' + ' + lab;
      saveFeed(); emit(); return;
    }
    const item = { id: a.id + ':' + Date.now(), alertId: a.id, sym: a.sym, label: a.label || 'Price alert', price: Number(a.price), px, dir: a.dir, at, ts: Date.now(), opt: !!a.opt, optKey: a.optKey || null, under: a.under || null };
    feed = [item].concat(feed).slice(0, 3); saveFeed();
    const c = app();
    if (c) c.setState({ alerts: userAlerts().map((x) => (x.id === a.id ? Object.assign({}, x, { hit: 'Hit ' + at, on: false }) : x)) });
    if (window.XRSet) window.XRSet.alertSound();
    if (window.XRSet && window.XRSet.get('desktop') && typeof Notification !== 'undefined') {
      try {
        const body = a.sym + ' ' + (a.dir === 'below' ? 'fell below ' : 'crossed above ') + fmt(Number(a.price)) + ' · now ' + fmt(px);
        const show = () => { try { new Notification('🔔 ' + (a.label || 'Price alert'), { body, silent: true }); } catch (e) { /* not allowed */ } };
        if (Notification.permission === 'granted') show(); else if (Notification.permission !== 'denied') Notification.requestPermission().then((p) => { if (p === 'granted') show(); });
      } catch (e) { /* no notifications on this system */ }
    }
    emit();
  };

  const check = (a, px) => {
    if (!Number.isFinite(px)) return;
    const lv = Number(a.price), prev = last[a.id];
    last[a.id] = px;
    if (prev === undefined) return;   // first look just records where price is
    const crossed = a.dir === 'below' ? prev > lv && px <= lv : prev < lv && px >= lv;
    if (crossed) fire(a, px);
  };

  let busy = false;
  const tick = async () => {
    if (busy || !XR.live) return;
    const list = armed();
    if (!list.length) return;
    busy = true;
    try {
      // stock / index alerts use the live quote feed the charts already use
      list.filter((a) => !a.opt).forEach((a) => { const q = XR.quote ? XR.quote(a.sym) : null; if (q && Number.isFinite(q.last)) check(a, q.last); });
      // premium alerts: one quote call for all contracts
      const opts = list.filter((a) => a.opt && a.occ);
      if (opts.length) {
        const occs = Array.from(new Set(opts.map((a) => a.occ))).slice(0, 50);
        const r = await fetch('/api/options?occ=' + encodeURIComponent(occs.join(',')), { cache: 'no-store' });
        const j = r.ok ? await r.json() : {};
        opts.forEach((a) => { const q = j[a.occ]; const px = q ? (Number.isFinite(q.mid) && q.mid > 0 ? q.mid : q.last) : NaN; check(a, Number(px)); });
      }
    } catch (e) { /* offline for a moment: try again next tick */ }
    busy = false;
  };
  setInterval(tick, 4000);

  XR.alerts = {
    feed: () => feed.slice(),
    armedCount: () => armed().length,
    dismiss: (id) => { feed = feed.filter((x) => x.id !== id); saveFeed(); emit(); },
    clear: () => { feed = []; saveFeed(); emit(); },
    open: (item) => {   // jump to the chart the alert was on
      const c = app(); if (!c || !item) return;
      if (item.opt && item.optKey) {
        const [u, k, t, e] = String(item.optKey).split('|');
        c.setState({ page: 'watch', wlMode: 'opt', optActive: { under: u, strike: Number(k), type: t, expKey: e }, chartSym: u });
      } else c.setState({ page: 'dash', sym: item.sym, chartSym: item.sym });
    },
    _check: check   // used by tests
  };
})();
