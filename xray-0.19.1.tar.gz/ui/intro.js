// Launch intro: the hologram Delfi logo while X-ray really starts up (server, brokers, quotes, chart).
// The bar follows the actual steps. Click or press any key to skip. Never shown in popped-out chart windows.
(function () {
  'use strict';
  const el = document.getElementById('xr-intro');
  if (!el) return;
  if (/[#&]pop=/.test(location.hash)) { el.remove(); return; }
  if (window.XRSet && window.XRSet.get('skipIntro')) { el.remove(); return; }
  try { if (sessionStorage.getItem('xr-quick-return') === '1') { el.remove(); return; } } catch (e) { /* fine */ }   // back from Data connection: small loader instead   // Settings: skip the startup animation
  const $ = (s) => el.querySelector(s);
  const t0 = Date.now();
  const MIN = 2600, MAX = 11000;

  // footer: greeting + market clock (ET)
  const et = () => { const o = {}; new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', weekday: 'short', hour: 'numeric', minute: '2-digit', hour12: false }).formatToParts(new Date()).forEach((p) => { o[p.type] = p.value; }); return o; };
  const market = () => {
    const o = et(); const h = Number(o.hour) % 24, m = Number(o.minute), mins = h * 60 + m;
    const wk = !/Sat|Sun/.test(o.weekday);
    // shown in the user's own time; open/closed is still worked out on New York hours
    const clock = new Intl.DateTimeFormat('en-US', { hour: 'numeric', minute: '2-digit' }).format(new Date());
    const st = !wk ? 'MARKET CLOSED' : mins >= 570 && mins < 960 ? 'MARKET OPEN' : mins >= 240 && mins < 570 ? 'PRE-MARKET' : mins >= 960 && mins < 1200 ? 'AFTER HOURS' : 'MARKET CLOSED';
    return st + ' ' + clock;
  };
  const hr = new Date().getHours();
  const hello = hr < 5 ? 'GOOD EVENING' : hr < 12 ? 'GOOD MORNING' : hr < 17 ? 'GOOD AFTERNOON' : 'GOOD EVENING';
  const setFoot = () => { $('.xi-hello').textContent = hello + ' · ' + market(); };
  setFoot();

  // steps: label, state ('wait' | 'ok' | 'warn' | 'skip'), weight
  const steps = [
    { k: 'eng', label: 'Starting engine', st: 'wait', w: 20 },
    { k: 'wb', label: 'Webull', st: 'wait', w: 20 },
    { k: 'sw', label: 'Schwab', st: 'wait', w: 15 },
    { k: 'q', label: 'Live prices', st: 'wait', w: 20 },
    { k: 'ch', label: 'Building chart', st: 'wait', w: 25 }
  ];
  const S = (k) => steps.find((x) => x.k === k);
  const set = (k, st, label) => { const s = S(k); if (s.st === 'wait' || s.st !== st) { s.st = st; if (label) s.label = label; } };
  let shown = 0, done = false;
  const draw = () => {
    const live = steps.filter((s) => s.st !== 'skip');
    const total = live.reduce((a, s) => a + s.w, 0) || 1;
    const got = live.reduce((a, s) => a + (s.st === 'wait' ? 0 : s.w), 0);
    const target = done ? 100 : Math.min(97, got / total * 100);
    shown += (target - shown) * 0.12; if (target - shown < 0.4) shown = target;
    const pct = Math.round(shown);
    $('.xi-pct').textContent = (done && pct >= 100 ? 'READY' : 'LOADING') + ' ' + pct + '%';
    const blocks = el.querySelectorAll('.xi-blocks i'); const on = Math.round(pct / 100 * blocks.length);
    blocks.forEach((b, i) => b.classList.toggle('on', i < on));
    // the steps drive the bar; they aren't listed on screen
  };

  const check = () => {
    const XR = window.XR; const st = XR && XR.status;
    if (st) set('eng', 'ok', 'Engine online');
    if (st) {
      if (!st.hasKeys) set('wb', 'skip');
      else if (st.webull && st.webull.live) set('wb', 'ok', 'Webull connected');
      else if (st.webull && st.webull.error) set('wb', 'warn', 'Webull offline');
      else if (st.phase === 'approve') S('wb').label = 'Webull · approve in the Webull app';
      if (!st.schwab || !st.schwab.hasKeys) set('sw', 'skip');
      else if (st.schwab.live) {
        const exp = st.schwab.loginExpires; const d = exp ? Math.max(0, Math.floor((exp - Date.now()) / 86400000)) : null;
        set('sw', 'ok', 'Schwab session' + (d != null ? ' · ' + (d >= 1 ? d + 'd left' : 'ends today') : ''));
      } else if (st.schwab.phase && st.schwab.phase !== 'connecting' && st.schwab.phase !== 'idle') set('sw', 'warn', 'Schwab login expired');
      if (!st.hasKeys && !(st.schwab && st.schwab.hasKeys)) { set('q', 'skip'); set('ch', 'skip'); set('wb', 'warn', 'No broker connected · add keys under Data connection'); S('wb').st = 'warn'; }
    }
    const app = window.__app && window.__app.c && window.__app.c.state;
    if (XR && XR.live && app) {
      const sym = app.chartSym || 'SPX';
      if (XR.q && XR.q[sym]) set('q', 'ok', 'Live prices');
      if (XR.b && Object.keys(XR.b).some((k) => k.indexOf(sym + '|') === 0 && XR.b[k] && XR.b[k].bars && XR.b[k].bars.length)) set('ch', 'ok', sym.replace(/^\^/, '') + ' chart ready');
    }
    // a broker that never answers shouldn't hold the intro hostage
    const age = Date.now() - t0;
    if (age > 7000) steps.forEach((s) => { if (s.st === 'wait' && s.k !== 'eng') s.st = 'skip'; });
    const allIn = steps.every((s) => s.st !== 'wait');
    if ((allIn && age >= MIN) || age >= MAX) finish();
  };

  let gone = false;
  const finish = () => {
    if (done) return; done = true;
    setTimeout(() => { el.classList.add('xi-out'); setTimeout(remove, 650); }, 520);
  };
  const remove = () => { if (gone) return; gone = true; clearInterval(iv); cancelAnimationFrame(raf); el.remove(); window.dispatchEvent(new Event('resize')); };
  const skip = () => { if (!done) { done = true; } el.classList.add('xi-out'); setTimeout(remove, 380); };
  el.addEventListener('click', skip);
  window.addEventListener('keydown', function k() { window.removeEventListener('keydown', k); if (!gone) skip(); });

  let raf = 0; const loop = () => { draw(); raf = requestAnimationFrame(loop); }; raf = requestAnimationFrame(loop);
  const iv = setInterval(() => { check(); setFoot(); }, 150);
})();
