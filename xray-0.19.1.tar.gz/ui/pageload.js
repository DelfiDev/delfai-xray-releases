// Loading screen between X-ray and the data connection page: shows the moment you click, hides once the
// next page has actually loaded (setup.html calls XRPageReady() after its first status check).
(function () {
  'use strict';
  const css = '#xr-pl{position:fixed;inset:0;z-index:99999;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px;background:radial-gradient(60% 50% at 50% 45%,rgba(143,210,236,.07),transparent 70%),#05080D;opacity:0;pointer-events:none;transition:opacity .18s ease}'
    + '#xr-pl.on{opacity:1;pointer-events:all}'
    + '#xr-pl .ring{position:relative;width:96px;height:96px;display:flex;align-items:center;justify-content:center}'
    + '#xr-pl .ring:before{content:"";position:absolute;inset:0;border-radius:50%;border:2px solid rgba(143,210,236,.12);border-top-color:#8FD2EC;animation:xrplspin 1s linear infinite;box-shadow:0 0 24px rgba(143,210,236,.15)}'
    + '#xr-pl img{width:54px;height:54px;animation:xrplglow 1.6s ease-in-out infinite}'
    + '#xr-pl .t{font:500 12px "JetBrains Mono",monospace;letter-spacing:.16em;color:#8FD2EC;text-transform:uppercase}'
    + '@keyframes xrplspin{to{transform:rotate(360deg)}}@keyframes xrplglow{0%,100%{filter:drop-shadow(0 0 4px rgba(143,210,236,.35))}50%{filter:drop-shadow(0 0 14px rgba(143,210,236,.85))}}';
  let el = null;
  const ensure = () => {
    if (el) return el;
    const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
    el = document.createElement('div'); el.id = 'xr-pl'; el.setAttribute('role', 'status');
    el.innerHTML = '<div class="ring"><img src="delfi-logo.png" alt=""></div><div class="t"></div>';
    document.body.appendChild(el);
    return el;
  };
  const show = (txt, instant) => {
    const o = ensure(); o.querySelector('.t').textContent = txt; o.setAttribute('aria-label', txt);
    if (instant) { o.style.transition = 'none'; o.classList.add('on'); void o.offsetWidth; o.style.transition = ''; return; }
    void o.offsetWidth; o.classList.add('on');
  };
  const hide = () => { if (el) el.classList.remove('on'); };
  const label = (url) => (/setup\.html/.test(url) ? 'Opening data connection…' : 'Loading X-ray…');
  // go to another page with the loader up first, so the click feels instant even if the page takes a second
  window.XRGo = (url) => {
    show(label(url));
    // coming back into X-ray from the data page: skip the big launch intro, keep this small loader instead
    if (!/setup\.html/.test(url)) { try { sessionStorage.setItem('xr-quick-return', '1'); } catch (e) { /* fine */ } }
    requestAnimationFrame(() => requestAnimationFrame(() => { location.href = url; }));
  };
  window.XRPageReady = hide;
  document.addEventListener('click', (e) => {
    const a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || a.target === '_blank') return;
    const href = a.getAttribute('href');
    if (!/^\/(setup\.html)?$/.test(href)) return;   // only X-ray's own two pages
    e.preventDefault(); window.XRGo(href);
  }, true);
  // arriving on a page that waits for its data: loader is up from the first paint, page calls XRPageReady()
  const boot = () => {
    let quick = false; try { quick = sessionStorage.getItem('xr-quick-return') === '1'; } catch (e) { quick = false; }
    if (quick && document.getElementById('app')) {
      // the intro script (later on the page) reads this flag too, so clear it only once everything has loaded
      window.addEventListener('load', () => { try { sessionStorage.removeItem('xr-quick-return'); } catch (e) { /* fine */ } });
      show('Loading X-ray…', true);
      const t0 = Date.now();
      const wait = () => { if ((window.__app && window.__app.c) || Date.now() - t0 > 8000) setTimeout(hide, 250); else setTimeout(wait, 80); };
      wait();
      return;
    }
    if (document.body && document.body.dataset.xrWait) {
      show(document.body.dataset.xrWait, true); setTimeout(hide, 8000);   // never hang more than 8s
    }
  };
  if (document.body) boot(); else document.addEventListener('DOMContentLoaded', boot);
  // coming back with the browser Back button: don't leave the loader stuck on
  window.addEventListener('pageshow', (e) => { if (e.persisted) hide(); });
})();
