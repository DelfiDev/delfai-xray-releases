// DELFAi X-ray app: starts the local data server and opens the app window.
// Loaded by main.js (the starter), which picks the newest healthy version. This file and everything
// next to it can be replaced by an update; main.js never changes.
'use strict';
const { app, BrowserWindow, shell, Menu, dialog, Notification, session } = require('electron');
// developer tools only when Delfi runs X-ray with XRAY_DEV=1; customers can't open them
const DEV = process.env.XRAY_DEV === '1';
const path = require('path');
const os = require('os');
const DATA_DIR = path.join(os.homedir(), '.delfai-xray'); // same folder as the browser edition, so keys carry over
const { start } = require('./server/server');
const XB = global.__xray || {};   // set by the starter: which version is running and how to mark it healthy
const VERSION = XB.version || app.getVersion();
const restartApp = () => { app.relaunch(); app.exit(0); };
const fs = require('fs');
// page errors go into the same log as the server, so problems on someone's machine can be traced
const ulog = (m) => { try { fs.appendFileSync(path.join(DATA_DIR, 'xray.log'), new Date().toISOString() + ' [window] ' + m + '\n'); } catch (e) { /* ignore */ } };
const watchWin = (w, tag) => {
  const wc = w.webContents;
  // newer Electron passes one event object, older ones passed (event, level, message, line, source)
  wc.on('console-message', (e, level, msg, line, src) => {
    const isErr = typeof level === 'number' ? level >= 3 : e && e.level === 'error';
    if (!isErr) return;
    const m = typeof level === 'number' ? msg : e.message, ln = typeof level === 'number' ? line : e.lineNumber, sr = typeof level === 'number' ? src : e.sourceId;
    ulog(tag + ' ' + String(m).slice(0, 300) + ' (' + String(sr || '').split('/').pop() + ':' + ln + ')');
  });
  wc.on('did-fail-load', (e, code, desc, url) => ulog(tag + ' failed to load ' + url + ': ' + desc));
  wc.on('render-process-gone', (e, d) => ulog(tag + ' renderer gone: ' + (d && d.reason)));
  w.on('unresponsive', () => ulog(tag + ' unresponsive'));
};

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) { app.quit(); } // a second launch just focuses the open window
let win = null;

async function boot() {
  let s;
  try {
    s = await start({ port: 7457, dataDir: DATA_DIR, uiDir: path.join(__dirname, 'ui'), version: VERSION, onRestart: restartApp });
  } catch (e) {
    if (e && e.code === 'EADDRINUSE') s = await start({ port: 0, dataDir: DATA_DIR, uiDir: path.join(__dirname, 'ui'), version: VERSION, onRestart: restartApp });
    else { dialog.showErrorBox('DELFAi X-ray', 'Could not start: ' + (e && e.message)); app.quit(); return; }
  }
  win = new BrowserWindow({
    width: 1480, height: 940, minWidth: 900, minHeight: 600,
    backgroundColor: '#0E131B', title: 'DELFAi X-ray', show: false,
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, webSecurity: true, devTools: DEV, spellcheck: false, webviewTag: false, navigateOnDragDrop: false }
  });
  // Windows: taskbar + pinned icon show the Delfi logo, not the default app engine icon
  if (process.platform === 'win32') { try { win.setAppDetails({ appId: 'com.delfitrading.xray', appIconPath: path.join(__dirname, 'build', 'icon.ico'), appIconIndex: 0, relaunchCommand: '"' + process.execPath + '"', relaunchDisplayName: 'DELFAi X-ray' }); } catch (e) { /* older Windows */ } }
  win.once('ready-to-show', () => win.show());
  // still running fine 15s after the page loaded: this version is healthy (the starter won't roll it back)
  win.webContents.once('did-finish-load', () => setTimeout(() => { try { if (XB.markHealthy) XB.markHealthy(); } catch (e) { /* fine */ } }, 15000));
  watchWin(win, 'main');
  // links to news etc. open in the normal browser
  // pop-out charts open as their own X-ray windows; any other link opens in the normal browser
  const popOpts = { show: false, width: 1200, height: 760, minWidth: 420, minHeight: 300, backgroundColor: '#0E131B', title: 'DELFAi X-ray', autoHideMenuBar: true, icon: path.join(__dirname, 'build', 'icon.png'), webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, webSecurity: true, devTools: DEV, spellcheck: false, webviewTag: false, navigateOnDragDrop: false } };
  const linkHandler = ({ url }) => { if (url.startsWith(s.url) && /#pop=/.test(url)) return { action: 'allow', overrideBrowserWindowOptions: popOpts }; if (/^https?:\/\//.test(url)) shell.openExternal(url); return { action: 'deny' }; };
  win.webContents.setWindowOpenHandler(linkHandler);
  app.on('browser-window-created', (e, w) => { if (w === win) return; watchWin(w, 'popout'); w.once('ready-to-show', () => w.show()); setTimeout(() => { try { if (!w.isDestroyed() && !w.isVisible()) w.show(); } catch (err) { /* closed */ } }, 2500); w.setMenuBarVisibility(false); w.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:\/\//.test(url) && !url.startsWith(s.url)) shell.openExternal(url); return { action: 'deny' }; }); if (process.platform === 'win32') { try { w.setAppDetails({ appId: 'com.delfitrading.xray', appIconPath: path.join(__dirname, 'build', 'icon.ico'), appIconIndex: 0 }); } catch (err) { /* fine */ } } });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith(s.url)) { e.preventDefault(); if (/^https?:\/\//.test(url)) shell.openExternal(url); } });
  win.loadURL(s.url);
  watchSchwabLogin(s.url);
}

// Schwab ends API logins every 7 days: a desktop notification 24 hours before, and again when it ends
function watchSchwabLogin(base) {
  const sent = {};
  const notify = (key, title, body) => {
    if (sent[key]) return; sent[key] = true;
    if (win && !win.isFocused()) win.flashFrame(true);
    if (!Notification.isSupported()) return;
    const n = new Notification({ title, body, icon: path.join(__dirname, 'build', 'icon.png') });
    n.on('click', () => { if (!win) return; if (win.isMinimized()) win.restore(); win.show(); win.focus(); win.loadURL(base + 'setup.html#schwab'); });
    n.show();
  };
  const check = async () => {
    try {
      const st = await (await fetch(base + 'api/status')).json();
      const sw = st && st.schwab; const exp = sw && sw.loginExpires;
      if (!sw || !sw.hasKeys || !exp) return;
      const ms = exp - Date.now();
      if (ms <= 0) notify('end:' + exp, 'Schwab login expired', 'Schwab makes you sign in again every 7 days. Click to reconnect, it takes 15 seconds.');
      else if (ms < 24 * 3600000) notify('soon:' + exp, 'Schwab login expires soon', 'Your Schwab connection ends in about ' + Math.max(1, Math.round(ms / 3600000)) + ' hours. Click to reconnect now.');
    } catch (e) { /* server busy, try again later */ }
  };
  setTimeout(check, 15000);
  setInterval(check, 10 * 60000);
}

const template = [
  ...(process.platform === 'darwin' ? [{ role: 'appMenu' }] : []),
  { label: 'File', submenu: [{ label: 'Data connection', accelerator: 'CmdOrCtrl+,', click: () => win && win.loadURL(win.webContents.getURL().replace(/\/[^/]*$/, '/setup.html')) }, { type: 'separator' }, process.platform === 'darwin' ? { role: 'close' } : { role: 'quit' }] },
  { role: 'editMenu' },
  { label: 'View', submenu: [{ role: 'reload' }, { role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { type: 'separator' }, { role: 'togglefullscreen' }].concat(DEV ? [{ role: 'toggleDevTools' }] : []) },
  { role: 'windowMenu' }
];

if (process.platform === 'win32') app.setAppUserModelId('com.delfitrading.xray');
app.whenReady().then(() => {
  if (!gotLock) return;
  // only what X-ray needs: desktop notifications, copy to clipboard, full screen. No camera, location, etc.
  const allowed = new Set(['notifications', 'clipboard-sanitized-write', 'fullscreen']);
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(allowed.has(perm)));
  session.defaultSession.setPermissionCheckHandler((wc, perm) => allowed.has(perm));
  session.defaultSession.on('will-download', (ev, item) => { if (!/^(blob:|data:)/.test(item.getURL())) ev.preventDefault(); });
  Menu.setApplicationMenu(Menu.buildFromTemplate(template)); boot();
});
// no embedded web views, no downloads of files from pages, no new windows except X-ray's own
app.on('web-contents-created', (e, wc) => {
  wc.on('will-attach-webview', (ev) => ev.preventDefault());
  if (!DEV) wc.on('devtools-opened', () => wc.closeDevTools());
});
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on('window-all-closed', () => app.quit());
