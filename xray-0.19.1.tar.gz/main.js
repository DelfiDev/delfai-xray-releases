// DELFAi X-ray starter. Installed once, never updated: it picks which version of the app to run.
// Updates land in ~/.delfai-xray/versions/<version>. The newest one that finished downloading and isn't
// marked bad runs; if a new version never gets healthy (crashes on start), it's marked bad and the
// previous good version runs instead. If anything here goes wrong, the version that came with the installer runs.
'use strict';
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');
// only versions signed by Delfi Trading run: every file's fingerprint is in files.json, signed with Delfi's key
const PUB = '-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAHsk5bWoFbOsxz/ao5DkekWASB1R1dcjJ9DNmynHIDEw=\n-----END PUBLIC KEY-----\n';
const MARKERS = new Set(['.complete', '.trial', '.healthy', '.bad', 'files.json', 'files.sig']);
function signedOk(dir, ver) {
  try {
    const txt = fs.readFileSync(path.join(dir, 'files.json'));
    const sig = Buffer.from(fs.readFileSync(path.join(dir, 'files.sig'), 'utf8').trim(), 'base64');
    if (!crypto.verify(null, txt, PUB, sig)) return false;
    const m = JSON.parse(txt.toString('utf8'));
    if (!m || m.version !== ver || !m.files) return false;
    const walk = (d, pre) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(d, e.name), pre + e.name + '/') : [pre + e.name]));
    const onDisk = walk(dir, '').filter((f) => !MARKERS.has(f));
    if (onDisk.length !== Object.keys(m.files).length) return false;   // nothing added, nothing missing
    return onDisk.every((f) => m.files[f] && crypto.createHash('sha256').update(fs.readFileSync(path.join(dir, f))).digest('hex') === m.files[f]);
  } catch (e) { return false; }
}
const VDIR = path.join(os.homedir(), '.delfai-xray', 'versions');
let bundled = '0.0.0';
try { bundled = require('./package.json').version; } catch (e) { /* keep 0.0.0 */ }
const cmp = (a, b) => {
  const pa = String(a).split('.').map((x) => parseInt(x, 10) || 0), pb = String(b).split('.').map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < 3; i++) { if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0) ? 1 : -1; }
  return 0;
};
const has = (d, f) => { try { return fs.existsSync(path.join(d, f)); } catch (e) { return false; } };
const touch = (d, f, v) => { try { fs.writeFileSync(path.join(d, f), v || new Date().toISOString()); } catch (e) { /* read-only? fine */ } };

function pick() {
  let best = { dir: __dirname, ver: bundled };
  let list = [];
  try { list = fs.readdirSync(VDIR).filter((v) => /^\d+\.\d+\.\d+$/.test(v)); } catch (e) { list = []; }
  list.forEach((v) => {
    const d = path.join(VDIR, v);
    if (!has(d, '.complete') || has(d, '.bad') || !has(d, 'app-main.js')) return;
    if (cmp(v, best.ver) > 0) best = { dir: d, ver: v };
  });
  // the chosen version must carry Delfi's signature and be untouched; otherwise it's marked bad and skipped
  if (best.dir !== __dirname && !signedOk(best.dir, best.ver)) { touch(best.dir, '.bad', 'not signed by Delfi Trading or files were changed'); return pick(); }
  return best;
}

let chosen = pick();
if (chosen.dir !== __dirname) {
  // started before but never became healthy: it crashed or hung, so don't trust it again
  if (has(chosen.dir, '.trial') && !has(chosen.dir, '.healthy')) { touch(chosen.dir, '.bad', 'never became healthy'); chosen = pick(); }
  if (chosen.dir !== __dirname && !has(chosen.dir, '.healthy')) touch(chosen.dir, '.trial');
}
global.__xray = {
  version: chosen.ver, dir: chosen.dir, bundled, bundledDir: __dirname,
  markHealthy: () => { if (chosen.dir !== __dirname) touch(chosen.dir, '.healthy'); }
};
// run it; if it won't even load, mark it bad and try the next best (last good update, then the installed one)
for (let tries = 0; ; tries++) {
  try { require(path.join(chosen.dir, 'app-main.js')); break; } catch (e) {
    if (chosen.dir === __dirname || tries > 3) throw e;
    touch(chosen.dir, '.bad', String((e && e.stack) || e).slice(0, 2000));
    chosen = pick();
    global.__xray = { version: chosen.ver, dir: chosen.dir, bundled, bundledDir: __dirname, markHealthy: () => { if (chosen.dir !== __dirname) touch(chosen.dir, '.healthy'); } };
  }
}
