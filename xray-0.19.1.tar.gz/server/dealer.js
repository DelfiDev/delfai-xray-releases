// Dealer hedging model: estimates what option dealers have to buy or sell, from the broker's own chain
// (open interest, volume, bid/ask, IV). Nobody sees dealer books directly; this is the same kind of estimate
// paid gamma services publish, with two versions:
//   standard - the usual assumption (dealers long calls, short puts)
//   signed   - standard, plus today's new positions signed by where they traded (near ask = customers bought,
//              so dealers are short them; near bid = customers sold, so dealers are long them)
'use strict';
const { greeks, yearsToExpiry, normIv, impliedVol } = require('./gex');
const { nyParts } = require('./data');

const INDEXY = /^(SPX|SPY|QQQ|IWM|DIA|XSP|NDX|RUT)$/;

async function chainRows(dm, sym, nExp, spot) {
  const ex = await dm.expirations(sym);
  const exps = (ex.expiries || []).slice(0, nExp);
  const rows = [];
  for (let i = 0; i < exps.length; i++) {
    const exp = exps[i];
    const pct = INDEXY.test(sym) ? (i < 2 ? 0.05 : 0.07) : (i < 2 ? 0.1 : 0.14);
    const list = await dm.chainContracts(sym, exp, pct);
    const snap = await dm.optionQuotes(list.map((c) => c.occ), i < 2 ? 30000 : 120000);
    list.forEach((c) => {
      const s = snap[c.occ]; if (!s) return;
      rows.push({ exp, type: c.type, K: Number(c.strike), oi: s.oi || 0, vol: s.volume || 0, bid: s.bid || 0, ask: s.ask || 0, last: s.last, mid: s.mid, iv: s.iv });
    });
  }
  return { rows, exps, step: ex.step || 1 };
}

async function dealerModel(dm, sym, opts) {
  const nExp = Math.max(1, Math.min(6, (opts && opts.exps) || 4));
  const q = (await dm.quotes([sym]))[sym];
  if (!q || !q.last) throw new Error('No price for ' + sym);
  const S = q.last;
  const { rows, exps, step } = await chainRows(dm, sym, nExp, S);
  if (!rows.length) throw new Error('No option chain for ' + sym);
  const now = Date.now();
  const p = nyParts(now);
  const minsLeft = Math.max(0, 960 - (p.h * 60 + p.m));
  const sessionLeft = /Sat|Sun/.test(p.wd) ? 0 : Math.min(1, minsLeft / 390);

  // per contract: IV, years left, standard and signed dealer position (contracts; + = dealers long)
  const C = [];
  rows.forEach((r) => {
    const T = yearsToExpiry(r.exp, now);
    let iv = normIv(r.iv);
    if (!iv) { const px = r.mid > 0 ? r.mid : r.last; iv = px > 0 ? impliedVol(px, S, r.K, T, r.type) : null; }
    if (!iv || !(iv > 0.01)) return;
    const std = (r.type === 'C' ? 1 : -1) * r.oi;
    const lean = r.ask > r.bid && r.last != null ? (r.last - r.bid) / (r.ask - r.bid) : 0.5;
    const fresh = r.vol * Math.min(1, r.vol / (r.vol + r.oi + 1)); // share of today's volume that looks like new positions
    const flow = lean >= 0.65 ? -fresh : lean <= 0.35 ? fresh : 0; // customers bought -> dealers short
    C.push({ exp: r.exp, type: r.type, K: r.K, T, iv, std, sig: std + flow, oi: r.oi, vol: r.vol, mid: r.mid, lean });
  });
  if (!C.length) throw new Error('No usable IV in the ' + sym + ' chain');

  const at = (Sx, f) => { let tot = 0; C.forEach((c) => { const g = greeks(Sx, c.K, c.T, c.iv, c.type); tot += f(c, g); }); return tot; };
  // dollar gamma per 1% move and dollar delta at a hypothetical price
  const gexAt = (Sx, key) => at(Sx, (c, g) => c[key] * g.gamma * 100 * Sx * Sx * 0.01);
  const dexAt = (Sx, key) => at(Sx, (c, g) => c[key] * g.delta * 100 * Sx);
  const shares = (Sx, key) => at(Sx, (c, g) => c[key] * g.delta * 100);

  const grid = [];
  for (let k = -5; k <= 5; k += 0.5) grid.push(k);
  const base = { std: shares(S, 'std'), sig: shares(S, 'sig') };
  const curve = grid.map((pct) => {
    const Sx = S * (1 + pct / 100);
    const o = { pct, S: Sx };
    ['std', 'sig'].forEach((key) => {
      o[key + 'Gex'] = gexAt(Sx, key);
      // dealers keep delta-neutral: if their option delta rises they sell stock, so hedge flow = -(change) in $
      o[key + 'Hedge'] = -(shares(Sx, key) - base[key]) * Sx;
    });
    return o;
  });
  const flipOf = (key) => {
    let best = null;
    for (let i = 1; i < curve.length; i++) {
      const a = curve[i - 1][key + 'Gex'], b = curve[i][key + 'Gex'];
      if ((a <= 0 && b > 0) || (a >= 0 && b < 0)) { const t = a / (a - b); const x = curve[i - 1].S + (curve[i].S - curve[i - 1].S) * t; if (!best || Math.abs(x - S) < Math.abs(best - S)) best = x; }
    }
    return best;
  };

  // per strike gamma (standard and signed) for the profile and the walls
  const byK = new Map();
  C.forEach((c) => {
    const g = greeks(S, c.K, c.T, c.iv, c.type);
    const e = byK.get(c.K) || { K: c.K, call: 0, put: 0, std: 0, sig: 0, oi: 0 };
    const v = g.gamma * 100 * S * S * 0.01;
    if (c.type === 'C') e.call += c.oi * v; else e.put -= c.oi * v;
    e.std += c.std * v; e.sig += c.sig * v; e.oi += c.oi;
    byK.set(c.K, e);
  });
  const strikes = Array.from(byK.values()).sort((a, b) => a.K - b.K);
  const cw = strikes.reduce((a, b) => (b.call > (a ? a.call : -Infinity) && b.K >= S * 0.98 ? b : a), null);
  const pw = strikes.reduce((a, b) => (b.put < (a ? a.put : Infinity) && b.K <= S * 1.02 ? b : a), null);

  // charm: hedge flow from time passing (rest of today), vanna: hedge flow if IV drops 1 point
  const charmFlow = (key) => -at(S, (c, g) => c[key] * g.charm * 100 * Math.min(sessionLeft, c.T * 365)) * S;
  const vannaFlow = (key) => -at(S, (c, g) => c[key] * g.vanna * -0.01 * 100) * S;

  // first expiry: expected move (ATM straddle), max pain, pin strike
  const e0 = exps[0];
  const first = C.filter((c) => c.exp === e0);
  const ks = Array.from(new Set(first.map((c) => c.K))).sort((a, b) => a - b);
  const atm = ks.reduce((a, b) => (Math.abs(b - S) < Math.abs(a - S) ? b : a), ks[0]);
  const cA = first.find((c) => c.K === atm && c.type === 'C'), pA = first.find((c) => c.K === atm && c.type === 'P');
  const em = cA && pA && cA.mid > 0 && pA.mid > 0 ? cA.mid + pA.mid : (cA ? S * cA.iv * Math.sqrt(cA.T) : null);
  let maxPain = null, mpBest = Infinity;
  ks.forEach((K) => { let pain = 0; first.forEach((c) => { pain += c.oi * (c.type === 'C' ? Math.max(0, K - c.K) : Math.max(0, c.K - K)); }); if (pain < mpBest) { mpBest = pain; maxPain = K; } });
  const near = strikes.filter((x) => !em || Math.abs(x.K - S) <= em * 1.2);
  const pin = near.length ? near.reduce((a, b) => (b.std > a.std ? b : a)).K : null;
  const atmIv = cA ? cA.iv : null;

  // tape check: is price acting like dealers are long gamma (chop, mean reversion) or short gamma (trend, expansion)?
  let tape = null;
  try {
    const b = await dm.bars(sym, '5m');
    const bars = (b && b.bars) || [];
    const day = p.date;
    const fmt = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/New_York' });
    const today = bars.filter((x) => x.t && fmt.format(new Date(x.t)) === day);
    const use = today.length >= 6 ? today : bars.slice(-24);
    if (use.length >= 6) {
      const rets = []; for (let i = 1; i < use.length; i++) rets.push(Math.log(use[i].c / use[i - 1].c));
      const m = rets.reduce((a, x) => a + x, 0) / rets.length;
      const sd = Math.sqrt(rets.reduce((a, x) => a + (x - m) * (x - m), 0) / rets.length);
      const rv = sd * Math.sqrt(78 * 252);
      let pv = 0, vv = 0, cross = 0, prevSide = 0;
      use.forEach((x) => { const tp = (x.h + x.l + x.c) / 3; pv += tp * (x.v || 1); vv += (x.v || 1); const side = x.c >= pv / vv ? 1 : -1; if (prevSide && side !== prevSide) cross++; prevSide = side; });
      const hi = Math.max(...use.map((x) => x.h)), lo = Math.min(...use.map((x) => x.l));
      const rangeVsEm = em ? (hi - lo) / em : null;
      const ratio = atmIv ? rv / atmIv : null;
      let score = 0;
      if (ratio != null) score += ratio < 0.8 ? 1 : ratio > 1.2 ? -1 : 0;
      score += cross >= Math.max(4, use.length / 8) ? 1 : cross <= 1 ? -1 : 0;
      if (rangeVsEm != null) score += rangeVsEm < 0.6 ? 1 : rangeVsEm > 1 ? -1 : 0;
      tape = { rv, iv: atmIv, ratio, crosses: cross, bars: use.length, rangeVsEm, today: today.length >= 6, label: score >= 2 ? 'Acting like long gamma' : score <= -2 ? 'Acting like short gamma' : 'Mixed', score };
    }
  } catch (e) { tape = null; }

  const tot = (key) => ({
    gex: gexAt(S, key), dex: dexAt(S, key), flip: flipOf(key),
    charm: charmFlow(key), vanna: vannaFlow(key)
  });
  const std = tot('std'), sig = tot('sig');
  const hedgeAt = (pct, key) => { const c = curve.find((x) => Math.abs(x.pct - pct) < 1e-9); return c ? c[key + 'Hedge'] : null; };
  return {
    symbol: sym, spot: S, t: now, exps, step, sessionLeft,
    standard: Object.assign(std, { down1: hedgeAt(-1, 'std'), up1: hedgeAt(1, 'std') }),
    signed: Object.assign(sig, { down1: hedgeAt(-1, 'sig'), up1: hedgeAt(1, 'sig') }),
    curve, strikes: strikes.filter((x) => Math.abs(x.K - S) <= S * 0.06),
    walls: { call: cw ? cw.K : null, put: pw ? pw.K : null },
    expiry0: { exp: e0, em, atm, maxPain, pin, iv: atmIv },
    tape, contracts: C.length
  };
}

module.exports = { dealerModel };
