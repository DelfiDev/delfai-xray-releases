// Off-exchange (dark pool) short volume from FINRA's free daily files.
// Each file lists, per ticker, shares sold short and total shares traded off-exchange that day (TRF/ADF/ORF).
// When market makers fill buyers off-exchange they usually sell short to do it, so a high short share of
// off-exchange volume is read as buying pressure (the idea behind the DIX index). Daily, not real-time.
'use strict';
const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');

class Finra {
  constructor(o) {
    this.dir = o.cacheDir; this.log = o.log || (() => {});
    this.base = process.env.FINRA_URL || 'https://cdn.finra.org/equity/regsho/daily/CNMSshvol';
    fs.mkdirSync(this.dir, { recursive: true });
    this.days = new Map(); // yyyymmdd -> { sym: [short, total] } | null (no file)
    this.busy = null; this.lastScan = 0;
  }
  get(url) {
    return new Promise((resolve, reject) => {
      const lib = url.startsWith('http:') ? http : https;
      const rq = lib.get(url, { headers: { 'User-Agent': 'Mozilla/5.0 (compatible; DELFAi-Xray)' }, timeout: 20000 }, (res) => {
        if (res.statusCode === 404 || res.statusCode === 403) { res.resume(); return resolve(null); }
        if (res.statusCode !== 200) { res.resume(); return reject(new Error('FINRA answered ' + res.statusCode)); }
        let d = ''; res.setEncoding('utf8'); res.on('data', (c) => { d += c; }); res.on('end', () => resolve(d));
      });
      rq.on('timeout', () => rq.destroy(new Error('FINRA took too long')));
      rq.on('error', reject);
    });
  }
  parse(txt) {
    const out = {};
    txt.split(/\r?\n/).forEach((ln) => { const f = ln.split('|'); if (f.length < 5 || f[0] === 'Date') return; const sh = Number(f[2]), tot = Number(f[4]); if (f[1] && Number.isFinite(sh) && tot > 0) out[f[1]] = [sh, tot]; });
    return out;
  }
  // last N weekdays (newest first) as yyyymmdd, in New York time
  dates(n) {
    const out = []; let t = Date.now();
    const fmt = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/New_York' });
    const wd = new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', weekday: 'short' });
    for (let k = 0; out.length < n && k < n * 2 + 10; k++, t -= 86400000) { if (/Sat|Sun/.test(wd.format(new Date(t)))) continue; out.push(fmt.format(new Date(t)).replace(/-/g, '')); }
    return out;
  }
  async day(d) {
    if (this.days.has(d)) return this.days.get(d);
    const f = path.join(this.dir, d + '.json');
    try { const v = JSON.parse(fs.readFileSync(f, 'utf8')); this.days.set(d, v); return v; } catch (e) { /* not cached */ }
    const txt = await this.get(this.base + d + '.txt');
    if (txt == null) { return null; } // not published (holiday, or before 6pm ET today)
    const v = this.parse(txt);
    if (Object.keys(v).length < 100) return null;
    try { fs.writeFileSync(f, JSON.stringify(v)); } catch (e) { /* fine */ }
    this.days.set(d, v); return v;
  }
  // load the last ~20 trading days (cached on disk; a new file appears each evening)
  async load() {
    if (this.busy) return this.busy;
    if (this.loaded && Date.now() - this.lastScan < 30 * 60000) return this.loaded;
    this.busy = (async () => {
      const want = this.dates(30); const got = []; const q = want.slice();
      const worker = async () => { while (q.length && got.length < 40) { const d = q.shift(); try { const v = await this.day(d); if (v) got.push(d); } catch (e) { this.log('finra ' + d + ': ' + e.message); } } };
      await Promise.all([worker(), worker(), worker()]);
      got.sort().reverse();
      this.loaded = got.slice(0, 21); this.lastScan = Date.now();
      return this.loaded;
    })();
    try { return await this.busy; } finally { this.busy = null; }
  }
  async report(symbols) {
    const ds = await this.load();
    if (!ds.length) throw new Error('No FINRA files reachable');
    const days = ds.map((d) => ({ d, v: this.days.get(d) }));
    const fmtD = (d) => d.slice(0, 4) + '-' + d.slice(4, 6) + '-' + d.slice(6);
    const series = (sym) => days.map(({ d, v }) => { const x = v[sym]; return x ? { d: fmtD(d), r: x[0] / x[1], short: x[0], total: x[1] } : null; }).filter(Boolean).reverse(); // oldest -> newest
    const stats = (sym) => {
      const s = series(sym); if (!s.length) return null;
      const last = s[s.length - 1], prev = s.slice(0, -1);
      const avg = prev.length ? prev.reduce((a, x) => a + x.r, 0) / prev.length : last.r;
      const sd = prev.length > 2 ? Math.sqrt(prev.reduce((a, x) => a + (x.r - avg) * (x.r - avg), 0) / prev.length) : 0;
      const vAvg = prev.length ? prev.reduce((a, x) => a + x.total, 0) / prev.length : last.total;
      return { sym, date: last.d, ratio: last.r, avg, z: sd ? (last.r - avg) / sd : 0, total: last.total, short: last.short, volVsAvg: vAvg ? last.total / vAvg : 1, hist: s.map((x) => +x.r.toFixed(4)) };
    };
    // market gauge: volume-weighted short share across the 300 most traded names each day
    const market = days.map(({ d, v }) => { const top = Object.entries(v).sort((a, b) => b[1][1] - a[1][1]).slice(0, 300); let sh = 0, tt = 0; top.forEach(([, x]) => { sh += x[0]; tt += x[1]; }); return { d: fmtD(d), r: tt ? sh / tt : 0 }; }).reverse();
    const lastDay = days[0];
    const big = Object.entries(lastDay.v).filter(([s, x]) => x[1] >= 2e6 && /^[A-Z]{1,5}$/.test(s)).map(([s]) => s);
    const scored = big.map(stats).filter(Boolean);
    const mine = (symbols || []).map((s) => stats(s)).filter(Boolean);
    const mAvg = market.slice(0, -1).reduce((a, x) => a + x.r, 0) / Math.max(1, market.length - 1);
    return {
      date: fmtD(lastDay.d), days: market.length,
      market: { ratio: market[market.length - 1].r, avg: mAvg, hist: market.map((x) => +x.r.toFixed(4)), dates: market.map((x) => x.d) },
      tickers: mine,
      topBuying: scored.slice().sort((a, b) => b.z - a.z).slice(0, 12),
      topSelling: scored.slice().sort((a, b) => a.z - b.z).slice(0, 12),
      heaviest: scored.slice().sort((a, b) => b.volVsAvg - a.volVsAvg).slice(0, 12)
    };
  }
}

module.exports = { Finra };
