// Locked storage for broker keys and logins. In the desktop app, files are encrypted with the computer's own
// key store (Windows: DPAPI tied to your Windows account; Mac: Keychain), so a copied config file is useless on
// another computer or to another Windows user. Older plain files are read once and locked on the next save.
'use strict';
const fs = require('fs');

const TAG = 'XRV1:';
let ss = null;
try {
  const e = require('electron');
  if (e && e.safeStorage && typeof e.safeStorage.isEncryptionAvailable === 'function') ss = e.safeStorage;
} catch (err) { /* plain node (tests / browser edition): no OS key store */ }
const can = () => { try { return !!(ss && ss.isEncryptionAvailable()); } catch (e) { return false; } };

function readJSON(file) {
  let raw;
  try { raw = fs.readFileSync(file, 'utf8'); } catch (e) { return null; }
  if (raw.startsWith(TAG)) {
    if (!can()) return null;
    try { return JSON.parse(ss.decryptString(Buffer.from(raw.slice(TAG.length), 'base64'))); } catch (e) { return null; }   // another computer / user: start clean
  }
  try { return JSON.parse(raw); } catch (e) { return null; }
}

function writeJSON(file, obj) {
  const txt = JSON.stringify(obj, null, 2);
  const out = can() ? TAG + ss.encryptString(txt).toString('base64') : txt;
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, out, { mode: 0o600 });
  fs.renameSync(tmp, file);
}

// lock an older plain file in place (no change if it's already locked or can't be locked here)
function lock(file) {
  if (!can()) return;
  try { const raw = fs.readFileSync(file, 'utf8'); if (raw.startsWith(TAG)) return; const obj = JSON.parse(raw); writeJSON(file, obj); } catch (e) { /* missing or unreadable: leave it */ }
}

module.exports = { readJSON, writeJSON, lock, encrypted: can };
