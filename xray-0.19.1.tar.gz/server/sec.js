// Financial statements from SEC EDGAR (free, public, no key). Every US-listed company files its
// 10-K / 10-Q with XBRL tags; companyfacts gives every reported number. We turn that into
// income statement, balance sheet and cash flow tables (annual + quarterly) plus key ratios.
'use strict';
const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');

const DAY = 86400000;
// SEC asks every automated client to identify itself with a name and a contact email.
// TODO: add Delfi's support email here before shipping to customers.
const UA = process.env.SEC_UA || 'DELFAi X-ray/0.4.1 (Delfi Trading LLC)';

// concept fallbacks, first one a company actually reports wins
const C = {
  revenue: ['RevenueFromContractWithCustomerExcludingAssessedTax', 'Revenues', 'SalesRevenueNet', 'RevenueFromContractWithCustomerIncludingAssessedTax', 'RevenuesNetOfInterestExpense', 'SalesRevenueGoodsNet', 'Revenue'],
  cogs: ['CostOfRevenue', 'CostOfGoodsAndServicesSold', 'CostOfGoodsSold', 'CostOfSales'],
  gross: ['GrossProfit'],
  rnd: ['ResearchAndDevelopmentExpense', 'ResearchAndDevelopmentExpenseExcludingAcquiredInProcessCost'],
  sga: ['SellingGeneralAndAdministrativeExpense'],
  opinc: ['OperatingIncomeLoss', 'ProfitLossFromOperatingActivities'],
  pretax: ['IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest', 'IncomeLossFromContinuingOperationsBeforeIncomeTaxesMinorityInterestAndIncomeLossFromEquityMethodInvestments', 'ProfitLossBeforeTax'],
  tax: ['IncomeTaxExpenseBenefit', 'IncomeTaxExpenseContinuingOperations'],
  net: ['NetIncomeLoss', 'ProfitLossAttributableToOwnersOfParent', 'ProfitLoss', 'NetIncomeLossAvailableToCommonStockholdersBasic'],
  eps: ['EarningsPerShareDiluted', 'EarningsPerShareBasicAndDiluted', 'DilutedEarningsLossPerShare', 'EarningsPerShareBasic'],
  dilShares: ['WeightedAverageNumberOfDilutedSharesOutstanding', 'WeightedAverageNumberOfShareOutstandingBasicAndDiluted'],
  cash: ['CashAndCashEquivalentsAtCarryingValue', 'CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents', 'CashAndCashEquivalents', 'Cash'],
  stInv: ['ShortTermInvestments', 'MarketableSecuritiesCurrent', 'AvailableForSaleSecuritiesDebtSecuritiesCurrent'],
  curAssets: ['AssetsCurrent', 'CurrentAssets'],
  assets: ['Assets'],
  curLiab: ['LiabilitiesCurrent', 'CurrentLiabilities'],
  liab: ['Liabilities'],
  ltDebt: ['LongTermDebtNoncurrent', 'LongTermDebt', 'LongTermDebtAndCapitalLeaseObligations', 'NoncurrentBorrowings', 'ConvertibleNotesPayable', 'ConvertibleDebtNoncurrent', 'ConvertibleLongTermNotesPayable', 'LongTermNotesPayable', 'SeniorLongTermNotes', 'UnsecuredLongTermDebt'],
  stDebt: ['LongTermDebtCurrent', 'DebtCurrent', 'ShortTermBorrowings', 'CurrentBorrowings', 'ConvertibleNotesPayableCurrent', 'ConvertibleDebtCurrent', 'NotesPayableCurrent'],
  equity: ['StockholdersEquity', 'EquityAttributableToOwnersOfParent', 'StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest', 'Equity'],
  liabEq: ['LiabilitiesAndStockholdersEquity', 'EquityAndLiabilities'],
  ocf: ['NetCashProvidedByUsedInOperatingActivities', 'NetCashProvidedByUsedInOperatingActivitiesContinuingOperations', 'CashFlowsFromUsedInOperatingActivities'],
  capex: ['PaymentsToAcquirePropertyPlantAndEquipment', 'PaymentsToAcquireProductiveAssets', 'PurchaseOfPropertyPlantAndEquipmentClassifiedAsInvestingActivities'],
  icf: ['NetCashProvidedByUsedInInvestingActivities', 'NetCashProvidedByUsedInInvestingActivitiesContinuingOperations', 'CashFlowsFromUsedInInvestingActivities'],
  fcf: ['NetCashProvidedByUsedInFinancingActivities', 'NetCashProvidedByUsedInFinancingActivitiesContinuingOperations', 'CashFlowsFromUsedInFinancingActivities'],
  divPaid: ['PaymentsOfDividends', 'PaymentsOfDividendsCommonStock', 'DividendsPaidClassifiedAsFinancingActivities'],
  buyback: ['PaymentsForRepurchaseOfCommonStock'],
  sbc: ['ShareBasedCompensation', 'AllocatedShareBasedCompensationExpense'],
  dps: ['CommonStockDividendsPerShareDeclared', 'CommonStockDividendsPerShareCashPaid']
};
const SHARES_OUT = ['EntityCommonStockSharesOutstanding'];

const days = (a, b) => Math.round((Date.parse(b) - Date.parse(a)) / DAY);
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const endLabel = (e) => { const d = new Date(e + 'T12:00:00Z'); return MON[d.getUTCMonth()] + " '" + String(d.getUTCFullYear()).slice(2); };

// all facts for one concept, in the first unit that matches (USD, USD/shares, shares)
function factsOf(facts, names, unitPref) {
  for (const ns of ['us-gaap', 'ifrs-full', 'dei']) {
    const g = facts[ns]; if (!g) continue;
    for (const n of names) {
      const c = g[n]; if (!c || !c.units) continue;
      const unit = unitPref.find((u) => c.units[u]) || (unitPref.includes('USD') ? Object.keys(c.units).find((u) => /^[A-Z]{3}$/.test(u)) : null);
      if (!unit) continue;
      const arr = c.units[unit].filter((f) => /^(10-K|10-Q|20-F|40-F|10-KT|10-QT|6-K|8-K)(\/A)?$/.test(f.form || ''));
      if (arr.length) return { name: n, unit, arr };
    }
  }
  return null;
}

// period tables for a flow concept: annual + quarterly (quarters derived from year-to-date numbers)
function flowSeries(fc, additive) {
  if (additive === undefined) additive = true;
  const dur = new Map(); // start|end -> {val, filed, fy, fp, firstFiled}
  for (const f of fc.arr) {
    if (!f.start || !f.end || typeof f.val !== 'number') continue;
    const k = f.start + '|' + f.end; const o = dur.get(k);
    if (!o) dur.set(k, { start: f.start, end: f.end, val: f.val, filed: f.filed, fy: f.fy, fp: f.fp, firstFiled: f.filed });
    else {
      if (f.filed > o.filed) { o.val = f.val; o.filed = f.filed; }
      if (f.filed < o.firstFiled) { o.firstFiled = f.filed; o.fy = f.fy; o.fp = f.fp; }
    }
  }
  const all = Array.from(dur.values());
  const annual = {}, quarter = {};
  for (const d of all) { const n = days(d.start, d.end); if (n >= 350 && n <= 380) annual[d.end] = { val: d.val, fy: d.fy, start: d.start }; if (n >= 80 && n <= 100) quarter[d.end] = { val: d.val, fy: d.fy, fp: d.fp }; }
  // year-to-date differences: 6M - 3M, 9M - 6M, 12M - 9M (same start date)
  for (const d of all) {
    const n = days(d.start, d.end); if (n <= 100 || n > 380 || quarter[d.end]) continue;
    const prev = all.find((e) => e.start === d.start && e.end < d.end && days(e.end, d.end) >= 80 && days(e.end, d.end) <= 100);
    if (prev) quarter[d.end] = { val: additive ? d.val - prev.val : d.val, fy: d.fy, fp: n >= 350 ? 'Q4' : d.fp, derived: true };
  }
  // annual minus the three reported quarters
  for (const end of Object.keys(annual)) {
    if (quarter[end]) continue;
    const a = annual[end];
    const qs = Object.keys(quarter).filter((e) => e > a.start && e < end);
    if (qs.length === 3) quarter[end] = { val: additive ? a.val - qs.reduce((s, e) => s + quarter[e].val, 0) : a.val, fy: a.fy, fp: 'Q4', derived: true };
  }
  return { annual, quarter };
}
function instantSeries(fc) {
  const m = {};
  for (const f of fc.arr) { if (f.start || !f.end || typeof f.val !== 'number') continue; const o = m[f.end]; if (!o || f.filed > o.filed) m[f.end] = { val: f.val, filed: f.filed }; }
  return m;
}

function build(cf, ticker) {
  const facts = cf.facts || {};
  const S = {}; const used = {};
  const flowKeys = ['revenue', 'cogs', 'gross', 'rnd', 'sga', 'opinc', 'pretax', 'tax', 'net', 'eps', 'dilShares', 'ocf', 'capex', 'icf', 'fcf', 'divPaid', 'buyback', 'sbc', 'dps'];
  const instKeys = ['cash', 'stInv', 'curAssets', 'assets', 'curLiab', 'liab', 'ltDebt', 'stDebt', 'equity', 'liabEq'];
  for (const k of flowKeys) {
    const unit = k === 'eps' || k === 'dps' ? ['USD/shares'] : k === 'dilShares' ? ['shares'] : ['USD'];
    const fc = factsOf(facts, C[k], unit); if (!fc) continue; used[k] = fc.name; S[k] = flowSeries(fc, k !== 'dilShares');
  }
  // debt: companies switch tags over the years (e.g. term loans -> convertible notes), so use the one with the newest balance
  const latestEnd = (fc) => fc.arr.reduce((m, x) => (!x.start && x.end > m ? x.end : m), '');
  const freshest = (names) => { let best = null; for (const n of names) { const fc = factsOf(facts, [n], ['USD']); if (fc && (!best || latestEnd(fc) > latestEnd(best))) best = fc; } return best; };
  for (const k of instKeys) { const fc = k === 'ltDebt' || k === 'stDebt' ? freshest(C[k]) : factsOf(facts, C[k], ['USD']); if (!fc) continue; used[k] = fc.name; S[k] = instantSeries(fc); }
  const so = factsOf(facts, SHARES_OUT, ['shares']);
  let sharesOut = null;
  if (so) { const last = so.arr.slice().sort((a, b) => (a.end < b.end ? 1 : -1))[0]; sharesOut = last ? { val: last.val, asOf: last.end } : null; }

  // column dates: the periods where the company reported revenue or net income
  const anchor = (per) => { const set = new Set(); ['revenue', 'net', 'ocf'].forEach((k) => { if (S[k]) Object.keys(S[k][per]).forEach((e) => set.add(e)); }); return Array.from(set).sort(); };
  const cutoff = new Date(Date.now() - 12 * 365 * DAY).toISOString().slice(0, 10);
  const annualEnds = anchor('annual').filter((e) => e > cutoff).slice(-6);
  const quarterEnds = anchor('quarter').filter((e) => e > cutoff).slice(-10);

  const flowVal = (k, per, e) => (S[k] && S[k][per][e] ? S[k][per][e].val : null);
  const instVal = (k, e) => (S[k] && S[k][e] ? S[k][e].val : null);
  const make = (per, ends) => {
    const cols = ends.map((e) => {
      const ref = (S.net && S.net[per][e]) || (S.revenue && S.revenue[per][e]) || (S.ocf && S.ocf[per][e]) || {};
      const fy = ref.fy;
      const label = per === 'annual' ? 'FY' + (fy || e.slice(0, 4)) : (ref.fp && /^Q\d$/.test(ref.fp) ? ref.fp : 'Q') + ' ' + (fy ? "'" + String(fy).slice(2) : '');
      return { end: e, label: label.trim(), sub: endLabel(e), derived: !!ref.derived };
    });
    const row = (label, k, kind, opt) => ({ label, key: k, kind: kind || 'usd', bold: !!(opt && opt.bold), vals: ends.map((e) => (opt && opt.fn ? opt.fn(e) : instKeys.includes(k) ? instVal(k, e) : flowVal(k, per, e))) });
    const rev = (e) => flowVal('revenue', per, e);
    const gross = (e) => { const g = flowVal('gross', per, e); if (g != null) return g; const r = rev(e), c = flowVal('cogs', per, e); return r != null && c != null ? r - c : null; };
    const pct = (a, b) => (a != null && b ? (a / b) * 100 : null);
    const income = [
      row('Revenue', 'revenue', 'usd', { bold: true }),
      row('Cost of revenue', 'cogs'),
      row('Gross profit', 'gross', 'usd', { fn: gross, bold: true }),
      row('Gross margin', 'gm', 'pct', { fn: (e) => pct(gross(e), rev(e)) }),
      row('R&D', 'rnd'),
      row('SG&A', 'sga'),
      row('Operating income', 'opinc', 'usd', { bold: true }),
      row('Operating margin', 'om', 'pct', { fn: (e) => pct(flowVal('opinc', per, e), rev(e)) }),
      row('Pre-tax income', 'pretax'),
      row('Income tax', 'tax'),
      row('Net income', 'net', 'usd', { bold: true }),
      row('Net margin', 'nm', 'pct', { fn: (e) => pct(flowVal('net', per, e), rev(e)) }),
      row('EPS (diluted)', 'eps', 'eps'),
      row('Diluted shares', 'dilShares', 'num')
    ];
    const totalLiab = (e) => { const l = instVal('liab', e); if (l != null) return l; const le = instVal('liabEq', e), q = instVal('equity', e); return le != null && q != null ? le - q : null; };
    const balance = [
      row('Cash & equivalents', 'cash', 'usd', { bold: true }),
      row('Short-term investments', 'stInv'),
      row('Total current assets', 'curAssets'),
      row('Total assets', 'assets', 'usd', { bold: true }),
      row('Total current liabilities', 'curLiab'),
      row('Short-term debt', 'stDebt'),
      row('Long-term debt', 'ltDebt'),
      row('Total liabilities', 'liab', 'usd', { fn: totalLiab, bold: true }),
      row("Shareholders' equity", 'equity', 'usd', { bold: true }),
      row('Current ratio', 'cr', 'x', { fn: (e) => { const a = instVal('curAssets', e), l = instVal('curLiab', e); return a != null && l ? a / l : null; } }),
      row('Debt / equity', 'de', 'x', { fn: (e) => { const d = (instVal('ltDebt', e) || 0) + (instVal('stDebt', e) || 0), q = instVal('equity', e); return q && (instVal('ltDebt', e) != null || instVal('stDebt', e) != null) ? d / q : null; } })
    ];
    const fcfv = (e) => { const o = flowVal('ocf', per, e), c = flowVal('capex', per, e); return o != null ? o - (c || 0) : null; };
    const cash = [
      row('Operating cash flow', 'ocf', 'usd', { bold: true }),
      row('Capital expenditures', 'capex', 'usd', { fn: (e) => { const c = flowVal('capex', per, e); return c != null ? -Math.abs(c) : null; } }),
      row('Free cash flow', 'freecf', 'usd', { fn: fcfv, bold: true }),
      row('Investing cash flow', 'icf'),
      row('Financing cash flow', 'fcf'),
      row('Dividends paid', 'divPaid', 'usd', { fn: (e) => { const c = flowVal('divPaid', per, e); return c != null ? -Math.abs(c) : null; } }),
      row('Stock buybacks', 'buyback', 'usd', { fn: (e) => { const c = flowVal('buyback', per, e); return c != null ? -Math.abs(c) : null; } }),
      row('Stock-based comp', 'sbc')
    ];
    const keep = (rows) => rows.filter((r) => r.vals.some((v) => v != null));
    return { cols, income: keep(income), balance: keep(balance), cash: keep(cash) };
  };

  // trailing twelve months from the last 4 quarters
  const ttm = (k) => { if (!S[k]) return null; const qs = Object.keys(S[k].quarter).sort().slice(-4); if (qs.length < 4 || days(qs[0], qs[3]) > 300) return null; return qs.reduce((s, e) => s + S[k].quarter[e].val, 0); };
  const lastInst = (k) => { if (!S[k]) return null; const e = Object.keys(S[k]).sort().pop(); return e ? S[k][e].val : null; };
  const rv = ttm('revenue'), ni = ttm('net'), ocfT = ttm('ocf'), cap = ttm('capex');
  let revGrowth = null;
  if (S.revenue) { const qs = Object.keys(S.revenue.quarter).sort(); if (qs.length >= 8) { const a = qs.slice(-4).reduce((s, e) => s + S.revenue.quarter[e].val, 0), b = qs.slice(-8, -4).reduce((s, e) => s + S.revenue.quarter[e].val, 0); if (b && days(qs[qs.length - 8], qs[qs.length - 1]) < 760) revGrowth = (a / b - 1) * 100; } }
  const lastAnnualDps = S.dps ? Object.keys(S.dps.annual).sort().pop() : null;
  const dpsHist = S.dps ? Object.keys(S.dps.annual).sort().slice(-6).map((e) => ({ end: e, label: 'FY' + (S.dps.annual[e].fy || e.slice(0, 4)), val: S.dps.annual[e].val })) : [];
  return {
    ticker, name: cf.entityName || ticker, cik: cf.cik, source: 'SEC EDGAR',
    sharesOut,
    ttm: {
      revenue: rv, netIncome: ni, eps: ttm('eps'), fcf: ocfT != null ? ocfT - Math.abs(cap || 0) : null,
      grossMargin: rv && ttm('gross') != null ? ttm('gross') / rv * 100 : null,
      netMargin: rv && ni != null ? ni / rv * 100 : null,
      revGrowth,
      dps: ttm('dps') != null ? ttm('dps') : (lastAnnualDps ? S.dps.annual[lastAnnualDps].val : null)
    },
    latest: { cash: lastInst('cash'), debt: (lastInst('ltDebt') || 0) + (lastInst('stDebt') || 0), equity: lastInst('equity'), assets: lastInst('assets') },
    dpsHist,
    annual: make('annual', annualEnds),
    quarterly: make('quarter', quarterEnds),
    concepts: used
  };
}

class SecData {
  constructor(opts) {
    opts = opts || {};
    this.dir = opts.cacheDir; if (this.dir) fs.mkdirSync(this.dir, { recursive: true });
    this.wwwHost = opts.wwwHost || 'www.sec.gov';
    this.dataHost = opts.dataHost || 'data.sec.gov';
    this.protocol = opts.protocol || 'https';
    this.log = opts.log || (() => {});
    this.map = null; this.mapAt = 0; this.mem = new Map(); this.inflight = new Map();
    this.lastStart = 0;
  }
  fetchJson(host, p) {
    // SEC allows 10 requests a second; we stay well under it
    const wait = Math.max(0, this.lastStart + 150 - Date.now()); this.lastStart = Date.now() + wait;
    return new Promise((resolve, reject) => setTimeout(() => {
      const [h, port] = host.split(':');
      const lib = this.protocol === 'http' ? http : https;
      const req = lib.request({ host: h, port: port ? Number(port) : undefined, path: p, method: 'GET', headers: { 'User-Agent': UA, Accept: 'application/json', 'Accept-Encoding': 'identity' }, timeout: 20000 }, (res) => {
        const chunks = []; res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const body = Buffer.concat(chunks).toString('utf8');
          if (res.statusCode === 404) { const e = new Error('not found'); e.status = 404; return reject(e); }
          if (res.statusCode !== 200) { const e = new Error('SEC returned HTTP ' + res.statusCode); e.status = res.statusCode; return reject(e); }
          try { resolve(JSON.parse(body)); } catch (e) { reject(new Error('SEC sent something unreadable')); }
        });
      });
      req.on('timeout', () => req.destroy(new Error('SEC request timed out')));
      req.on('error', reject); req.end();
    }, wait));
  }
  cacheRead(name, maxAge) {
    if (!this.dir) return null;
    try { const f = path.join(this.dir, name); const st = fs.statSync(f); if (Date.now() - st.mtimeMs > maxAge) return null; return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return null; }
  }
  cacheWrite(name, obj) { if (!this.dir) return; try { fs.writeFileSync(path.join(this.dir, name), JSON.stringify(obj)); } catch (e) { /* cache is optional */ } }

  async tickerMap() {
    if (this.map && Date.now() - this.mapAt < 7 * DAY) return this.map;
    let raw = this.cacheRead('sec-tickers.json', 7 * DAY);
    if (!raw) { raw = await this.fetchJson(this.wwwHost, '/files/company_tickers.json'); this.cacheWrite('sec-tickers.json', raw); }
    const m = {}; Object.values(raw).forEach((r) => { const t = String(r.ticker).toUpperCase().replace(/[-.]/g, '.'); if (!m[t]) m[t] = { cik: r.cik_str, title: r.title }; });
    this.map = m; this.mapAt = Date.now(); return m;
  }

  async financials(sym) {
    sym = String(sym || '').toUpperCase().trim();
    if (!/^[A-Z][A-Z.]{0,6}$/.test(sym)) { const e = new Error('Not a stock ticker'); e.status = 400; throw e; }
    const hit = this.mem.get(sym); if (hit && Date.now() - hit.t < 6 * 3600000) return hit.v;
    if (this.inflight.has(sym)) return this.inflight.get(sym);
    const job = (async () => {
      const m = await this.tickerMap();
      const ent = m[sym] || m[sym.replace(/\./g, '-')] || m[sym.replace(/-/g, '.')];
      if (!ent) { const e = new Error(sym + ' does not file reports with the SEC (ETFs, funds and many foreign or OTC stocks don\'t).'); e.status = 404; e.code = 'NO_FILINGS'; throw e; }
      const cik = String(ent.cik).padStart(10, '0');
      let cf = this.cacheRead('sec-' + cik + '.json', 12 * 3600000);
      if (!cf) {
        cf = await this.fetchJson(this.dataHost, '/api/xbrl/companyfacts/CIK' + cik + '.json');
        // keep only the concepts we use, so the cache stays small
        const want = new Set([].concat(...Object.values(C), SHARES_OUT));
        const slim = { cik: cf.cik, entityName: cf.entityName, facts: {} };
        for (const ns of Object.keys(cf.facts || {})) { for (const k of Object.keys(cf.facts[ns])) if (want.has(k)) { slim.facts[ns] = slim.facts[ns] || {}; slim.facts[ns][k] = cf.facts[ns][k]; } }
        cf = slim; this.cacheWrite('sec-' + cik + '.json', cf);
      }
      const out = build(cf, sym);
      if (!out.annual.cols.length && !out.quarterly.cols.length) { const e = new Error('No financial statements found in ' + sym + "'s SEC filings."); e.status = 404; e.code = 'NO_FILINGS'; throw e; }
      this.mem.set(sym, { t: Date.now(), v: out });
      return out;
    })();
    this.inflight.set(sym, job);
    try { return await job; } finally { this.inflight.delete(sym); }
  }
}

module.exports = { SecData, build, flowSeries };
