// VIP access: "Sign in with Discord" through VENOM OS, which checks the member's VIP role in the Delfi server.
// The answer is re-checked every few hours. If VENOM can't be reached, the last good answer is kept for 3 days
// so a network blip never locks a paying member out.
'use strict';
const crypto = require('crypto');
const os = require('os');

// this computer's id: built from the machine itself, so a copied X-ray folder or config on another computer
// gets a different id and VENOM refuses the session (one license, limited computers)
const DEVICE = (() => {
  let cpu = ''; try { cpu = (os.cpus()[0] || {}).model || ''; } catch (e) { /* fine */ }
  let user = ''; try { user = os.userInfo().username; } catch (e) { /* fine */ }
  const parts = ['delfai-xray-device-v1', os.hostname(), user, os.platform(), os.arch(), cpu, Math.round(os.totalmem() / 2 ** 30)];
  return crypto.createHash('sha256').update(parts.join('|')).digest('hex');
})();

const VENOM = (process.env.XRAY_VENOM_BASE || 'https://venom-os.delfi-venom-os.workers.dev').replace(/\/$/, '');
const KEY = 'xr-delfai-7f3c9b1e';
const GRACE = 3 * 864e5;          // keep VIP for 3 days while offline
const RECHECK = 3 * 3600e3;       // re-check every 3 hours

class Vip {
  constructor({ getCfg, saveCfg, log }) {
    this.getCfg = getCfg; this.saveCfg = saveCfg; this.log = log;
    this.nonce = null; this.busy = null;
    this.timer = setInterval(() => { if (this.cur().session) this.refresh().catch(() => {}); }, RECHECK);
    if (this.timer.unref) this.timer.unref();
    setTimeout(() => { if (this.cur().session) this.refresh().catch(() => {}); else this.info().catch(() => {}); }, 3000);
  }
  cur() { return this.getCfg().vip || {}; }
  save(v) { this.getCfg().vip = v; this.saveCfg(); }

  /** What the app shows: vip only counts while the last good check is fresh enough. */
  status() {
    const v = this.cur();
    const fresh = v.checkedOk && Date.now() - v.checkedOk < GRACE;
    return {
      signedIn: !!v.session, vip: !!(v.session && v.vip && fresh), xray: !!(v.session && v.xray && fresh), staff: !!v.staff, inServer: v.inServer !== false,
      user: v.user || null, roles: v.roles || [], checkoutUrl: v.checkoutUrl || null,
      checked: v.checkedOk || null, offline: !!v.offline, error: v.error || null, busy: !!this.busy,
    };
  }

  // the Get VIP link, so it shows before anyone signs in
  async info() {
    const r = await fetch(VENOM + '/xray/info', { signal: AbortSignal.timeout(10000) });
    const j = await r.json();
    if (j && j.checkoutUrl && j.checkoutUrl !== this.cur().checkoutUrl) this.save(Object.assign({}, this.cur(), { checkoutUrl: j.checkoutUrl }));
  }

  loginUrl(port) {
    this.nonce = crypto.randomBytes(16).toString('hex');
    return `${VENOM}/xray/login?port=${port}&nonce=${this.nonce}&dev=${DEVICE}`;
  }

  async callback(session, nonce) {
    if (!this.nonce || nonce !== this.nonce || !/^[a-f0-9]{48}$/.test(String(session))) throw new Error('This sign-in link is not valid anymore. Go back to X-ray and try again.');
    this.nonce = null;
    this.save(Object.assign({}, this.cur(), { session, vip: false, checkedOk: 0 }));
    await this.refresh();
    return this.status();
  }

  async post(path, body) {
    const r = await fetch(VENOM + path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Xray-Key': KEY }, body: JSON.stringify(Object.assign({ device: DEVICE }, body)), signal: AbortSignal.timeout(15000) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || 'VENOM answered ' + r.status);
    return j;
  }

  refresh() {
    if (this.busy) return this.busy;
    const v = this.cur();
    if (!v.session) return Promise.resolve(this.status());
    this.busy = this.post('/xray/status', { session: v.session }).then((j) => {
      if (!j.signedIn) { this.save({ checkoutUrl: j.checkoutUrl || v.checkoutUrl }); this.log('vip: session ended, signed out'); return; }
      this.save({ session: v.session, vip: !!j.vip, xray: !!j.xray, staff: !!j.staff, inServer: j.inServer !== false, roles: j.roles || [], user: j.user || null, checkoutUrl: j.checkoutUrl || null, checkedOk: Date.now(), offline: false, error: null });
      this.log('vip: ' + (j.user ? j.user.username : '?') + ' is ' + (j.vip ? 'VIP' : 'not VIP'));
    }).catch((e) => {
      this.save(Object.assign({}, this.cur(), { offline: true, error: e.message }));
      this.log('vip: check failed (' + e.message + '), keeping last answer');
    }).then(() => { this.busy = null; return this.status(); });
    return this.busy;
  }

  /** The box for one contract. The rules live on VENOM OS only; this just sends the candles and passes the answer back. */
  async box(occ, days, shortGamma) {
    const v = this.cur();
    if (!v.session) return { locked: 'signin' };
    const slim = (days || []).slice(-400).map((d) => ({ t: d.t, day: d.day, o: d.o, h: d.h, l: d.l, c: d.c, v: d.v || 0 }));
    try {
      const j = await this.post('/xray/box', { session: v.session, occ, days: slim, shortGamma: shortGamma === true ? true : shortGamma === false ? false : undefined });
      return { box: j.box || null };
    } catch (e) {
      if (e.message === 'no-xray') return { locked: 'xray' };
      if (e.message === 'signed-out') { this.refresh().catch(() => {}); return { locked: 'signin' }; }
      if (e.message === 'slow-down') return { error: 'slow' };
      return { error: 'offline' };
    }
  }

  async logout() {
    const v = this.cur();
    if (v.session) this.post('/xray/logout', { session: v.session }).catch(() => {});
    this.save({ checkoutUrl: v.checkoutUrl || null });
    return this.status();
  }
}

const donePage = (ok, msg) => `<!doctype html><meta charset="utf-8"><title>DELFAi X-ray</title>
<body style="margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#05080d;color:#e8eef2;font:15px system-ui,sans-serif">
<div style="max-width:420px;padding:28px;border:1px solid #2c4a63;border-radius:14px;background:#0e131b;text-align:center">
<div style="font:600 12px monospace;letter-spacing:.16em;color:#8fd2ec">DELFAi X-RAY</div>
<h1 style="font-size:22px;margin:10px 0">${ok ? 'You’re signed in' : 'Sign-in didn’t work'}</h1>
<p style="color:#9aa8b4;line-height:1.5">${msg}</p></div></body>`;

module.exports = { Vip, donePage, VENOM, DEVICE };
