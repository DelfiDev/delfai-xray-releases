// Economic data from FRED (Federal Reserve Bank of St. Louis), public CSV downloads, no key needed.
// Cached on disk so the Economic Indicators page opens instantly and FRED is asked at most every few hours.
'use strict';
const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');

// every series the Economic Indicators page uses
const IDS = [
  // economy (monthly or quarterly)
  'GDP', 'GDPC1', 'NGDPPOT', 'A939RX0Q048SBEA', 'FEDFUNDS', 'CPIAUCSL', 'PCEPILFE', 'RSAFS', 'UMCSENT', 'DGORDER', 'UNRATE', 'PAYEMS', 'ICSA',
  'INDPRO', 'HOUST', 'TOTALSA', 'RMFSL', 'RECPROUSM156N', 'IR3TCD01USM156N', 'TERMCBCCALLNS', 'MORTGAGE30US', 'MORTGAGE15US',
  // treasury curve (daily)
  'DGS1MO', 'DGS3MO', 'DGS6MO', 'DGS1', 'DGS2', 'DGS3', 'DGS5', 'DGS7', 'DGS10', 'DGS20', 'DGS30',
  // volatility + markets (daily)
  'VIXCLS', 'DTWEXBGS', 'DCOILWTICO', 'BAMLH0A0HYM2',
  // liquidity
  'WALCL', 'RRPONTSYD', 'WTREGEN'
];

class Fred {
  constructor(o) {
    this.dir = o.cacheDir; this.log = o.log || (() => {});
    this.base = process.env.FRED_URL || 'https://fred.stlouisfed.org/graph/fredgraph.csv?id=';
    fs.mkdirSync(this.dir, { recursive: true });
    this.mem = null; this.busy = null;
  }
  get(url) {
    return new Promise((resolve, reject) => {
      const lib = url.startsWith('http:') ? http : https;
      const rq = lib.get(url, { headers: { 'User-Agent': 'Mozilla/5.0 (compatible; DELFAi-Xray/0.10; +https://delfitrading.com)', Accept: 'text/csv,text/plain,*/*' }, timeout: 15000 }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) { res.resume(); return resolve(this.get(new URL(res.headers.location, url).toString())); }
        if (res.statusCode !== 200) { res.resume(); return reject(new Error('FRED answered ' + res.statusCode)); }
        let d = ''; res.setEncoding('utf8'); res.on('data', (c) => { d += c; }); res.on('end', () => resolve(d));
      });
      rq.on('timeout', () => rq.destroy(new Error('FRED took too long')));
      rq.on('error', (e) => reject(new Error(e.code === 'ENOTFOUND' ? 'no internet / FRED not reachable' : e.message)));
    });
  }
  // "observation_date,ID\n2024-01-01,3.2\n..." -> [[ms, value], ...]
  parse(csv) {
    const out = [];
    if (!/^\s*(observation_date|DATE)/i.test(csv)) return out; // an error page, not data
    csv.split(/\r?\n/).slice(1).forEach((ln) => {
      const [d, v] = ln.split(',');
      const t = Date.parse(d + 'T00:00:00Z'); const x = Number(v);
      if (Number.isFinite(t) && v !== '.' && v !== '' && Number.isFinite(x)) out.push([t, x]);
    });
    return out;
  }
  file(id) { return path.join(this.dir, id + '.json'); }
  disk(id) { try { return JSON.parse(fs.readFileSync(this.file(id), 'utf8')); } catch (e) { return null; } }
  async fetchOne(id) {
    // only ask for the years the page shows: much smaller downloads
    const daily = /^(DGS|VIXCLS|DTWEX|DCOIL|BAML|RRPONTSYD)/.test(id);
    const from = daily ? new Date(Date.now() - 2 * 365 * 86400000).toISOString().slice(0, 10) : '1989-01-01';
    const url = this.base + encodeURIComponent(id) + (this.base.includes('fredgraph') ? '&cosd=' + from : '');
    let lastErr;
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const v = this.parse(await this.get(url));
        if (!v.length) throw new Error('FRED sent no data');
        fs.writeFileSync(this.file(id), JSON.stringify({ t: Date.now(), v }));
        return v;
      } catch (e) { lastErr = e; }
    }
    throw lastErr;
  }
  // refresh anything older than 4 hours, six at a time, in the background
  refresh() {
    if (this.busy) return this.busy;
    const stale = IDS.filter((id) => { const d = this.disk(id); return !d || Date.now() - d.t > 4 * 3600000; });
    if (!stale.length) { this.lastRun = Date.now(); return Promise.resolve(); }
    this.errors = {};
    const q = stale.slice();
    const worker = async () => { while (q.length) { const id = q.shift(); try { await this.fetchOne(id); } catch (e) { this.errors[id] = e.message; this.log('fred ' + id + ': ' + e.message); } } };
    this.busy = Promise.all([worker(), worker(), worker(), worker(), worker(), worker()]).then(() => { this.busy = null; this.lastRun = Date.now(); });
    return this.busy;
  }
  // whatever is on disk right now (instantly), plus whether more is still coming
  snapshot() {
    if (!this.busy && (!this.lastRun || Date.now() - this.lastRun > (Object.keys(this.errors || {}).length ? 60000 : 15 * 60000))) this.refresh();
    const series = {};
    IDS.forEach((id) => { const d = this.disk(id); if (d && d.v && d.v.length) series[id] = d.v; });
    return { t: Date.now(), series, pending: !!this.busy, errors: this.errors || {}, have: Object.keys(series).length, total: IDS.length };
  }
}

module.exports = { Fred, IDS };
