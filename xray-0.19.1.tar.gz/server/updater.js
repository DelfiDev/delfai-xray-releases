// Auto-updater: checks the public releases repo for a newer X-ray, downloads it in the background,
// checks the SHA-256 and the Ed25519 signature, unpacks it into ~/.delfai-xray/versions/<version>,
// and tells the app it's ready. The starter (main.js) runs the newest healthy version on the next launch.
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');

const MANIFEST_URL = process.env.XRAY_UPDATE_URL || 'https://raw.githubusercontent.com/DelfiDev/delfai-xray-releases/main/latest.json';
// only updates signed with Delfi's private key are ever installed
const PUBLIC_KEY = process.env.XRAY_UPDATE_PUBKEY || '-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAHsk5bWoFbOsxz/ao5DkekWASB1R1dcjJ9DNmynHIDEw=\n-----END PUBLIC KEY-----\n';
const FIRST_CHECK = 20e3, EVERY = 4 * 3600e3;

const cmp = (a, b) => {
  const pa = String(a).split('.').map((x) => parseInt(x, 10) || 0), pb = String(b).split('.').map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < 3; i++) { if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0) ? 1 : -1; }
  return 0;
};
const signedText = (m) => [m.version, m.file, m.sha256, m.size].join('\n');

// minimal .tar.gz reader: regular files and folders only, nothing outside the target folder
function untarGz(buf, dest) {
  const tar = zlib.gunzipSync(buf);
  let off = 0, longName = null;
  while (off + 512 <= tar.length) {
    const h = tar.subarray(off, off + 512);
    if (h.every((b) => b === 0)) break;
    const str = (a, n) => h.subarray(a, a + n).toString('utf8').replace(/\0.*$/s, '');
    let name = str(0, 100); const prefix = str(345, 155); if (prefix) name = prefix + '/' + name;
    const size = parseInt(str(124, 12).trim() || '0', 8), type = String.fromCharCode(h[156] || 48);
    const body = tar.subarray(off + 512, off + 512 + size);
    off += 512 + Math.ceil(size / 512) * 512;
    if (type === 'L') { longName = body.toString('utf8').replace(/\0.*$/s, ''); continue; }
    if (longName) { name = longName; longName = null; }
    if (type === 'x' || type === 'g') continue;   // pax headers
    const rel = name.replace(/^\.\//, '').replace(/\/$/, '');
    if (!rel || rel === '.') continue;   // the archive's own top folder
    if (rel.split(/[\\/]/).includes('..') || path.isAbsolute(rel)) throw new Error('Bad path in update: ' + name);
    const out = path.join(dest, rel);
    if (type === '5') { fs.mkdirSync(out, { recursive: true }); continue; }
    if (type !== '0' && type !== '\0') continue;   // no links, devices, etc.
    fs.mkdirSync(path.dirname(out), { recursive: true });
    fs.writeFileSync(out, body);
  }
}

class Updater {
  constructor({ dataDir, current, log, onRestart }) {
    this.dir = path.join(dataDir, 'versions');
    this.current = current; this.log = log || (() => {}); this.onRestart = onRestart || null;
    this.st = { current, latest: null, ready: null, notes: '', checking: false, error: null, checked: null, downloading: false };
    if (!process.env.XRAY_NO_UPDATE) {
      this.t1 = setTimeout(() => this.check().catch(() => {}), FIRST_CHECK); if (this.t1.unref) this.t1.unref();
      this.t2 = setInterval(() => this.check().catch(() => {}), EVERY); if (this.t2.unref) this.t2.unref();
    }
    // a version that's already downloaded and newer than the running one is "ready"
    try {
      fs.readdirSync(this.dir).forEach((v) => {
        if (cmp(v, current) > 0 && fs.existsSync(path.join(this.dir, v, '.complete')) && !fs.existsSync(path.join(this.dir, v, '.bad'))) {
          if (!this.st.ready || cmp(v, this.st.ready) > 0) this.st.ready = v;
        }
      });
    } catch (e) { /* no versions folder yet */ }
  }
  status() { return Object.assign({}, this.st, { canRestart: !!this.onRestart }); }

  async check() {
    if (this.st.checking) return this.status();
    this.st.checking = true; this.st.error = null;
    try {
      const r = await fetch(MANIFEST_URL + '?t=' + Date.now(), { signal: AbortSignal.timeout(15000), cache: 'no-store' });
      if (!r.ok) throw new Error('Update server answered ' + r.status);
      const m = await r.json();
      if (!m || !m.version || !m.file || !m.sha256 || !m.sig) throw new Error('Update info is incomplete');
      const ok = crypto.verify(null, Buffer.from(signedText(m)), PUBLIC_KEY, Buffer.from(String(m.sig), 'base64'));
      if (!ok) throw new Error('Update signature is not valid, ignoring it');
      this.st.latest = m.version; this.st.notes = String(m.notes || '').slice(0, 600); this.st.checked = Date.now();
      if (cmp(m.version, this.current) > 0 && this.st.ready !== m.version) await this.download(m);
    } catch (e) {
      this.st.error = e.message; this.log('update: ' + e.message);
    } finally { this.st.checking = false; }
    return this.status();
  }

  async download(m) {
    if (!/^[\w.-]+\.tar\.gz$/.test(m.file) || !/^\d+\.\d+\.\d+$/.test(m.version)) throw new Error('Update file name is not allowed');
    this.st.downloading = true;
    try {
      const url = new URL(m.file, MANIFEST_URL).toString();
      const r = await fetch(url, { signal: AbortSignal.timeout(120000) });
      if (!r.ok) throw new Error('Download failed (' + r.status + ')');
      const buf = Buffer.from(await r.arrayBuffer());
      if (m.size && buf.length !== Number(m.size)) throw new Error('Download size does not match');
      const sha = crypto.createHash('sha256').update(buf).digest('hex');
      if (sha !== String(m.sha256).toLowerCase()) throw new Error('Download is damaged (checksum mismatch)');
      const final = path.join(this.dir, m.version), tmp = final + '.tmp';
      fs.rmSync(tmp, { recursive: true, force: true }); fs.mkdirSync(tmp, { recursive: true });
      untarGz(buf, tmp);
      if (!fs.existsSync(path.join(tmp, 'app-main.js')) || !fs.existsSync(path.join(tmp, 'ui', 'index.html'))) throw new Error('Update is missing files');
      fs.writeFileSync(path.join(tmp, '.complete'), new Date().toISOString());
      fs.rmSync(final, { recursive: true, force: true }); fs.renameSync(tmp, final);
      this.st.ready = m.version; this.log('update: v' + m.version + ' downloaded and verified, ready on restart');
      this.prune();
    } finally { this.st.downloading = false; }
  }

  // keep the running version, the ready one, and one older as a fallback
  prune() {
    try {
      const keep = new Set([this.current, this.st.ready].filter(Boolean));
      const all = fs.readdirSync(this.dir).filter((v) => /^\d+\.\d+\.\d+$/.test(v)).sort((a, b) => cmp(b, a));
      let older = 0;
      all.forEach((v) => { if (keep.has(v)) return; if (cmp(v, this.current) < 0 && older++ < 1) return; fs.rmSync(path.join(this.dir, v), { recursive: true, force: true }); });
    } catch (e) { /* fine */ }
  }

  restart() { if (this.onRestart) { setTimeout(() => this.onRestart(), 300); return true; } return false; }
}

module.exports = { Updater, cmp, signedText, untarGz };
