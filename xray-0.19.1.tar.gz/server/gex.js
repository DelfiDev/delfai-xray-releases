// Real dealer-gamma model from an options chain (OI + IV per contract).
// Convention: dealers long calls / short puts (call GEX +, put GEX −), $ gamma per 1% move.
'use strict';

const npdf = (x) => Math.exp(-x * x / 2) / 2.5066282746310002;
const ncdf = (x) => {
  const t = 1 / (1 + 0.2316419 * Math.abs(x));
  const d = 0.3989422804014327 * Math.exp(-x * x / 2);
  const p = d * t * (0.319381530 + t * (-0.356563782 + t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))));
  return x > 0 ? 1 - p : p;
};
const R = 0.04;

function greeks(S, K, T, iv, type) {
  const sq = Math.sqrt(T);
  const d1 = (Math.log(S / K) + (R + iv * iv / 2) * T) / (iv * sq);
  const d2 = d1 - iv * sq;
  const nd = npdf(d1);
  const gamma = nd / (S * iv * sq);
  const delta = type === 'C' ? ncdf(d1) : ncdf(d1) - 1;
  const vanna = -nd * d2 / iv;
  const charmC = -nd * (2 * R * T - d2 * iv * sq) / (2 * T * iv * sq);
  return { gamma, delta, vanna, charm: charmC / 365, d1, d2 };
}

function bsPrice(S, K, T, iv, type) {
  const sq = Math.sqrt(T);
  const d1 = (Math.log(S / K) + (R + iv * iv / 2) * T) / (iv * sq), d2 = d1 - iv * sq;
  const disc = Math.exp(-R * T);
  return type === 'C' ? S * ncdf(d1) - K * disc * ncdf(d2) : K * disc * ncdf(-d2) - S * ncdf(-d1);
}

// implied vol from a price (bisection), used when the feed has no IV
function impliedVol(price, S, K, T, type) {
  if (!(price > 0) || !(S > 0) || !(T > 0)) return null;
  const intrinsic = type === 'C' ? Math.max(0, S - K) : Math.max(0, K - S);
  if (price <= intrinsic + 1e-4) return 0.05;
  let lo = 0.01, hi = 5;
  for (let i = 0; i < 60; i++) {
    const mid = (lo + hi) / 2;
    if (bsPrice(S, K, T, mid, type) > price) hi = mid; else lo = mid;
  }
  return (lo + hi) / 2;
}

// Years until 4:00pm New York time on the expiry date.
function yearsToExpiry(expDate, now) {
  const [y, m, d] = expDate.split('-').map(Number);
  // 16:00 ET ~ 20:00 UTC (EDT) or 21:00 UTC (EST); use the right offset for the date.
  const probe = new Date(Date.UTC(y, m - 1, d, 12));
  const nyHour = Number(new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', hour: 'numeric', hour12: false }).format(probe));
  const offset = 12 - nyHour; // hours behind UTC
  const close = Date.UTC(y, m - 1, d, 16 + offset, 0);
  const ms = close - (now || Date.now());
  return Math.max(ms / (365 * 24 * 3600 * 1000), 0.25 / 365 / 6.5); // floor ~15 minutes of trading
}

function normIv(v) {
  const x = Number(v);
  if (!Number.isFinite(x) || x <= 0) return null;
  return x > 3 ? x / 100 : x;
}

function modeStep(strikes, spot) {
  const near = strikes.filter((k) => Math.abs(k - spot) / spot < 0.04).sort((a, b) => a - b);
  const diffs = {};
  for (let i = 1; i < near.length; i++) { const d = +(near[i] - near[i - 1]).toFixed(2); if (d > 0) diffs[d] = (diffs[d] || 0) + 1; }
  let best = null, bc = 0;
  Object.keys(diffs).forEach((d) => { if (diffs[d] > bc || (diffs[d] === bc && Number(d) < best)) { best = Number(d); bc = diffs[d]; } });
  return best || 1;
}

/**
 * contracts: [{ strike, type:'C'|'P', exp:'YYYY-MM-DD', oi, iv, gamma, delta, mid }]
 * expiries: sorted list of expiry dates included
 * heatSlots: optional [{slot, values:{strike:net}}] recorded through the day
 */
function buildModel(spot, contracts, expiries, opts) {
  opts = opts || {};
  const now = opts.now || Date.now();
  const usable = contracts.filter((c) => c.oi > 0 && c.strike > 0);
  const allStrikes = Array.from(new Set(contracts.map((c) => c.strike)));
  const step = opts.step || modeStep(allStrikes, spot);
  const base = Math.round(spot / step) * step;
  const nS = 30;
  const strikes = [];
  for (let i = -nS; i <= nS; i++) strikes.push(+(base + i * step).toFixed(2));
  const idxOf = (K) => { const i = Math.round((K - base) / step) + nS; return i >= 0 && i < strikes.length ? i : -1; };

  const e0 = expiries[0], e1 = expiries[1];
  const fmtExp = (e) => { const [y, m, d] = e.split('-').map(Number); return ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][m - 1] + ' ' + d; };
  const buckets = [
    { key: '0dte', label: e0 ? fmtExp(e0) + ' (nearest)' : 'Nearest', T: e0 ? yearsToExpiry(e0, now) : 1 / 365, share: 0, m: () => 1 },
    { key: 'opex', label: e1 ? fmtExp(e1) : 'Next expiry', T: e1 ? yearsToExpiry(e1, now) : 7 / 365, share: 0, m: () => 1 },
    { key: 'later', label: 'Later expiries', T: 35 / 365, share: 0, m: () => 1 }
  ];
  const bOf = (exp) => (exp === e0 ? 0 : exp === e1 ? 1 : 2);
  const empty = () => ({ cG: 0, pG: 0, cD: 0, pD: 0, cV: 0, pV: 0, cC: 0, pC: 0, cN: 0, pN: 0 });
  const per = buckets.map(() => strikes.map(empty));

  // per-contract prep
  const prepared = [];
  usable.forEach((c) => {
    const T = yearsToExpiry(c.exp, now);
    let iv = normIv(c.iv);
    if (!iv && c.mid > 0) iv = impliedVol(c.mid, spot, c.strike, T, c.type);
    if (!iv) iv = 0.3;
    iv = Math.min(Math.max(iv, 0.03), 4);
    prepared.push({ c, T, iv });
  });

  let gTot = 0, gAbs = 0;
  const bucketAbs = [0, 0, 0];
  prepared.forEach(({ c, T, iv }) => {
    const g = greeks(spot, c.strike, T, iv, c.type);
    const gam = Number.isFinite(Number(c.gamma)) && Number(c.gamma) > 0 ? Number(c.gamma) : g.gamma;
    const del = Number.isFinite(Number(c.delta)) && c.delta !== null && c.delta !== '' ? Number(c.delta) : g.delta;
    const dollarG = c.oi * 100 * gam * spot * spot * 0.01;
    const sign = c.type === 'C' ? 1 : -1;
    gTot += sign * dollarG; gAbs += dollarG;
    const b = bOf(c.exp);
    bucketAbs[b] += dollarG;
    const i = idxOf(c.strike);
    if (i < 0) return;
    const cell = per[b][i];
    if (c.type === 'C') {
      cell.cG += dollarG; cell.cD += c.oi * 100 * del * spot; cell.cV += c.oi * 100 * g.vanna * spot * 0.01; cell.cC += c.oi * 100 * g.charm * spot; cell.cN += c.oi;
    } else {
      cell.pG -= dollarG; cell.pD += c.oi * 100 * del * spot; cell.pV -= c.oi * 100 * g.vanna * spot * 0.01; cell.pC -= c.oi * 100 * g.charm * spot; cell.pN += c.oi;
    }
  });
  const totAbs = bucketAbs.reduce((a, b) => a + b, 0) || 1;
  buckets.forEach((b, i) => { b.share = bucketAbs[i] / totAbs; });

  // net GEX if price moved to X (re-price gamma at X with each contract's IV)
  const netAt = (X) => {
    let n = 0;
    prepared.forEach(({ c, T, iv }) => { const g = greeks(X, c.strike, T, iv, c.type).gamma; n += (c.type === 'C' ? 1 : -1) * c.oi * 100 * g * X * X * 0.01; });
    return n;
  };
  const profile = [];
  for (let j = 0; j <= 40; j++) { const X = spot * (0.96 + 0.08 * j / 40); profile.push({ X, net: netAt(X) }); }

  // zero-gamma flip: scan a finer grid, pick the crossing closest to spot
  let flip = null;
  const fine = [];
  for (let j = 0; j <= 120; j++) { const X = spot * (0.94 + 0.12 * j / 120); fine.push({ X, n: netAt(X) }); }
  let bestD = Infinity;
  for (let j = 1; j < fine.length; j++) {
    const a = fine[j - 1], b = fine[j];
    if ((a.n <= 0 && b.n > 0) || (a.n >= 0 && b.n < 0)) {
      const X = a.X + (b.X - a.X) * (0 - a.n) / (b.n - a.n);
      if (Math.abs(X - spot) < bestD) { bestD = Math.abs(X - spot); flip = X; }
    }
  }
  if (flip === null) flip = gTot >= 0 ? spot * 0.97 : spot * 1.03; // no crossing in range

  // walls: biggest call gamma / put gamma by strike (all buckets)
  let cw = null, cwV = -1, pw = null, pwV = -1;
  strikes.forEach((K, i) => {
    const cg = per.reduce((a, row) => a + row[i].cG, 0);
    const pg = -per.reduce((a, row) => a + row[i].pG, 0);
    if (cg > cwV) { cwV = cg; cw = K; }
    if (pg > pwV) { pwV = pg; pw = K; }
  });

  // max pain for the nearest expiry
  let maxPain = null;
  const near = usable.filter((c) => c.exp === e0);
  if (near.length) {
    const ks = Array.from(new Set(near.map((c) => c.strike))).sort((a, b) => a - b);
    let best = Infinity;
    ks.forEach((S) => {
      let pay = 0;
      near.forEach((c) => { pay += c.oi * (c.type === 'C' ? Math.max(0, S - c.strike) : Math.max(0, c.strike - S)); });
      if (pay < best) { best = pay; maxPain = S; }
    });
  }

  // expected move from the nearest-expiry ATM straddle
  let em = null;
  if (near.length) {
    const atm = near.reduce((a, c) => (Math.abs(c.strike - spot) < Math.abs(a - spot) ? c.strike : a), near[0].strike);
    const call = contracts.find((c) => c.exp === e0 && c.strike === atm && c.type === 'C');
    const put = contracts.find((c) => c.exp === e0 && c.strike === atm && c.type === 'P');
    if (call && put && call.mid > 0 && put.mid > 0) em = call.mid + put.mid;
  }

  // intraday heat: recorded half-hour snapshots (filled forward), future slots blank
  const heatSlots = opts.heatSlots || [];
  const heat = [];
  const curSlot = opts.curSlot === undefined ? 13 : opts.curSlot;
  const nowVals = strikes.map((K, i) => per[0][i].cG + per[0][i].pG + per[1][i].cG + per[1][i].pG);
  let lastVals = null;
  for (let t = 0; t < 14; t++) {
    const rec = heatSlots.find((h) => h.slot === t);
    if (rec) lastVals = strikes.map((K) => rec.values[K] || 0);
    if (t === curSlot) lastVals = nowVals;
    if (t > curSlot) heat.push(nowVals);
    else heat.push(lastVals || nowVals);
  }

  return {
    strikes, buckets, per, profile, heat, putScale: 1, step,
    levels: { spot, flip, cw, pw, maxPain, em, netGex: gTot, absGex: gAbs },
    nowVals, live: true, asOf: now
  };
}

module.exports = { buildModel, greeks, bsPrice, impliedVol, yearsToExpiry, normIv, modeStep };
