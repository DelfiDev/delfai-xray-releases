// Catalysts & News, all from free public sources fetched on the user's own computer:
//  - macro calendar: Forex Factory's weekly calendar feed (CPI, FOMC, jobs, ...)
//  - earnings dates: Nasdaq's public earnings calendar
//  - market headlines: Yahoo Finance RSS
// Expected move into earnings comes from the user's own broker (ATM straddle).
'use strict';
const https = require('https');
const fs = require('fs');
const path = require('path');

const BROWSER_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36';
const H = 3600000;
// test hooks: point the three sources at a local test double
const FF = process.env.CAL_FF_URL || 'https://nfs.faireconomy.media/ff_calendar_thisweek.json';
const FF_NEXT = process.env.CAL_FF_NEXT_URL || 'https://nfs.faireconomy.media/ff_calendar_nextweek.json';
const NDQ = process.env.CAL_NDQ_URL || 'https://api.nasdaq.com/api/calendar/earnings';
const YH = process.env.CAL_YH_URL || 'https://feeds.finance.yahoo.com/rss/2.0/headline';
const WORLD_RSS = process.env.CAL_WORLD_URL || 'https://feeds.bbci.co.uk/news/world/rss.xml';
const BIZ_RSS = process.env.CAL_BIZ_URL || 'https://feeds.bbci.co.uk/news/business/rss.xml';

function get(url, headers, asText) {
  return new Promise((resolve, reject) => {
    const req = (url.startsWith('http:') ? require('http') : https).get(url, { headers: Object.assign({ 'User-Agent': BROWSER_UA, Accept: asText ? '*/*' : 'application/json, text/plain, */*' }, headers || {}), timeout: 15000 }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) { res.resume(); return resolve(get(new URL(res.headers.location, url).toString(), headers, asText)); }
      const chunks = []; res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        const body = Buffer.concat(chunks).toString('utf8');
        if (res.statusCode !== 200) { const e = new Error(new URL(url).host + ' returned HTTP ' + res.statusCode); e.status = res.statusCode; return reject(e); }
        if (asText) return resolve(body);
        try { resolve(JSON.parse(body)); } catch (e) { reject(new Error(new URL(url).host + ' sent something unreadable')); }
      });
    });
    req.on('timeout', () => req.destroy(new Error(new URL(url).host + ' timed out')));
    req.on('error', reject);
  });
}

const nyDate = (ms) => new Intl.DateTimeFormat('en-CA', { timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(ms));
const nyTime = (ms) => new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date(ms));
const nyDow = (ms) => new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', weekday: 'short' }).format(new Date(ms)).toUpperCase();
const money = (s) => { const n = Number(String(s || '').replace(/[$,]/g, '')); return Number.isFinite(n) ? n : 0; };

// headlines: which ticker or market a headline is about, for the left column
const TAGS = [
  [/nvidia/i, 'NVDA'], [/tesla|musk/i, 'TSLA'], [/apple|iphone/i, 'AAPL'], [/microsoft/i, 'MSFT'],
  [/amazon/i, 'AMZN'], [/meta\b|facebook|instagram/i, 'META'], [/alphabet|google/i, 'GOOGL'], [/netflix/i, 'NFLX'], [/palantir/i, 'PLTR'], [/\bamd\b/i, 'AMD'],
  [/bitcoin|btc\b/i, 'BTCUSD'], [/ether(eum)?\b|\beth\b/i, 'ETHUSD'], [/solana/i, 'SOLUSD'], [/\bxrp\b|ripple/i, 'XRPUSD'], [/doge/i, 'DOGEUSD'], [/coinbase/i, 'COIN'],
  [/crude|oil\b|opec|brent/i, '/CL'], [/gold\b/i, '/GC'], [/dollar|dxy/i, 'DXY'], [/euro\b|ecb/i, 'EURUSD'], [/yen\b|boj/i, 'USDJPY'], [/treasur|yield|bond/i, '/ZN'], [/fed\b|powell|fomc|rate cut|rate hike/i, 'FED'], [/natural gas/i, '/NG'],
  [/s&p|stocks?\b|wall street|dow\b|nasdaq|market/i, 'SPX']
];
const CATS = {
  stock: { s: '^GSPC,^IXIC,SPY,QQQ,NVDA,TSLA,AAPL,MSFT,AMZN,META', fallback: 'SPX' },
  fx: { s: 'ES=F,NQ=F,CL=F,GC=F,DX-Y.NYB,EURUSD=X,JPY=X,^TNX', fallback: '/ES' },
  crypto: { s: 'BTC-USD,ETH-USD,SOL-USD,XRP-USD,DOGE-USD,COIN', fallback: 'BTCUSD' }
};

class Calendar {
  constructor(opts) {
    this.dir = opts.cacheDir; if (this.dir) fs.mkdirSync(this.dir, { recursive: true });
    this.log = opts.log || (() => {});
    this.mem = new Map();
  }
  async cached(key, ttl, fn, disk) {
    const now = Date.now(); const e = this.mem.get(key);
    if (e && e.v !== undefined && now - e.t < ttl) return e.v;
    if (e && e.p) return e.p;
    if (disk && this.dir && !e) { try { const f = path.join(this.dir, key.replace(/[^a-z0-9-]/gi, '_') + '.json'); const st = fs.statSync(f); if (now - st.mtimeMs < ttl) { const v = JSON.parse(fs.readFileSync(f, 'utf8')); this.mem.set(key, { t: st.mtimeMs, v }); return v; } } catch (err) { /* no cache yet */ } }
    const p = fn().then((v) => {
      this.mem.set(key, { t: Date.now(), v });
      if (disk && this.dir) { try { fs.writeFileSync(path.join(this.dir, key.replace(/[^a-z0-9-]/gi, '_') + '.json'), JSON.stringify(v)); } catch (err) { /* optional */ } }
      return v;
    }).catch((err) => { const old = this.mem.get(key); this.mem.set(key, { t: old && old.v !== undefined ? old.t : 0, v: old ? old.v : undefined }); if (old && old.v !== undefined) return old.v; throw err; });
    this.mem.set(key, Object.assign({}, e || {}, { p }));
    return p;
  }

  // ---------- macro (US events, medium/high impact) ----------
  macroWeek() {
    return this.cached('ff-week', 2 * H, async () => {
      const [a, b] = await Promise.all([get(FF), get(FF_NEXT).catch(() => [])]);
      const rows = [].concat(Array.isArray(a) ? a : [], Array.isArray(b) ? b : []);
      return (Array.isArray(rows) ? rows : []).filter((r) => r.country === 'USD' && /high|medium/i.test(r.impact || '')).map((r) => {
        const t = Date.parse(r.date);
        return { t, date: nyDate(t), day: nyDow(t), time: /all day|tentative/i.test(r.time || '') ? 'ALL' : nyTime(t), title: r.title, impact: /high/i.test(r.impact) ? 'High' : 'Medium', forecast: r.forecast || '', previous: r.previous || '' };
      }).filter((r) => Number.isFinite(r.t)).sort((a, b) => a.t - b.t);
    }, true);
  }

  // ---------- earnings (Nasdaq calendar, one day per request) ----------
  earningsDay(date) {
    return this.cached('ndq-' + date, date < nyDate(Date.now()) ? 30 * 24 * H : 8 * H, async () => {
      const j = await get(NDQ + '?date=' + date, { Origin: 'https://www.nasdaq.com', Referer: 'https://www.nasdaq.com/' });
      const rows = (j && j.data && j.data.rows) || [];
      return rows.map((r) => ({ sym: String(r.symbol || '').toUpperCase(), name: r.name || '', when: /pre-market/.test(r.time || '') ? 'BMO' : /after-hours/.test(r.time || '') ? 'AMC' : 'TBD', cap: money(r.marketCap), eps: r.epsForecast || '', quarter: r.fiscalQuarterEnding || '', date }));
    }, true);
  }
  async earningsRange(days) {
    const out = [];
    const start = Date.now();
    for (let i = 0; i < days; i++) {
      const t = start + i * 24 * H; const dow = nyDow(t);
      if (dow === 'SAT' || dow === 'SUN') continue;
      try { (await this.earningsDay(nyDate(t))).forEach((r) => out.push(r)); } catch (e) { this.log('earnings ' + nyDate(t) + ': ' + e.message); }
    }
    return out;
  }

  // this week's catalysts: US macro + earnings from companies over $100B or on the watch list
  async week(watch) {
    const now = Date.now();
    const span = 8; // the next 7 days
    const [macro, earn] = await Promise.all([this.macroWeek().catch((e) => { this.log('macro: ' + e.message); return []; }), this.earningsRange(span)]);
    const w = new Set((watch || []).map((s) => s.toUpperCase()));
    const big = earn.filter((r) => r.cap >= 100e9 || w.has(r.sym)).sort((a, b) => b.cap - a.cap).slice(0, 14);
    const today = nyDate(now);
    return {
      macro: macro.filter((m) => m.date >= today && m.t < now + 7 * 24 * H),
      earnings: big.map((r) => ({ sym: r.sym, name: r.name, date: r.date, day: nyDow(Date.parse(r.date + 'T12:00:00Z')), when: r.when, cap: r.cap, eps: r.eps })),
      t: now
    };
  }

  // next report date for each name over the next ~6 weeks
  async nextEarnings(syms) {
    const all = await this.earningsRange(45);
    const out = {};
    all.forEach((r) => { if (syms.includes(r.sym) && !out[r.sym]) out[r.sym] = r; });
    return out;
  }

  // ---------- headlines ----------
  marketNews(cat) {
    const c = CATS[cat] || CATS.stock;
    return this.cached('news-' + cat, 5 * 60000, async () => {
      const xml = await get(YH + '?s=' + encodeURIComponent(c.s) + '&region=US&lang=en-US', {}, true);
      const dec = (x) => (x || '').replace(/<!\[CDATA\[|\]\]>/g, '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').trim();
      const seen = new Set();
      return (xml.match(/<item>[\s\S]*?<\/item>/g) || []).map((it) => {
        const g = (tag) => { const m = new RegExp('<' + tag + '>([\\s\\S]*?)</' + tag + '>').exec(it); return m ? dec(m[1]) : ''; };
        const title = g('title'); const hit = TAGS.find(([re]) => re.test(title));
        return { title, link: g('link'), time: Date.parse(g('pubDate')) || null, src: 'Yahoo Finance', sym: hit ? hit[1] : c.fallback };
      }).filter((x) => x.title && !seen.has(x.title) && seen.add(x.title)).sort((a, b) => (b.time || 0) - (a.time || 0)).slice(0, 12);
    });
  }
}

// ---------- globe: world macro calendar + geotagged headlines ----------
const CCY = { USD: ['Washington, D.C.', 38.9, -77.0], EUR: ['Frankfurt (ECB)', 50.1, 8.7], GBP: ['London', 51.5, -0.1], JPY: ['Tokyo', 35.7, 139.7], CNY: ['Beijing', 39.9, 116.4], AUD: ['Sydney', -33.9, 151.2], CAD: ['Ottawa', 45.4, -75.7], CHF: ['Zurich', 47.4, 8.5], NZD: ['Wellington', -41.3, 174.8] };
const CCY_ASSETS = { USD: [['SPX', 'flat', 'SPX'], ['DXY', 'flat'], ['US 10Y', 'flat']], EUR: [['EURUSD', 'flat'], ['DAX', 'flat']], GBP: [['GBPUSD', 'flat'], ['FTSE 100', 'flat']], JPY: [['USDJPY', 'flat'], ['Nikkei', 'flat']], CNY: [['Hang Seng', 'flat'], ['Copper', 'flat']], AUD: [['AUDUSD', 'flat']], CAD: [['USDCAD', 'flat'], ['Oil', 'flat']], CHF: [['USDCHF', 'flat']], NZD: [['NZDUSD', 'flat']] };
const PLACES = [
  [/hormuz/i, 'Strait of Hormuz', 26.6, 56.3, 'ship'], [/red sea|houthi|bab el|suez/i, 'Red Sea / Suez', 20.0, 39.0, 'ship'], [/panama canal/i, 'Panama Canal', 9.1, -79.7, 'ship'], [/malacca/i, 'Strait of Malacca', 2.5, 101.5, 'ship'],
  [/taiwan|tsmc/i, 'Taiwan', 24.5, 121.0, 'geo'], [/ukrain|kyiv|odesa/i, 'Ukraine', 50.4, 30.5, 'geo'], [/russia|kremlin|moscow|putin/i, 'Moscow', 55.8, 37.6, 'geo'], [/israel|gaza|lebanon|hezbollah/i, 'Israel', 31.8, 35.2, 'geo'], [/\biran\b|tehran/i, 'Tehran', 35.7, 51.4, 'geo'],
  [/north korea|pyongyang/i, 'Pyongyang', 39.0, 125.8, 'geo'], [/venezuela/i, 'Caracas', 10.5, -66.9, 'geo'],
  [/opec|saudi|aramco/i, 'Riyadh (OPEC+)', 24.7, 46.7, 'energy'], [/copper|chile/i, 'Chile', -33.4, -70.6, 'energy'], [/crude|oil price|brent|natural gas|lng/i, 'Oil markets', 29.8, -95.4, 'energy'], [/gold\b/i, 'Gold', 51.5, -0.1, 'energy'],
  [/hurricane|tropical storm|typhoon|earthquake|wildfire|flood/i, '', 0, 0, 'wx'],
  [/\bfed\b|powell|fomc|federal reserve/i, 'Washington, D.C. (Fed)', 38.9, -77.0, 'cb'], [/\becb\b|lagarde/i, 'Frankfurt (ECB)', 50.1, 8.7, 'cb'], [/bank of england|\bboe\b/i, 'London (BoE)', 51.5, -0.1, 'cb'], [/bank of japan|\bboj\b/i, 'Tokyo (BoJ)', 35.7, 139.7, 'cb'], [/pboc|people's bank of china/i, 'Beijing (PBoC)', 39.9, 116.4, 'cb'],
  [/china|beijing|xi jinping|chinese/i, 'Beijing', 39.9, 116.4, 'geo'], [/japan|tokyo|yen\b/i, 'Tokyo', 35.7, 139.7, 'data'], [/germany|german|berlin/i, 'Berlin', 52.5, 13.4, 'data'], [/\buk\b|britain|british|london/i, 'London', 51.5, -0.1, 'data'],
  [/europe|eurozone|\beu\b|brussels/i, 'Brussels', 50.85, 4.35, 'geo'], [/india|mumbai|delhi/i, 'Mumbai', 19.1, 72.9, 'data'], [/korea|seoul|samsung/i, 'Seoul', 37.6, 127.0, 'data'], [/canada|ottawa/i, 'Ottawa', 45.4, -75.7, 'data'], [/mexico/i, 'Mexico City', 19.4, -99.1, 'data'],
  [/brazil/i, 'Brasília', -15.8, -47.9, 'data'], [/australia/i, 'Sydney', -33.9, 151.2, 'data'], [/tariff|trade war|trade deal/i, 'Washington, D.C.', 38.9, -77.0, 'geo'],
  [/wall street|s&p|nasdaq|dow\b|stocks?\b|nvidia|tesla|apple|microsoft|amazon|meta\b|alphabet/i, 'New York', 40.7, -74.0, 'data']
];
const TOPICS = [
  [/\bwar\b|military|missile|drone|troops|sanction|ceasefire|invasion|nuclear|airstrike|air strike|fighter jets?|\barmy\b|navy|attack on|strikes? on|coup|election|president|prime minister|parliament|government|protest|border|diplomat|summit|tariff|trade war|trade deal/i, 'geo'],
  [/central bank|interest rates?|rate (cut|hike|decision)|monetary policy|\becb\b|\bfed\b|bank of (england|japan|canada)|\bboj\b|\bboe\b|lagarde|powell|warsh/i, 'cb'],
  [/\boil\b|crude|opec|natural gas|\blng\b|energy|pipeline|refiner|electricity|power grid|coal/i, 'energy'],
  [/\bgdp\b|inflation|\bcpi\b|\bpce\b|payrolls?|jobs report|unemployment|jobless|\bpmi\b|retail sales|economy|economic|recession|exports?|imports?|trade (deficit|surplus|balance)|industrial|manufactur|consumer|housing|wages?|budget|deficit|earnings|profits?|shares|stocks?|markets?|investors?|bank|currency|bonds?|yields?|debt|layoffs?|jobs/i, 'data']
];
const WX_SPOTS = [[/gulf|texas|louisiana|florida/i, 'Gulf of Mexico', 25.5, -90.0], [/japan/i, 'Japan', 35.7, 139.7], [/taiwan/i, 'Taiwan', 24.5, 121.0], [/philippines/i, 'Philippines', 14.6, 121.0], [/california/i, 'California', 36.8, -119.4], [/china/i, 'China', 31.2, 121.5]];

Calendar.prototype.worldCalendar = function () {
  return this.cached('ff-world', 2 * H, async () => {
    const [a, b] = await Promise.all([get(FF), get(FF_NEXT).catch(() => [])]);
    return [].concat(Array.isArray(a) ? a : [], Array.isArray(b) ? b : []).filter((r) => CCY[r.country] && /high|medium/i.test(r.impact || ''));
  }, true);
};
Calendar.prototype.worldNews = function () {
  return this.cached('world-news', 10 * 60000, async () => {
    const feeds = [WORLD_RSS, BIZ_RSS];
    const xmls = await Promise.all(feeds.map((u) => get(u, {}, true).catch(() => '')));
    const dec = (x) => (x || '').replace(/<!\[CDATA\[|\]\]>/g, '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').trim();
    const out = [];
    xmls.forEach((xml) => (xml.match(/<item>[\s\S]*?<\/item>/g) || []).forEach((it) => {
      const g = (tag) => { const m = new RegExp('<' + tag + '>([\\s\\S]*?)</' + tag + '>').exec(it); return m ? dec(m[1]) : ''; };
      out.push({ title: g('title'), summary: g('description'), link: g('link'), time: Date.parse(g('pubDate')) || null, src: 'BBC' });
    }));
    return out;
  });
};
Calendar.prototype.globe = async function (upLex, downLex) {
  const now = Date.now();
  const [cal, world, ...mkts] = await Promise.all([this.worldCalendar().catch(() => []), this.worldNews().catch(() => []), ...['stock', 'fx', 'crypto'].map((c) => this.marketNews(c).catch(() => []))]);
  const ev = [];
  cal.forEach((r, i) => {
    const t = Date.parse(r.date); if (!Number.isFinite(t)) return;
    const ago = (now - t) / H; if (ago > 24 * 7 || ago < -24 * 8) return;
    const [where, lat, lon] = CCY[r.country];
    const isCb = /rate|statement|minutes|press conference|speaks|testifies|monetary policy/i.test(r.title);
    const nums = [r.forecast ? 'Forecast ' + r.forecast : '', r.previous ? 'previous ' + r.previous : ''].filter(Boolean).join(', ');
    ev.push({ id: 'c' + i, cat: isCb ? 'cb' : 'data', imp: /high/i.test(r.impact) ? 3 : 2, ago, lat, lon, where, title: r.country + ' ' + r.title, summary: (ago < 0 ? 'Scheduled ' : 'Released ') + nyDow(t) + ' ' + nyTime(t) + ' ET.' + (nums ? ' ' + nums + '.' : ''), assets: CCY_ASSETS[r.country], read: r.country === 'USD' ? (/high/i.test(r.impact) ? 'US high-impact release: expect a volatility spike at the print, then IV drops on 0DTE. Size down into it.' : 'US release, usually a moderate mover for SPX.') : 'Overseas release. Mostly moves its own currency and index; watch for follow-through into the US open.', src: 'Economic calendar', link: '' });
  });
  const seen = new Set();
  const all = world.concat(...mkts.map((l) => l.map((x) => Object.assign({ summary: '' }, x))));
  all.forEach((n, i) => {
    if (!n.title || seen.has(n.title)) return; seen.add(n.title);
    const txt = n.title + ' ' + (n.summary || '');
    const pl = PLACES.find(([re]) => re.test(txt)); if (!pl) return;
    let [, where, lat, lon, cat] = pl;
    if (cat === 'wx') { const w = WX_SPOTS.find(([re]) => re.test(txt)); if (!w) return; [, where, lat, lon] = w; }
    // a country name only says WHERE; what the story is ABOUT decides the category. Not market news (crime, animals, sport…): skip it.
    if (cat === 'data' || cat === 'geo') { const t = TOPICS.find(([re]) => re.test(txt)); if (!t) return; cat = t[1]; }
    const ago = n.time ? (now - n.time) / H : 1; if (ago > 24 * 7) return;
    const up = upLex.test(n.title), down = downLex.test(n.title);
    const dir = up && !down ? 'up' : down && !up ? 'down' : 'flat';
    const hit = TAGS.find(([re]) => re.test(n.title));
    const assets = hit ? [[hit[1], dir, /^[A-Z]{1,5}$/.test(hit[1]) ? hit[1] : undefined]] : [];
    const imp = /war|attack|strike|sanction|missile|invasion|collapse|crash|emergency|tariff|hurricane|earthquake|default/i.test(txt) ? 3 : cat === 'data' ? 1 : 2;
    ev.push({ id: 'n' + i, cat, imp, ago, lat: lat + ((i % 5) - 2) * 0.6, lon: lon + ((i % 7) - 3) * 0.6, where, title: n.title, summary: n.summary || '', assets, read: imp === 3 ? 'Headline risk. Can move SPX fast either way; wait for the first 15-minute candle to settle before trusting a box.' : cat === 'energy' ? 'Energy story. Moves oil names and inflation expectations more than tech.' : cat === 'cb' ? 'Central bank headline. Watch yields and the dollar; rate-sensitive names react first.' : 'Background story. Low impact for 0DTE unless it builds.', src: n.src, link: n.link || '', breaking: ago < 1 && imp === 3 });
  });
  return ev.sort((a, b) => b.imp - a.imp).slice(0, 60);
};

// expected move into a date from the user's broker: ATM straddle of the first expiry on/after it
async function expectedMove(dm, sym, date) {
  const ex = await dm.expirations(sym);
  const exp = (ex.expiries || []).find((e) => e >= date);
  if (!exp) return null;
  const q = (await dm.quotes([sym]))[sym]; if (!q || !q.last) return null;
  const list = await dm.chainContracts(sym, exp, 0.04);
  if (!list.length) return null;
  const k = list.map((c) => c.strike).reduce((b, s) => (Math.abs(s - q.last) < Math.abs(b - q.last) ? s : b), list[0].strike);
  const c = list.find((x) => x.strike === k && x.type === 'C'), p = list.find((x) => x.strike === k && x.type === 'P');
  if (!c || !p) return null;
  const s = await dm.optionQuotes([c.occ, p.occ], 60000);
  const cm = s[c.occ] && s[c.occ].mid, pm = s[p.occ] && s[p.occ].mid;
  if (!(cm > 0) || !(pm > 0)) return null;
  return { pct: (cm + pm) / q.last * 100, exp };
}

module.exports = { Calendar, expectedMove, nyDate };
