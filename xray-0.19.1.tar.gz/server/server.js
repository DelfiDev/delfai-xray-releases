// Local X-ray server: serves the UI and a small JSON API on 127.0.0.1, plus optional PIN-protected phone access.
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { WebullClient } = require('./webull');
const { DataManager } = require('./data');
const { SchwabClient } = require('./schwab');
const { SchwabData, MultiData } = require('./schwab_data');
const { SecData } = require('./sec');
const { moneyMap } = require('./moneymap');
const { scanTicker } = require('./premflow');
const { Fred } = require('./fred');
const { dealerModel } = require('./dealer');
const { Support } = require('./support');
const { Vip, donePage } = require('./vip');
const { Updater } = require('./updater');
const vault = require('./vault');
const { Finra } = require('./finra');
const { Calendar, expectedMove, nyDate } = require('./calendar');

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.woff2': 'font/woff2', '.woff': 'font/woff', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };

function start(opts) {
  const dataDir = opts.dataDir;
  const uiDir = opts.uiDir;
  fs.mkdirSync(dataDir, { recursive: true });
  const cfgFile = path.join(dataDir, 'config.json');
  const logFile = path.join(dataDir, 'xray.log');
  const log = (m) => { const line = new Date().toISOString() + ' ' + m + '\n'; try { fs.appendFileSync(logFile, line); } catch (e) { /* ignore */ } if (opts.verbose) process.stdout.write(line); };

  let cfg = {};
  cfg = vault.readJSON(cfgFile) || {};
  const saveCfg = () => vault.writeJSON(cfgFile, cfg);
  if (vault.encrypted()) { try { if (!fs.readFileSync(cfgFile, 'utf8').startsWith('XRV1:') && Object.keys(cfg).length) saveCfg(); } catch (e) { /* no file yet */ } }   // lock older plain files right away
  ['webull-token.json', 'schwab-token.json'].forEach((f) => vault.lock(path.join(dataDir, f)));

  const mmCache = new Map();
  const pfCache = new Map(); const pfScanning = new Set(); const pfErr = new Map(); let pfBusy = Promise.resolve();
  const fred = new Fred({ cacheDir: path.join(dataDir, 'fred-cache'), log }); let volCache = null;
  const vip = new Vip({ getCfg: () => cfg, saveCfg: () => saveCfg(), log });
  // auto-updater (signed updates from the public releases repo)
  const updater = new Updater({ dataDir, current: opts.version || process.env.XRAY_TEST_VERSION || '0.0.0', log, onRestart: opts.onRestart || null });
  // box answers from VENOM, cached a minute per contract (and per latest candle)
  const boxCache = new Map();
  const boxFor = async (key, days, sg) => {
    const last = days && days.length ? days[days.length - 1] : null;
    const sig = key + '|' + (last ? [last.day || last.t, last.c, last.l, last.v].join(',') : '') + '|' + sg;
    const hit = boxCache.get(sig);
    if (hit && Date.now() - hit.at < 60000) return hit.r;
    const r = await vip.box(key, days, sg);
    if (!r.error) { boxCache.set(sig, { at: Date.now(), r }); if (boxCache.size > 800) boxCache.delete(boxCache.keys().next().value); }
    return r;
  };
  const support = new Support({ dataDir, log, getCfg: () => cfg, saveCfg: () => saveCfg(), version: opts.version });
  const finra = new Finra({ cacheDir: path.join(dataDir, 'finra-cache'), log }); const dlCache = new Map();
  setTimeout(() => { try { fred.refresh(); } catch (e) { /* retried when the page opens */ } }, 15000); // warm the economic data in the background
  const cal = new Calendar({ cacheDir: path.join(dataDir, 'calendar-cache'), log });
  let bigCache = null;
  const sec = new SecData({ cacheDir: path.join(dataDir, 'sec-cache'), wwwHost: opts.secWwwHost, dataHost: opts.secDataHost, protocol: opts.secProtocol, log });
  const state = { mode: 'demo', phase: 'idle', message: 'Not connected. Showing sample data.', tokenStatus: null };
  let client = null, dm = null;

  const makeClient = () => {
    const w = cfg.webull || {};
    if (!w.appKey || !w.appSecret) return null;
    const hostOpt = opts.webullHost || w.host || 'api.webull.com';
    const [host, port] = hostOpt.split(':');
    return new WebullClient({ appKey: w.appKey, appSecret: w.appSecret, host, port: port ? Number(port) : null, protocol: opts.webullProtocol || 'https', tokenFile: path.join(dataDir, 'webull-token.json'), log });
  };

  const schwabState = { phase: 'idle', message: '', live: false };
  let schwab = null, wbLive = false;
  const makeSchwab = () => {
    const c = cfg.schwab || {};
    if (!c.appKey || !c.appSecret) return null;
    return new SchwabClient({ appKey: c.appKey, appSecret: c.appSecret, host: opts.schwabHost, protocol: opts.schwabProtocol || 'https', tokenFile: path.join(dataDir, 'schwab-token.json'), log });
  };
  const rebuild = () => {
    const list = [];
    if (wbLive && client) { const d = new DataManager(client, log); d.name = 'Webull'; list.push(d); }
    if (schwabState.live && schwab) list.push(new SchwabData(schwab, log));
    // keep caches/heatmaps when the provider set did not change
    const names = list.map((d) => d.name).join('+');
    if (!dm || dm._names !== names) { dm = list.length ? new MultiData(list, log) : null; if (dm) dm._names = names; }
    if (list.length) { state.mode = 'live'; state.phase = 'live'; state.message = 'Live · ' + list.map((d) => d.name).join(' + '); }
    else if (state.mode === 'live') { state.mode = 'demo'; }
    state.sources = list.map((d) => d.name);
  };
  const connectWebull = async () => {
    client = makeClient();
    if (!client) { wbLive = false; if (!schwabState.live) { state.mode = 'demo'; state.phase = 'needs-keys'; state.message = 'Add your Webull or Schwab keys to go live.'; } return; }
    const wdm = new DataManager(client, log);
    if (!schwabState.live) { state.phase = 'connecting'; state.message = 'Connecting to Webull…'; }
    try {
      const r = await client.ensureToken((u) => {
        state.tokenStatus = u.status;
        if (u.status === 'PENDING' && !schwabState.live) { state.phase = 'approve'; state.message = 'Open the Webull app and approve the API access request (2-step check). X-ray is waiting…'; }
      });
      state.tokenStatus = r.status;
      const q = await wdm.quotes(['SPY']);
      if (!q.SPY || !q.SPY.last) throw new Error('Connected, but Webull returned no SPY quote. Check that market data is enabled for your API app.');
      wbLive = true; state.webullError = null;
      log('webull: live');
    } catch (e) {
      wbLive = false; state.webullError = e.message;
      if (!schwabState.live) { state.mode = 'demo'; state.phase = 'error'; state.message = e.message; }
      log('webull connect error: ' + e.message);
    }
    rebuild();
  };
  const connectSchwab = async () => {
    schwab = makeSchwab();
    schwabState.live = false;
    if (!schwab) { schwabState.phase = 'needs-keys'; schwabState.message = 'Add your Schwab App Key and Secret.'; rebuild(); return; }
    if (!schwab.hasLogin()) { schwabState.phase = 'needs-login'; schwabState.message = schwab.tok ? 'Your Schwab login expired. Schwab asks for a new login every 7 days.' : 'Click Log in with Schwab to finish connecting.'; rebuild(); return; }
    schwabState.phase = 'connecting'; schwabState.message = 'Connecting to Schwab…';
    try {
      const q = await new SchwabData(schwab, log).quotes(['SPY']);
      if (!q.SPY || !q.SPY.last) throw new Error('Connected, but Schwab returned no SPY quote. Check that Market Data Production is on for your Schwab app.');
      schwabState.live = true; schwabState.phase = 'live'; schwabState.message = 'Live · Schwab';
      log('schwab: live');
    } catch (e) {
      schwabState.phase = e.status === 401 ? 'needs-login' : 'error'; schwabState.message = e.message;
      log('schwab connect error: ' + e.message);
    }
    rebuild();
  };
  const connect = async () => { await Promise.all([connectWebull(), connectSchwab()]); };
  // re-check Schwab now and then: notices an expired 7-day login and recovers after network blips
  setInterval(() => { if (cfg.schwab && cfg.schwab.appKey && (!schwabState.live || (schwab && !schwab.hasLogin()))) connectSchwab(); }, 5 * 60000).unref();

  const send = (res, code, obj) => {
    const body = JSON.stringify(obj);
    res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(body);
  };
  const readBig = (req, max) => new Promise((resolve, reject) => { const chunks = []; let n = 0; req.on('data', (c) => { n += c.length; if (n > max) { req.destroy(); reject(Object.assign(new Error('Too large'), { status: 413 })); } else chunks.push(c); }); req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); } catch (e) { resolve({}); } }); });
  const readBody = (req) => new Promise((resolve) => { let d = ''; req.on('data', (c) => { d += c; if (d.length > 1e5) req.destroy(); }); req.on('end', () => { try { resolve(d ? JSON.parse(d) : {}); } catch (e) { resolve({}); } }); });
  const needLive = (res) => { if (state.mode !== 'live' || !dm) { send(res, 409, { error: 'not-live', message: state.message }); return false; } return true; };

  // ---------- phone mode (PIN-protected access from your phone on the same network / Tailscale) ----------
  const PHONE_PORT = opts.phonePort || 7471;
  let phoneServer = null;
  const fails = {}; // ip -> {n, until}
  const newPin = () => String(crypto.randomInt(0, 1000000)).padStart(6, '0');
  const phoneCfg = () => { cfg.phone = Object.assign({ enabled: false, pin: null, sessions: [] }, cfg.phone || {}); if (!cfg.phone.pin) cfg.phone.pin = newPin(); return cfg.phone; };
  const lanUrls = () => {
    const out = [];
    Object.entries(os.networkInterfaces()).forEach(([name, list]) => (list || []).forEach((a) => {
      if (a.family !== 'IPv4' && a.family !== 4) return;
      if (a.internal) return;
      const ts = /^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./.test(a.address);
      out.push({ url: 'http://' + a.address + ':' + PHONE_PORT + '/', label: ts ? 'Tailscale (works away from home)' : 'Home Wi-Fi', name, ts });
    }));
    return out.sort((x, y) => (x.ts === y.ts ? 0 : x.ts ? 1 : -1));
  };
  const cookieOf = (req) => { const m = /(?:^|;\s*)xr_phone=([a-f0-9]{48})/.exec(req.headers.cookie || ''); return m ? m[1] : null; };
  const loginPage = (msg) => `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><meta name="theme-color" content="#0E131B"><link rel="apple-touch-icon" href="/apple-touch-icon.png"><link rel="manifest" href="/manifest.json"><title>DELFAi X-ray</title>
<style>@font-face{font-family:'Archivo Narrow';font-weight:700;src:url(/fonts/archivo-narrow-latin-700-normal.woff2) format('woff2')}@font-face{font-family:'JetBrains Mono';font-weight:500;src:url(/fonts/jetbrains-mono-latin-500-normal.woff2) format('woff2')}
body{margin:0;min-height:100vh;background:radial-gradient(ellipse at 50% 30%,#132233,#0A1017 60%,#06090E);color:#E8EEF2;font-family:system-ui,sans-serif;display:flex;align-items:center;justify-content:center}
form{width:min(340px,88vw);display:flex;flex-direction:column;align-items:center;gap:16px;text-align:center}
img{width:96px;height:96px;filter:drop-shadow(0 0 14px rgba(143,210,236,.5))}
h1{margin:0;font-family:'Archivo Narrow',sans-serif;font-size:34px}h1 span{color:#8FD2EC}
p{margin:0;color:#8796A3;font-size:14px;line-height:1.5}
input{width:100%;box-sizing:border-box;background:#0B1017;border:1px solid #2C3D52;border-radius:12px;color:#E8EEF2;font-size:28px;letter-spacing:.4em;text-align:center;padding:14px;font-family:'JetBrains Mono',monospace}
input:focus{outline:2px solid #8FD2EC;outline-offset:1px}
button{width:100%;min-height:50px;border:0;border-radius:12px;background:#8FD2EC;color:#0B1017;font-size:16px;font-weight:600}
.err{color:#F2555A}</style></head><body><form method="post" action="/phone-login"><img src="/delfi-logo.png" alt="Delfi logo"><h1>DELFAi <span>X-RAY</span></h1><p>Enter the 6-digit PIN shown on your computer under Data connection → Phone access.</p>${msg ? '<p class="err">' + msg + '</p>' : ''}<input name="pin" inputmode="numeric" pattern="[0-9]*" maxlength="6" autocomplete="one-time-code" aria-label="PIN" autofocus><button type="submit">Unlock</button></form></body></html>`;
  const html = (res, code, body, extra) => { res.writeHead(code, Object.assign({ 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' }, extra || {})); res.end(body); };
  const readForm = (req) => new Promise((resolve) => { let d = ''; req.on('data', (c) => { d += c; if (d.length > 2000) req.destroy(); }); req.on('end', () => resolve(new URLSearchParams(d))); });
  const PHONE_BLOCK = new Set(['/api/config', '/api/connect', '/api/disconnect', '/api/forget', '/api/phone', '/setup.html', '/api/schwab/config', '/api/schwab/auth-url', '/api/schwab/code', '/api/schwab/forget']);

  const phoneGate = async (req, res, p) => {
    const pc = phoneCfg();
    const ip = req.socket.remoteAddress || '?';
    if (p === '/phone-login' && req.method === 'POST') {
      const f = fails[ip];
      if (f && f.until > Date.now()) { html(res, 429, loginPage('Too many tries. Wait 10 minutes and try again.')); return false; }
      const pin = ((await readForm(req)).get('pin') || '').trim();
      if (pin && crypto.timingSafeEqual(Buffer.from(pin.padEnd(6).slice(0, 6)), Buffer.from(pc.pin))) {
        delete fails[ip];
        const tok = crypto.randomBytes(24).toString('hex');
        pc.sessions = [tok].concat(pc.sessions || []).slice(0, 10); saveCfg();
        log('phone login ok from ' + ip);
        res.writeHead(303, { Location: '/', 'Set-Cookie': 'xr_phone=' + tok + '; Path=/; HttpOnly; SameSite=Lax; Max-Age=31536000', 'Cache-Control': 'no-store' }); res.end();
        return false;
      }
      const n = ((f && f.until <= Date.now()) ? 0 : (f ? f.n : 0)) + 1;
      fails[ip] = { n, until: n >= 5 ? Date.now() + 10 * 60000 : 0 };
      log('phone login failed from ' + ip);
      html(res, 401, loginPage(n >= 5 ? 'Too many tries. Wait 10 minutes and try again.' : 'Wrong PIN. Try again.'));
      return false;
    }
    const tok = cookieOf(req);
    const ok = tok && (pc.sessions || []).includes(tok);
    const publicAsset = /^\/(fonts\/|delfi-logo\.png|apple-touch-icon\.png|manifest\.json|icon-512\.png)/.test(p);
    if (!ok && !publicAsset) {
      if (p.startsWith('/api/')) { send(res, 401, { error: 'locked' }); return false; }
      html(res, 200, loginPage(''));
      return false;
    }
    if (PHONE_BLOCK.has(p)) {
      if (p.startsWith('/api/')) send(res, 403, { error: 'Only available on your computer.' });
      else html(res, 403, '<!doctype html><meta name="viewport" content="width=device-width, initial-scale=1"><body style="background:#0E131B;color:#E8EEF2;font-family:system-ui;padding:32px;line-height:1.5"><h2>Open Data connection on your computer</h2><p>Keys and phone access can only be changed on the computer running X-ray.</p><p><a style="color:#8FD2EC" href="/">← Back to X-ray</a></p></body>');
      return false;
    }
    return true;
  };

  const startPhone = () => new Promise((resolve) => {
    if (phoneServer) return resolve(true);
    const srv = http.createServer(handler(true));
    srv.on('error', (e) => { log('phone server error: ' + e.message); state.phoneError = e.code === 'EADDRINUSE' ? 'Port ' + PHONE_PORT + ' is busy. Close other X-ray windows and try again.' : e.message; phoneServer = null; resolve(false); });
    srv.listen(PHONE_PORT, '0.0.0.0', () => { phoneServer = srv; state.phoneError = null; log('phone access on ' + PHONE_PORT); resolve(true); });
  });
  const stopPhone = () => new Promise((resolve) => { if (!phoneServer) return resolve(); phoneServer.close(() => resolve()); phoneServer = null; });

  const PRO_ONLY = new Set(['/api/dealer', '/api/moneymap', '/api/premflow', '/api/darkpool']);
  const handler = (phone) => async (req, res) => {
    const u = new URL(req.url, 'http://127.0.0.1');
    const p = u.pathname;
    const q = (k) => u.searchParams.get(k);
    try {
      if (phone) { if (!(await phoneGate(req, res, p))) return; }
      // the computer-side API only answers this machine
      else if (p.startsWith('/api/')) {
        const host = (req.headers.host || '').split(':')[0];
        if (host !== '127.0.0.1' && host !== 'localhost') return send(res, 403, { error: 'forbidden' });
      }
      // websites open in your browser can't talk to X-ray: anything not from X-ray's own pages is refused
      if (p.startsWith('/api/')) {
        const org = req.headers.origin, site = req.headers['sec-fetch-site'];
        const own = !org || org === 'http://' + req.headers.host;
        if (!own || site === 'cross-site' || site === 'same-site') return send(res, 403, { error: 'forbidden' });
        // X-ray Pro data is served only to X-ray owners
        if (PRO_ONLY.has(p) && !vip.status().xray) return send(res, 403, { error: 'xray-only', message: 'This is part of X-ray Pro.' });
      }
      if (p === '/api/status') {
        return send(res, 200, { mode: state.mode, phase: state.phase, message: state.message, sources: state.sources || [], tokenStatus: state.tokenStatus, hasKeys: !!(cfg.webull && cfg.webull.appKey), keyHint: cfg.webull && cfg.webull.appKey ? '••••' + String(cfg.webull.appKey).slice(-4) : null, webull: { live: wbLive, error: state.webullError || null }, stats: client ? client.stats : null, schwab: { hasKeys: !!(cfg.schwab && cfg.schwab.appKey), keyHint: cfg.schwab && cfg.schwab.appKey ? '••••' + String(cfg.schwab.appKey).slice(-4) : null, phase: schwabState.phase, message: schwabState.message, live: schwabState.live, loginExpires: schwab ? schwab.loginExpires() : null, stats: schwab ? schwab.stats : null }, version: opts.version || 'dev' });
      }
      if (p === '/api/config' && req.method === 'POST') {
        const b = await readBody(req);
        if (!b.appKey || !b.appSecret) return send(res, 400, { error: 'App Key and App Secret are both required.' });
        cfg.webull = { appKey: String(b.appKey).trim(), appSecret: String(b.appSecret).trim() };
        saveCfg();
        try { fs.unlinkSync(path.join(dataDir, 'webull-token.json')); } catch (e) { /* none */ }
        connectWebull();
        return send(res, 200, { ok: true });
      }
      if (p === '/api/connect' && req.method === 'POST') { connect(); return send(res, 200, { ok: true }); }
      if (p === '/api/schwab/config' && req.method === 'POST') {
        const b = await readBody(req);
        if (!b.appKey || !b.appSecret) return send(res, 400, { error: 'App Key and Secret are both required.' });
        cfg.schwab = { appKey: String(b.appKey).trim(), appSecret: String(b.appSecret).trim() }; saveCfg();
        try { fs.unlinkSync(path.join(dataDir, 'schwab-token.json')); } catch (e) { /* none */ }
        schwab = makeSchwab(); schwabState.live = false; schwabState.phase = 'needs-login'; schwabState.message = 'Keys saved. Click Log in with Schwab.'; rebuild();
        return send(res, 200, { ok: true, authUrl: schwab.authUrl() });
      }
      if (p === '/api/schwab/auth-url') { if (!schwab) schwab = makeSchwab(); if (!schwab) return send(res, 400, { error: 'Save your Schwab App Key and Secret first.' }); return send(res, 200, { url: schwab.authUrl() }); }
      if (p === '/api/schwab/code' && req.method === 'POST') {
        const b = await readBody(req);
        if (!schwab) schwab = makeSchwab();
        if (!schwab) return send(res, 400, { error: 'Save your Schwab App Key and Secret first.' });
        try { await schwab.exchangeCode(b.url); } catch (e) { log('schwab login error: ' + e.message); return send(res, 400, { error: /expired|invalid|grant/i.test(e.message) ? 'That login link expired or was already used. Click Log in with Schwab and paste the new address within 30 seconds.' : e.message }); }
        await connectSchwab();
        return send(res, 200, { ok: schwabState.live, message: schwabState.message });
      }
      if (p === '/api/schwab/forget' && req.method === 'POST') { cfg.schwab = null; saveCfg(); if (schwab) schwab.forget(); schwab = null; schwabState.live = false; schwabState.phase = 'needs-keys'; schwabState.message = 'Schwab keys removed.'; rebuild(); return send(res, 200, { ok: true }); }
      if (p === '/api/disconnect' && req.method === 'POST') {
        state.mode = 'demo'; state.phase = 'idle'; state.message = 'Disconnected. Showing sample data.';
        return send(res, 200, { ok: true });
      }
      if (p === '/api/forget' && req.method === 'POST') {
        cfg.webull = null; saveCfg();
        try { fs.unlinkSync(path.join(dataDir, 'webull-token.json')); } catch (e) { /* none */ }
        wbLive = false; client = null; state.mode = 'demo'; state.phase = 'needs-keys'; state.message = 'Keys removed. Showing sample data.'; rebuild();
        return send(res, 200, { ok: true });
      }
      if (p === '/api/phone' && req.method === 'GET') {
        const pc = phoneCfg(); saveCfg();
        return send(res, 200, { enabled: !!pc.enabled, running: !!phoneServer, pin: pc.pin, port: PHONE_PORT, urls: lanUrls(), error: state.phoneError || null, sessions: (pc.sessions || []).length });
      }
      if (p === '/api/phone' && req.method === 'POST') {
        const b = await readBody(req); const pc = phoneCfg();
        if (b.newPin) { pc.pin = newPin(); pc.sessions = []; }
        if (b.signOutAll) pc.sessions = [];
        if (typeof b.enabled === 'boolean') { pc.enabled = b.enabled; if (b.enabled) await startPhone(); else await stopPhone(); }
        saveCfg();
        return send(res, 200, { ok: true, running: !!phoneServer, error: state.phoneError || null });
      }
      if (p === '/api/quotes') { if (!needLive(res)) return; return send(res, 200, await dm.quotes((q('symbols') || '').split(',').filter(Boolean).slice(0, 80))); }
      if (p === '/api/bars') { if (!needLive(res)) return; return send(res, 200, await dm.bars(q('symbol'), q('tf'))); }
      if (p === '/api/expirations') { if (!needLive(res)) return; return send(res, 200, await dm.expirations(q('symbol'))); }
      if (p === '/api/options') { if (!needLive(res)) return; return send(res, 200, await dm.optionQuotes((q('occ') || '').split(',').filter(Boolean).slice(0, 200))); }
      if (p === '/api/chain') { if (!needLive(res)) return; const list = await dm.chainContracts(q('symbol'), q('exp'), Number(q('pct')) || 0.06); return send(res, 200, list); }
      if (p === '/api/option-bars') { if (!needLive(res)) return; return send(res, 200, await dm.optionBars(q('occ'))); }
      if (p === '/api/gex') { if (!needLive(res)) return; return send(res, 200, await dm.gex(q('symbol'))); }
      if (p === '/api/search') { if (!needLive(res)) return; return send(res, 200, await dm.search((q('q') || '').slice(0, 40))); }
      if (p === '/api/fundamentals') { if (!needLive(res)) return; return send(res, 200, await dm.fundamentals(q('symbol'))); }
      if (p === '/api/catalysts') { try { return send(res, 200, await cal.week((q('watch') || '').split(',').filter(Boolean).slice(0, 40))); } catch (e) { return send(res, 502, { error: e.message }); } }
      if (p === '/api/globe') { try { return send(res, 200, await cal.globe(/\b(beat|beats|surge|surges|jump|jumps|rall(y|ies)|record|upgrade[sd]?|soar|soars|gain[s]?|rise[s]?|strong|bullish|raises?|tops?)\b/i, /\b(miss|misses|fall[s]?|drop[s]?|plunge[s]?|slump[s]?|cut[s]?|downgrade[sd]?|weak|bearish|sink[s]?|tumble[s]?|slide[s]?|war|attack|sanction[s]?)\b/i)); } catch (e) { return send(res, 502, { error: e.message }); } }
      if (p === '/api/tickercat') {
        const sym = String(q('symbol') || '').toUpperCase(); const items = [];
        const nice = (iso) => { const d = new Date(iso + 'T12:00:00Z'); return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', timeZone: 'UTC' }); };
        try { const nx = (await cal.nextEarnings([sym]))[sym]; if (nx) items.push({ title: sym + ' earnings', when: nice(nx.date) + (nx.when === 'AMC' ? ' · after close' : nx.when === 'BMO' ? ' · before open' : '') + (nx.eps ? ' · EPS est ' + nx.eps : ''), tag: 'EARNINGS', date: nx.date }); } catch (e) { /* calendar unavailable */ }
        if (state.mode === 'live' && dm) { try { const f = await dm.fundamentals(sym); const ex = f.nextDivExDate || f.divExDate; if (ex && f.divAmount && ex >= nyDate(Date.now())) items.push({ title: 'Ex-dividend · $' + (f.divAmount / (f.divFreq || 4)).toFixed(2) + ' / share', when: nice(ex) + ((f.nextDivPayDate || f.divPayDate) ? ' · paid ' + nice(f.nextDivPayDate || f.divPayDate) : ''), tag: 'DIVIDEND', date: ex }); } catch (e) { /* no broker fundamentals */ } }
        items.sort((a, b) => (a.date < b.date ? -1 : 1));
        return send(res, 200, { symbol: sym, items });
      }
      if (p === '/api/marketnews') { try { return send(res, 200, await cal.marketNews(q('cat') || 'stock')); } catch (e) { return send(res, 502, { error: e.message }); } }
      if (p === '/api/bigcats') {
        if (bigCache && Date.now() - bigCache.t < 30 * 60000) return send(res, 200, bigCache.v);
        const GROUPS = { TSLA: 'Mag 7', GOOGL: 'Mag 7', MSFT: 'Mag 7', META: 'Mag 7', AAPL: 'Mag 7', AMZN: 'Mag 7', NVDA: 'Mag 7', NFLX: 'Movers', PLTR: 'Movers', AMD: 'Movers', AVGO: 'Movers', MU: 'Movers', COIN: 'Movers', SMCI: 'Movers', JPM: 'Movers', HOOD: 'Movers' };
        try {
          const syms = Object.keys(GROUPS);
          const next = await cal.nextEarnings(syms);
          const today = Date.parse(nyDate(Date.now()) + 'T12:00:00Z');
          const rows = [];
          for (const s0 of syms) {
            const r = next[s0]; if (!r) continue;
            let em = null;
            if (state.mode === 'live' && dm) { try { em = await expectedMove(dm, s0, r.date); } catch (e) { /* no chain */ } }
            rows.push({ sym: s0, name: r.name, ev: (r.quarter ? r.quarter.replace(/\/(\d{2})(\d{2})$/, " '$2").replace('/', ' ') + ' qtr earnings' : 'Quarterly earnings'), date: r.date, when: r.when, days: Math.round((Date.parse(r.date + 'T12:00:00Z') - today) / 86400000), em: em ? em.pct : null, emExp: em ? em.exp : null, grp: GROUPS[s0], eps: r.eps });
          }
          bigCache = { t: Date.now(), v: rows };
          return send(res, 200, rows);
        } catch (e) { return send(res, 502, { error: e.message }); }
      }
      if (p === '/api/premflow') {
        if (!needLive(res)) return;
        const syms = String(q('symbols') || 'SPY,QQQ,SPX,NVDA,TSLA,AAPL').toUpperCase().split(',').map((x) => x.trim()).filter((x) => /^[A-Z.]{1,6}$/.test(x)).slice(0, 8);
        const out = []; const errors = {}; const pending = [];
        // one ticker at a time in the background so the broker's rate limit isn't hammered; each ticker is reused for 2.5 minutes.
        // The UI gets whatever is ready right away and polls until nothing is pending.
        const fresh = (s0) => { const h = pfCache.get(s0); return h && Date.now() - h.t < 270000; };
        const need = syms.filter((s0) => !fresh(s0) && !pfScanning.has(s0));
        if (need.length) {
          need.forEach((s0) => pfScanning.add(s0));
          const run = async () => { for (const s0 of need) { try { const v = await scanTicker(dm, s0); pfCache.set(s0, { t: Date.now(), v }); pfErr.delete(s0); } catch (e) { pfErr.set(s0, e.message); log('premflow ' + s0 + ': ' + e.message); } pfScanning.delete(s0); } };
          pfBusy = pfBusy.then(run, run);
        }
        syms.forEach((s0) => { const h = pfCache.get(s0); if (h) out.push(h.v); if (pfScanning.has(s0)) pending.push(s0); else if (pfErr.has(s0)) errors[s0] = pfErr.get(s0); });
        const rows = [].concat(...out.map((x) => x.rows.slice().sort((a, b) => b.premium - a.premium).slice(0, 80))).sort((a, b) => b.premium - a.premium);
        const tide = { callsBought: 0, putsBought: 0, callsAll: 0, putsAll: 0 };
        rows.forEach((r) => { if (r.type === 'C') { tide.callsAll += r.premium; if (r.lean >= 0.65) tide.callsBought += r.premium; } else { tide.putsAll += r.premium; if (r.lean >= 0.65) tide.putsBought += r.premium; } });
        return send(res, 200, { t: Date.now(), pending, tickers: out.map((x) => ({ sym: x.sym, spot: x.spot, chgPct: x.chgPct, n: x.rows.length, tot: x.tot || null })), errors, tide, rows });
      }
      if (p === '/api/moneymap') {
        if (!needLive(res)) return;
        const sym = String(q('symbol') || '').toUpperCase(), exp = q('exp') || '';
        const key = sym + '|' + exp; const hit = mmCache.get(key);
        if (hit && Date.now() - hit.t < 45000) return send(res, 200, hit.v);
        if (!hit || !hit.p) { const p0 = moneyMap(dm, sym, exp).then((v) => { mmCache.set(key, { t: Date.now(), v }); return v; }).finally(() => { const h = mmCache.get(key); if (h) delete h.p; }); mmCache.set(key, Object.assign({}, hit || {}, { p: p0 })); }
        try { return send(res, 200, await mmCache.get(key).p || mmCache.get(key).v); } catch (e) { mmCache.delete(key); return send(res, 502, { error: e.message }); }
      }
      if (p === '/api/update') return send(res, 200, updater.status());
      if (p === '/api/update/check' && req.method === 'POST') return send(res, 200, await updater.check());
      if (p === '/api/update/restart' && req.method === 'POST') return send(res, 200, { ok: updater.restart() });
      // ---- journal screenshots: saved next to your X-ray data, never uploaded anywhere ----
      if (p === '/api/jmedia' && req.method === 'POST') {
        const org = req.headers.origin; if (org && !/^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/.test(org) && !phone) return send(res, 403, { error: 'forbidden' });
        const ext = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif' }[String(req.headers['content-type'] || '').split(';')[0].trim()];
        if (!ext) return send(res, 415, { error: 'Only pictures (PNG, JPG, WEBP, GIF).' });
        const buf = await new Promise((resolve, reject) => { const ch = []; let n = 0; req.on('data', (c) => { n += c.length; if (n > 10 * 1024 * 1024) { req.destroy(); reject(new Error('big')); } else ch.push(c); }); req.on('end', () => resolve(Buffer.concat(ch))); req.on('error', reject); }).catch(() => null);
        if (!buf) return send(res, 413, { error: 'That picture is over 10 MB.' });
        if (!buf.length) return send(res, 400, { error: 'Empty picture.' });
        const dir = path.join(dataDir, 'journal-media'); fs.mkdirSync(dir, { recursive: true });
        const id = crypto.randomBytes(8).toString('hex') + '.' + ext;
        fs.writeFileSync(path.join(dir, id), buf);
        return send(res, 200, { id });
      }
      if (p.startsWith('/api/jmedia/') && req.method === 'GET') {
        const id = decodeURIComponent(p.slice('/api/jmedia/'.length));
        if (!/^[a-f0-9]{16}\.(png|jpg|webp|gif)$/.test(id)) return send(res, 404, { error: 'not found' });
        const f = path.join(dataDir, 'journal-media', id);
        if (!fs.existsSync(f)) return send(res, 404, { error: 'not found' });
        res.writeHead(200, { 'Content-Type': MIME['.' + id.split('.').pop()] || 'application/octet-stream', 'Cache-Control': 'private, max-age=31536000, immutable', 'X-Content-Type-Options': 'nosniff' });
        return fs.createReadStream(f).pipe(res);
      }
      // ---- voice notes: turn on the computer's own voice typing (Windows: Win+H). Only from this computer. ----
      if (p === '/api/dictate' && req.method === 'POST') {
        const org = req.headers.origin; if (phone || (org && !/^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/.test(org))) return send(res, 403, { error: 'forbidden' });
        if (process.platform !== 'win32') return send(res, 200, { ok: false, how: process.platform === 'darwin' ? 'mac' : 'none' });
        const ps = "Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public class XrK{[DllImport(\"user32.dll\")]public static extern void keybd_event(byte b,byte s,uint f,UIntPtr e);}';[XrK]::keybd_event(0x5B,0,0,[UIntPtr]::Zero);[XrK]::keybd_event(0x48,0,0,[UIntPtr]::Zero);[XrK]::keybd_event(0x48,0,2,[UIntPtr]::Zero);[XrK]::keybd_event(0x5B,0,2,[UIntPtr]::Zero)";
        return require('child_process').execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', Buffer.from(ps, 'utf16le').toString('base64')], { windowsHide: true, timeout: 8000 }, (err) => send(res, 200, { ok: !err, how: 'windows' }));
      }
      if (p === '/api/option-daily') { if (!needLive(res)) return; try { return send(res, 200, await dm.optionDailyBars(q('occ') || '')); } catch (e) { return send(res, e.status || 502, { error: e.message, unsupported: !!e.unsupported }); } }
      if (p === '/api/box') {
        // live: we fetch the contract's daily candles ourselves; sample mode: the UI posts its candles
        const sgq = q('sg'); const sg = sgq === '1' ? true : sgq === '0' ? false : null;
        if (req.method === 'POST') {
          const b = await readBig(req, 3e5).catch(() => null);
          if (!b) return send(res, 413, { error: 'Too many candles' });
          return send(res, 200, await boxFor('sample:' + String(b.key || '').slice(0, 80), Array.isArray(b.days) ? b.days : [], b.shortGamma));
        }
        if (!needLive(res)) return;
        const o = q('occ') || '';
        let days;
        try { days = (await dm.optionDailyBars(o)).days; } catch (e) { return send(res, e.status || 502, { error: e.message, unsupported: !!e.unsupported }); }
        return send(res, 200, await boxFor(o, days, sg));
      }
      if (p === '/api/vip') return send(res, 200, vip.status());
      if (p === '/api/vip/refresh' && req.method === 'POST') return send(res, 200, await vip.refresh());
      if (p === '/api/vip/logout' && req.method === 'POST') return send(res, 200, await vip.logout());
      if (p === '/api/vip/login') {
        const port = Number((req.headers.host || '').split(':')[1]) || 7457;
        return send(res, 200, { url: vip.loginUrl(port) });
      }
      if (p === '/vip/callback' && !phone) {
        let ok = true, msg = 'You can close this tab and go back to X-ray.';
        try {
          const st = await vip.callback(q('session'), q('nonce'));
          msg = st.xray ? 'X-ray Pro is unlocked. Close this tab and go back to X-ray.' : st.inServer === false ? 'You\u2019re signed in, but we couldn\u2019t find you in the Delfi Discord server. Join it, then press Check again in X-ray.' : 'You\u2019re signed in. This Discord account doesn\u2019t have X-ray yet, so you\u2019re on the free version. Discord VIP doesn\u2019t include X-ray, it comes with X-ray or the Bundle.';
        } catch (e) { ok = false; msg = e.message; }
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        return res.end(donePage(ok, msg));
      }
      if (p === '/api/profile') {
        if (req.method === 'POST') {
          const b = await readBig(req, 1.5e6).catch(() => null); if (!b) return send(res, 413, { error: 'Photo is too large' });
          const photo = typeof b.photo === 'string' && /^data:image\/(png|jpeg|webp);base64,/.test(b.photo) && b.photo.length < 400000 ? b.photo : (b.photo === null ? null : (cfg.profile && cfg.profile.photo) || null);
          cfg.profile = { name: String(b.name || '').trim().slice(0, 40), discord: String(b.discord || '').trim().replace(/^@/, '').slice(0, 40), photo, plan: (cfg.profile && cfg.profile.plan) || 'Free', t: Date.now() };
          saveCfg(); return send(res, 200, cfg.profile);
        }
        return send(res, 200, cfg.profile || null);
      }
      if (p === '/api/support/tickets') return send(res, 200, { tickets: support.list(), configured: !!support.destination() });
      if (p === '/api/support/ticket' && req.method === 'POST') {
        try { const b = await readBig(req, 8e6); return send(res, 200, await support.create(b, Object.assign({}, cfg.profile || {}, { plan: vip.status().xray ? 'X-ray Pro' : vip.status().vip ? 'Discord VIP (no X-ray)' : 'Free' }))); } catch (e) { return send(res, e.status || 500, { error: e.message }); }
      }
      if (p === '/api/dealer') {
        if (!needLive(res)) return;
        const sym = String(q('symbol') || 'SPX').toUpperCase().replace(/[^A-Z.^]/g, '').slice(0, 8) || 'SPX';
        const exps = Math.max(1, Math.min(6, Number(q('exps')) || 4));
        const key = sym + '|' + exps; const hit = dlCache.get(key); const ttl = exps <= 2 ? 20000 : 45000;
        if (hit && hit.v && Date.now() - hit.t < ttl) return send(res, 200, hit.v);
        if (!hit || !hit.p) { const p0 = dealerModel(dm, sym, { exps }).then(async (v) => {
          // same flip and max pain as Gamma Core, so the two pages never disagree
          try { const g = await dm.gex(sym); const L = g && g.levels; if (L) { if (Number.isFinite(L.flip)) { v.standard.flip = L.flip; v.signed.flip = L.flip; } if (Number.isFinite(L.maxPain) && v.expiry0) v.expiry0.maxPain = L.maxPain; } } catch (e) { /* keep the dealer model's own numbers */ }
          dlCache.set(key, { t: Date.now(), v }); return v; }); dlCache.set(key, Object.assign({}, hit || {}, { p: p0 })); p0.catch(() => {}).finally(() => { const h = dlCache.get(key); if (h) delete h.p; }); }
        try { const h = dlCache.get(key); return send(res, 200, h.p ? (hit && hit.v ? hit.v : await h.p) : h.v); } catch (e) { dlCache.delete(key); return send(res, 502, { error: e.message }); }
      }
      if (p === '/api/darkpool') {
        const syms = String(q('symbols') || '').toUpperCase().split(',').map((x) => x.trim()).filter((x) => /^[A-Z.]{1,6}$/.test(x)).slice(0, 30);
        try { return send(res, 200, await finra.report(syms)); } catch (e) { return send(res, 502, { error: e.message }); }
      }
      if (p === '/api/econ') {
        // FRED is public: works with or without a broker. VIX9D / VIX1D / VVIX come from Schwab when it's connected.
        const v = fred.snapshot();
        let broker = {};
        if (schwabState.live && schwab) {
          if (volCache && Date.now() - volCache.t < 30 * 60000) broker = volCache.v;
          else {
            for (const [k, list] of [['VIX9D', ['$VIX9D', '$VIX9D.X']], ['VIX1D', ['$VIX1D', '$VIX1D.X']], ['VVIX', ['$VVIX', '$VVIX.X']]]) {
              for (const sym of list) {
                try { const r = await schwab.priceHistory({ symbol: sym, periodType: 'year', period: 1, frequencyType: 'daily', frequency: 1 }); const c = (r && r.candles) || []; if (c.length) { broker[k] = c.map((b) => [b.datetime, b.close]).filter((x) => Number.isFinite(x[1])); break; } } catch (e) { /* try the next spelling */ }
              }
            }
            volCache = { t: Date.now(), v: broker };
          }
        }
        if (dm && !broker.GLD) {
          try { const g = await dm.bars('GLD', '1D'); if (g && g.bars && g.bars.length) broker = Object.assign({}, broker, { GLD: g.bars.map((b) => [b.t, b.c]) }); } catch (e) { /* gold is optional */ }
        }
        return send(res, 200, Object.assign({}, v, { broker }));
      }
      if (p === '/api/financials') { try { return send(res, 200, await sec.financials(q('symbol'))); } catch (e) { return send(res, e.status === 404 || e.status === 400 ? 404 : 502, { error: e.message, code: e.code || null }); } }
      if (p === '/api/news') { if (!dm) dm = new DataManager(null, log); return send(res, 200, await dm.news(q('symbol') || 'SPY', q('name') || '')); }
      if (p.startsWith('/api/')) return send(res, 404, { error: 'not found' });

      // static UI
      let f = p === '/' ? '/index.html' : p;
      const fp = path.normalize(path.join(uiDir, f));
      if (!fp.startsWith(path.normalize(uiDir) + path.sep)) { res.writeHead(403); return res.end(); }
      fs.readFile(fp, (err, buf) => {
        if (err) { res.writeHead(404); return res.end('Not found'); }
        const hdr = { 'Content-Type': MIME[path.extname(fp)] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer' };
        // pages can only load X-ray's own code and only talk to X-ray's own server
        if (/\.html$/.test(fp)) Object.assign(hdr, { 'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https:; font-src 'self' data:; media-src 'self' data: blob:; connect-src 'self'; worker-src 'self' blob:; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'", 'X-Frame-Options': 'DENY' });
        res.writeHead(200, hdr);
        res.end(buf);
      });
    } catch (e) {
      log('api error ' + p + ': ' + e.message);
      send(res, e.status === 401 || e.status === 403 ? 401 : 502, { error: e.message });
    }
  };
  const server = http.createServer(handler(false));

  return new Promise((resolve, reject) => {
    server.on('error', reject);
    server.listen(opts.port || 0, '127.0.0.1', () => {
      const port = server.address().port;
      log('X-ray listening on ' + port);
      // warm the world-news globe and catalysts in the background so those pages open with data already there
      setTimeout(() => ['/api/globe', '/api/catalysts?watch=', '/api/darkpool?symbols=SPY'].forEach((u) => http.get('http://127.0.0.1:' + port + u, (r) => r.resume()).on('error', () => {})), 4000);
      if (cfg.phone && cfg.phone.enabled) startPhone();
      if ((cfg.webull && cfg.webull.appKey) || (cfg.schwab && cfg.schwab.appKey)) connect(); else { state.phase = 'needs-keys'; state.message = 'Add your Webull or Schwab keys to go live.'; }
      resolve({ server, port, url: 'http://127.0.0.1:' + port + '/', state });
    });
  });
}

module.exports = { start };

if (require.main === module) {
  const os = require('os');
  start({ port: Number(process.env.XRAY_PORT) || 7457, dataDir: process.env.XRAY_DATA || path.join(os.homedir(), '.delfai-xray'), uiDir: path.join(__dirname, '..', 'ui'), verbose: true, webullHost: process.env.WEBULL_HOST, webullProtocol: process.env.WEBULL_PROTOCOL, schwabHost: process.env.SCHWAB_HOST, schwabProtocol: process.env.SCHWAB_PROTOCOL, secWwwHost: process.env.SEC_WWW_HOST, secDataHost: process.env.SEC_DATA_HOST, secProtocol: process.env.SEC_PROTOCOL })
    .then((s) => console.log('Open ' + s.url));
}
