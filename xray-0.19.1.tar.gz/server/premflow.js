// Premium flow: where the big money is going in options today, and a read on whether it looks like a real
// directional bet or a hedge. Built from each contract's day totals (volume, open interest, bid/ask, last,
// delta) from the user's own broker. Brokers don't give trade-by-trade prints, so this reads the day's
// footprint per contract, not individual sweeps or blocks.
'use strict';

const INDEXY = new Set(['SPY', 'QQQ', 'IWM', 'DIA', 'SPX', 'NDX', 'RUT', 'XSP', 'TLT', 'HYG', 'XLF', 'SMH']);
const nyDate = (ms) => new Intl.DateTimeFormat('en-CA', { timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(ms));
const dteOf = (exp) => Math.max(0, Math.round((Date.parse(exp + 'T12:00:00Z') - Date.parse(nyDate(Date.now()) + 'T12:00:00Z')) / 86400000));

// read one contract's day: who likely did it and why
function classify(r, ctx) {
  const reasons = []; let hedge = 0, dir = 0;
  const d = Math.abs(r.delta == null ? (r.type === 'C' ? (r.strike <= ctx.spot ? 0.7 : 0.3) : (r.strike >= ctx.spot ? 0.7 : 0.3)) : r.delta);
  const opening = r.oi > 0 ? r.vol / r.oi : 9;
  const lean = r.ask > r.bid && r.last != null ? (r.last - r.bid) / (r.ask - r.bid) : 0.5;
  const otm = r.type === 'C' ? r.strike > ctx.spot : r.strike < ctx.spot;
  // where it traded
  if (lean >= 0.65) { dir += 2; reasons.push('traded near the ask (buyers paying up)'); }
  else if (lean <= 0.35) { dir -= 1; reasons.push('traded near the bid (more likely sold)'); }
  // new money vs old money
  if (opening >= 2) { dir += 2; reasons.push('volume ' + opening.toFixed(1) + 'x open interest (new positions)'); }
  else if (opening >= 1) { dir += 1; reasons.push('volume above open interest'); }
  else { reasons.push('volume below open interest (could be closing or rolling)'); }
  // time and distance
  if (r.dte <= 7 && otm && d >= 0.15 && d <= 0.55) { dir += 2; reasons.push('short-dated and out of the money, a classic directional bet'); }
  if (r.dte <= 1) dir += 1;
  // hedge fingerprints
  if (r.type === 'P' && INDEXY.has(ctx.sym) && r.dte >= 14) { hedge += 3; reasons.push('longer-dated index puts are the most common portfolio hedge'); }
  if (r.type === 'P' && otm && d < 0.15 && r.dte >= 7) { hedge += 2; reasons.push('far out-of-the-money put: crash protection'); }
  if (d >= 0.85) { hedge += 1; reasons.push('deep in the money: acts like stock (stock replacement or a hedge)'); }
  const pair = ctx.pairs[r.exp + '|' + r.strike];
  if (pair && pair.C > 0 && pair.P > 0 && Math.min(pair.C, pair.P) / Math.max(pair.C, pair.P) > 0.6) { hedge += 1; dir -= 2; reasons.push('heavy calls and puts at the same strike: a volatility play, not a direction'); }
  if (ctx.collar[r.exp] && r.type === 'P' && otm) { hedge += 2; reasons.push('matching call selling in the same expiry: looks like a collar'); }
  if (r.type === 'P' && ctx.chgPct > 0.5 && lean <= 0.5 && INDEXY.has(ctx.sym)) { hedge += 1; reasons.push('puts while the market is up: protection, not a bet'); }

  let label, color;
  if (pair && pair.C > 0 && pair.P > 0 && Math.min(pair.C, pair.P) / Math.max(pair.C, pair.P) > 0.6) { label = 'Volatility play'; color = '#A78BFA'; }
  else if (hedge >= 3 && hedge >= dir) { label = 'Likely hedge'; color = '#F0A04B'; }
  else if (lean <= 0.35 && opening < 1) { label = 'Closing / sold'; color = '#8796A3'; }
  else if (d >= 0.85 && r.dte <= 1) { label = 'Expiring ITM / stock-like'; color = '#8796A3'; reasons.push('deep in the money on its last day: usually closing, exercise or a stock-like trade, not a fresh bet'); }
  else if (lean <= 0.35 && opening >= 1.5 && otm) { label = r.type === 'C' ? 'Calls sold to open' : 'Puts sold to open'; color = '#6FA8DC'; reasons.push(r.type === 'C' ? 'sellers opening new calls: they are betting it stays below ' + r.strike : 'sellers opening new puts: they are fine owning it at ' + r.strike + ' (quietly bullish)'); }
  else if (dir >= 5) { label = r.type === 'C' ? 'Bullish bet' : 'Bearish bet'; color = r.type === 'C' ? '#34D399' : '#F2555A'; }
  else if (dir >= 3) { label = r.type === 'C' ? 'Leaning bullish' : 'Leaning bearish'; color = r.type === 'C' ? '#34D399' : '#F2555A'; }
  else { label = 'Unclear'; color = '#8796A3'; }
  const conviction = Math.max(0, Math.min(100, Math.round((dir - hedge) * 11 + 30)));
  return { label, color, conviction, reasons, lean, opening };
}

async function scanTicker(dm, sym) {
  const q = (await dm.quotes([sym]))[sym];
  if (!q || !q.last) throw new Error('No price for ' + sym);
  const rows = [];
  const push = (c, s, exp) => {
    if (!s || !s.volume) return;
    const mid = s.mid != null && s.mid > 0 ? s.mid : s.last; if (!(mid > 0)) return;
    rows.push({ occ: c.occ, sym, exp, dte: dteOf(exp), type: c.type, strike: Number(c.strike), vol: s.volume, oi: s.oi || 0, bid: s.bid || 0, ask: s.ask || 0, last: s.last, mid, delta: s.delta, iv: s.iv, premium: s.volume * mid * 100 });
  };
  // Schwab returns a whole expiry (volume, OI, bid/ask, greeks) in one call: much faster than quoting contract by contract
  const sw = dm.list && dm.list.find((d) => d.name === 'Schwab' && typeof d.chainFor === 'function');
  let swOk = false;
  if (sw) {
    try {
      const ex = await sw.expirations(sym);
      const exps = (ex.expiries || []).slice(0, 4);
      const step = ex.step || 1; const count = Math.max(30, Math.min(200, Math.ceil(q.last * 0.07 / step) * 2 + 4));
      for (const exp of exps) {
        const ch = await sw.chainFor(sym, exp, count, 60000);
        ch.list.filter((c) => c.exp === exp && Math.abs(c.strike - q.last) <= q.last * 0.07).forEach((c) => push(c, c, exp));
      }
      swOk = true;
    } catch (e) { rows.length = 0; }
  }
  const ex = swOk ? { expiries: [] } : await dm.expirations(sym);
  const exps = (ex.expiries || []).slice(0, 4);
  for (const exp of exps) {
    const list = await dm.chainContracts(sym, exp, 0.07);
    if (!list.length) continue;
    const snaps = await dm.optionQuotes(list.map((c) => c.occ), 60000);
    list.forEach((c) => push(c, snaps[c.occ], exp));
  }
  // context: same-strike call/put pairs and possible collars, per expiry
  const pairs = {}, collar = {};
  rows.forEach((r) => { const k = r.exp + '|' + r.strike; pairs[k] = pairs[k] || { C: 0, P: 0 }; pairs[k][r.type] += r.premium; });
  const byExp = {};
  rows.forEach((r) => { byExp[r.exp] = byExp[r.exp] || { soldCalls: 0, boughtPuts: 0 }; const lean = r.ask > r.bid && r.last != null ? (r.last - r.bid) / (r.ask - r.bid) : 0.5; if (r.type === 'C' && r.strike > q.last && lean <= 0.35) byExp[r.exp].soldCalls += r.premium; if (r.type === 'P' && r.strike < q.last && lean >= 0.65) byExp[r.exp].boughtPuts += r.premium; });
  Object.keys(byExp).forEach((e) => { const b = byExp[e]; collar[e] = b.soldCalls > 0 && b.boughtPuts > 0 && Math.min(b.soldCalls, b.boughtPuts) / Math.max(b.soldCalls, b.boughtPuts) > 0.5; });
  const ctx = { sym, spot: q.last, chgPct: q.chgPct || 0, pairs, collar };
  rows.forEach((r) => Object.assign(r, classify(r, ctx)));
  const tot = { callVol: 0, putVol: 0, callPrem: 0, putPrem: 0, callBought: 0, putBought: 0 };
  rows.forEach((r) => { const c = r.type === 'C'; tot[c ? 'callVol' : 'putVol'] += r.vol; tot[c ? 'callPrem' : 'putPrem'] += r.premium; if (r.lean >= 0.65) tot[c ? 'callBought' : 'putBought'] += r.premium; });
  return { sym, spot: q.last, chgPct: q.chgPct || 0, rows, tot };
}

module.exports = { scanTicker, classify };
