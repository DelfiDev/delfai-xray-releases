// Live data manager: caching, normalising Webull responses, SPX handling, option-bar alignment, GEX jobs.
'use strict';
const https = require('https');
const { buildModel, impliedVol, yearsToExpiry } = require('./gex');

const TF = { '1m': 'M1', '5m': 'M5', '15m': 'M15', '1H': 'M60', '4H': 'M240', '1D': 'D', '1W': 'W' };
const TF_COUNT = { '1m': 1000, '5m': 1000, '15m': 800, '1H': 600, '4H': 400, '1D': 500, '1W': 300 };
const INDEX_PROXY = { SPX: { etf: 'SPY', ratio: 10.02, root: 'SPXW' }, NDX: { etf: 'QQQ', ratio: 41.1, root: 'NDXP' } };

const num = (v) => { const x = Number(v); return Number.isFinite(x) ? x : null; };
const unwrap = (r) => {
  if (Array.isArray(r)) return r;
  if (r && typeof r === 'object') {
    for (const k of ['data', 'result', 'list', 'items', 'contracts', 'instruments']) if (Array.isArray(r[k])) return r[k];
  }
  return r ? [r] : [];
};
const toMs = (t) => {
  if (t === null || t === undefined) return null;
  if (typeof t === 'number' || /^\d+$/.test(String(t))) { const n = Number(t); return n < 1e12 ? n * 1000 : n; }
  const p = Date.parse(t);
  return Number.isFinite(p) ? p : null;
};
const nyParts = (ms) => {
  const f = new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false, weekday: 'short' });
  const o = {}; f.formatToParts(new Date(ms)).forEach((p) => { o[p.type] = p.value; });
  return { date: o.year + '-' + o.month + '-' + o.day, h: Number(o.hour) % 24, m: Number(o.minute), wd: o.weekday };
};
// first expiry still worth showing: after 4:15 PM ET today's contracts are done, so the next session's expiry
// becomes "0DTE" (money map, expected move, screener, gamma all move forward with it)
const minExp = (ms) => { const p = nyParts(ms || Date.now()); if (p.h * 60 + p.m < 16 * 60 + 15) return p.date; const d = new Date(Date.parse(p.date + 'T12:00:00Z') + 86400000); return d.toISOString().slice(0, 10); };
const rollDaily = (bars) => {
  const m = new Map();
  (bars || []).forEach((b) => {
    if (!b || b.pad || !b.day) return;
    const d = m.get(b.day);
    if (!d) m.set(b.day, { t: b.t, day: b.day, o: b.o, h: b.h, l: b.l, c: b.c, v: b.v || 0 });
    else { d.h = Math.max(d.h, b.h); d.l = Math.min(d.l, b.l); d.c = b.c; d.v += b.v || 0; }
  });
  return Array.from(m.values()).sort((a, b) => (a.day < b.day ? -1 : 1));
};
const occ = (root, exp, type, strike) => root + exp.slice(2).replace(/-/g, '') + type + String(Math.round(strike * 1000)).padStart(8, '0');
const parseOcc = (s) => {
  const m = /^([A-Z.]+?)(\d{6})([CP])(\d{8})$/.exec(s || '');
  if (!m) return null;
  return { root: m[1], exp: '20' + m[2].slice(0, 2) + '-' + m[2].slice(2, 4) + '-' + m[2].slice(4, 6), type: m[3], strike: Number(m[4]) / 1000 };
};

class DataManager {
  constructor(client, log) {
    this.c = client;
    this.log = log || (() => {});
    this.cache = new Map(); // key -> {t, v, p (promise)}
    this.heat = {}; // sym -> {date, slots:[{slot, values}]}
    this.lastQuote = {};
    this.bad = new Map(); // symbol -> time it was rejected as not existing (skipped for 30 min)
  }
  isBad(x) { const b = this.bad.get(x); if (!b) return false; if (Date.now() > b) { this.bad.delete(x); return false; } return true; }
  markBad(list, ttl) { (list || []).forEach((x) => this.bad.set(x, Date.now() + (ttl || 30 * 60000))); }
  // "417 Invalid Symbol:[A, B]" / "does not exist in the category. [A, B]" -> ['A','B']
  static badList(msg) { const m = /\[([^\]]+)\]/.exec(String(msg || '')); return m && /Invalid Symbol|does not exist/i.test(msg) ? m[1].split(',').map((x) => x.trim()).filter(Boolean) : []; }

  async cached(key, ttl, fn) {
    const e = this.cache.get(key);
    const now = Date.now();
    if (e && e.v !== undefined && now - e.t < ttl) return e.v;
    if (e && e.p) return e.p;
    const p = fn().then((v) => { this.cache.set(key, { t: Date.now(), v }); return v; }).catch((err) => {
      const old = this.cache.get(key);
      this.cache.set(key, { t: old && old.v !== undefined ? old.t : 0, v: old ? old.v : undefined });
      if (old && old.v !== undefined) return old.v;
      throw err;
    });
    this.cache.set(key, Object.assign({}, e || {}, { p }));
    return p;
  }

  // ---------- quotes ----------
  normQuote(s) {
    const last = num(s.price) ?? num(s.close) ?? num(s.last);
    const prev = num(s.pre_close);
    const chgPct = num(s.change_ratio) !== null ? num(s.change_ratio) * (Math.abs(num(s.change_ratio)) < 1.5 ? 100 : 1) : (prev && last ? (last / prev - 1) * 100 : 0);
    return { last, prevClose: prev, chg: num(s.change), chgPct, open: num(s.open), high: num(s.high), low: num(s.low), volume: num(s.volume), bid: num(s.bid), ask: num(s.ask), t: Date.now() };
  }
  async quotes(symbols) {
    const out = {};
    const plain = symbols.filter((s) => /^[A-Z]{1,5}$/.test(s) && !INDEX_PROXY[s]);
    const need = plain.filter((s) => { if (this.isBad(s)) return false; const q = this.lastQuote[s]; return !q || Date.now() - q.t > 2500; });
    for (let i = 0; i < need.length; i += 20) {
      const chunk = need.slice(i, i + 20);
      try {
        const rows = unwrap(await this.c.stockSnapshot(chunk, 'US_STOCK'));
        rows.forEach((r) => { if (r && r.symbol) this.lastQuote[r.symbol] = this.normQuote(r); });
        const missing = chunk.filter((s) => !rows.some((r) => r && r.symbol === s));
        if (missing.length) {
          const rows2 = unwrap(await this.c.stockSnapshot(missing, 'US_ETF').catch(() => []));
          rows2.forEach((r) => { if (r && r.symbol) this.lastQuote[r.symbol] = this.normQuote(r); });
        }
      } catch (e) {
        if (e.status === 401 || e.status === 403) { this.log('quotes: ' + e.message); throw e; }
        // tickers this broker doesn't carry (London, Tokyo, spot gold…): remember for the day instead of retrying every 30 minutes
        const unknown = DataManager.badList ? DataManager.badList(e.message) : [];
        if (unknown.length) { this.markBad(unknown, 12 * 3600000); this.log('quotes: ' + (this.name || 'broker') + ' does not carry ' + unknown.join(', ') + ' (skipping them today)'); }
        else this.log('quotes: ' + e.message);
        // one bad symbol can fail the whole batch: retry one by one so good tickers still load
        const rest = chunk.filter((x) => !this.isBad(x));
        if (unknown.length && rest.length) {
          const r = unwrap(await this.c.stockSnapshot(rest, 'US_STOCK').catch(() => []));
          r.forEach((q) => { if (q && q.symbol) this.lastQuote[q.symbol] = this.normQuote(q); });
          const etfs = rest.filter((x) => !r.some((q) => q && q.symbol === x));
          if (etfs.length) unwrap(await this.c.stockSnapshot(etfs, 'US_ETF').catch(() => [])).forEach((q) => { if (q && q.symbol) this.lastQuote[q.symbol] = this.normQuote(q); });
        } else if (chunk.length > 1) {
          for (const s of chunk) {
            const r1 = unwrap(await this.c.stockSnapshot([s], 'US_STOCK').catch(() => []));
            const r2 = r1.length ? r1 : unwrap(await this.c.stockSnapshot([s], 'US_ETF').catch(() => []));
            r2.forEach((r) => { if (r && r.symbol) this.lastQuote[r.symbol] = this.normQuote(r); });
            if (!r2.length) this.markBad([s], 12 * 3600000);
          }
        }
      }
    }
    plain.forEach((s) => { if (this.lastQuote[s]) out[s] = this.lastQuote[s]; });
    for (const s of symbols.filter((x) => INDEX_PROXY[x])) {
      try { out[s] = await this.indexQuote(s); } catch (e) { this.log('index ' + s + ': ' + e.message); }
    }
    return out;
  }

  // SPX: try Webull directly, else derive from SPXW put/call parity at the money
  async indexQuote(sym) {
    return this.cached('iq:' + sym, 3000, async () => {
      const px = INDEX_PROXY[sym];
      const etfQ = (await this.quotes([px.etf]))[px.etf];
      if (!etfQ || !etfQ.last) throw new Error('No ' + px.etf + ' quote yet');
      let spot = etfQ.last * px.ratio;
      try {
        const ex = await this.expirations(sym);
        const e0 = ex.expiries[0];
        if (e0) {
          const step = ex.step || 5;
          const atm = Math.round(spot / step) * step;
          const ks = [-2, -1, 0, 1, 2].map((i) => atm + i * step);
          const syms = [];
          ks.forEach((k) => { syms.push(occ(px.root, e0, 'C', k), occ(px.root, e0, 'P', k)); });
          const snap = await this.optionQuotes(syms);
          let best = null;
          ks.forEach((k) => {
            const c = snap[occ(px.root, e0, 'C', k)], p = snap[occ(px.root, e0, 'P', k)];
            if (c && p && c.mid > 0 && p.mid > 0) { const d = Math.abs(c.mid - p.mid); if (!best || d < best.d) best = { d, s: k + c.mid - p.mid }; }
          });
          if (best) { spot = best.s; px.ratio = spot / etfQ.last; }
        }
      } catch (e) { this.log('parity: ' + e.message); }
      const prev = etfQ.prevClose ? etfQ.prevClose * px.ratio : null;
      return { last: spot, prevClose: prev, chg: prev ? spot - prev : 0, chgPct: etfQ.chgPct, open: etfQ.open ? etfQ.open * px.ratio : null, high: etfQ.high ? etfQ.high * px.ratio : null, low: etfQ.low ? etfQ.low * px.ratio : null, volume: null, derived: true, t: Date.now() };
    });
  }

  // ---------- stock bars ----------
  async bars(sym, tf) {
    const span = TF[tf];
    if (!span) throw new Error('Unknown timeframe ' + tf);
    const ttl = tf === '1m' ? 4000 : tf === '5m' ? 8000 : tf === '1D' || tf === '1W' ? 60000 : 15000;
    return this.cached('bars:' + sym + ':' + tf, ttl, async () => {
      const px = INDEX_PROXY[sym];
      const s = px ? px.etf : sym;
      let rows = unwrap(await this.c.stockBars([s], span, TF_COUNT[tf], 'US_STOCK'));
      let item = rows.find((r) => r && (r.symbol === s || !r.symbol)) || rows[0];
      let list = item && Array.isArray(item.result) ? item.result : Array.isArray(item && item.bars) ? item.bars : (item && item.time !== undefined ? rows : []);
      if (!list.length) {
        rows = unwrap(await this.c.stockBars([s], span, TF_COUNT[tf], 'US_ETF').catch(() => []));
        item = rows[0];
        list = item && Array.isArray(item.result) ? item.result : [];
      }
      let bars = list.map((b) => ({ t: toMs(b.time !== undefined ? b.time : b.timestamp), o: num(b.open), h: num(b.high), l: num(b.low), c: num(b.close), v: num(b.volume) || 0 }))
        .filter((b) => b.t && b.o !== null && b.c !== null).sort((a, b) => a.t - b.t);
      if (px) {
        const iq = await this.indexQuote(sym).catch(() => null);
        const k = px.ratio;
        bars = bars.map((b) => ({ t: b.t, o: b.o * k, h: b.h * k, l: b.l * k, c: b.c * k, v: b.v }));
        return { bars, derived: px.etf + ' x ' + k.toFixed(3), spot: iq ? iq.last : null };
      }
      return { bars };
    });
  }

  // ---------- option chains ----------
  normContract(r) {
    const sym = r.symbol || r.option_symbol;
    const p = parseOcc(sym);
    const exp = (r.init_exp_date || r.expiration_date || r.expire_date || (p && p.exp) || '').slice(0, 10);
    const type = (r.option_type || '').toUpperCase().startsWith('P') ? 'P' : (r.option_type || '').toUpperCase().startsWith('C') ? 'C' : (p && p.type);
    return { occ: sym, exp, type, strike: num(r.strike_price) ?? (p && p.strike), root: p ? p.root : null };
  }
  async contractsPage(params) {
    const all = [];
    let key = null, guard = 0;
    do {
      const q = Object.assign({}, params);
      if (key) q.pagination_key = key;
      const r = await this.c.optionContracts(q);
      unwrap(r).forEach((x) => { if (x && (x.symbol || x.option_symbol)) all.push(this.normContract(x)); });
      key = r && !Array.isArray(r) ? (r.pagination_key || r.next_pagination_key || null) : null;
    } while (key && ++guard < 20);
    return all.filter((c) => c.occ && c.exp && c.type && c.strike);
  }
  async underlyingSpotGuess(sym) {
    const px = INDEX_PROXY[sym];
    if (px) { const q = (await this.quotes([px.etf]))[px.etf]; return q && q.last ? q.last * px.ratio : null; }
    const q = (await this.quotes([sym]))[sym];
    return q ? q.last : null;
  }
  async expirations(sym) {
    return this.cached('exp:' + sym + ':' + minExp(), 30 * 60000, async () => {
      const spot = await this.underlyingSpotGuess(sym);
      if (!spot) throw new Error('No price for ' + sym);
      const list = await this.contractsPage({ underlying_symbols: sym, strike_price_gte: (spot * 0.985).toFixed(2), strike_price_lte: (spot * 1.015).toFixed(2) });
      const px = INDEX_PROXY[sym];
      const today = minExp();
      const use = list.filter((c) => c.exp >= today && (!px || c.root === px.root));
      const expiries = Array.from(new Set(use.map((c) => c.exp))).sort();
      // strike spacing differs by expiry (weeklies often $1, monthlies $2.50 or $5): pick a spacing whose
      // strikes exist in every near expiry, so the strikes the app lists are real contracts
      const sets = expiries.slice(0, 6).map((e) => new Set(use.filter((c) => c.exp === e).map((c) => +c.strike.toFixed(3))));
      const lo = spot * 0.99, hi = spot * 1.01;
      const fits = (st) => sets.every((S) => { if (!S.size) return true; let any = false; for (let k = Math.ceil(lo / st) * st; k <= hi; k += st) { if (!S.has(+k.toFixed(3))) return false; any = true; } return any; });
      const step = [0.5, 1, 2.5, 5, 10, 25, 50, 100].find(fits) || 5;
      return { expiries, step, root: px ? px.root : sym };
    });
  }
  async chainContracts(sym, exp, pct) {
    return this.cached('cc:' + sym + ':' + exp + ':' + pct, 30 * 60000, async () => {
      const spot = await this.underlyingSpotGuess(sym);
      const list = await this.contractsPage({ underlying_symbols: sym, start_date: exp, strike_price_gte: (spot * (1 - pct)).toFixed(2), strike_price_lte: (spot * (1 + pct)).toFixed(2) });
      return list.filter((c) => c.exp === exp);
    });
  }

  normOpt(s) {
    const bid = num(s.bid), ask = num(s.ask), price = num(s.price);
    const mid = bid !== null && ask !== null && ask > 0 ? (bid + ask) / 2 : price;
    const p = parseOcc(s.symbol);
    return {
      occ: s.symbol, strike: num(s.strike_price) ?? (p && p.strike), type: p ? p.type : null, exp: p ? p.exp : null,
      last: price, bid, ask, mid, open: num(s.open), high: num(s.high), low: num(s.low), prevClose: num(s.pre_close),
      chg: num(s.change), chgPct: num(s.change_ratio) !== null ? num(s.change_ratio) * 100 : null,
      volume: num(s.volume) || 0, oi: num(s.open_interest) || 0,
      iv: num(s.imp_vol), delta: num(s.delta), gamma: num(s.gamma), theta: num(s.theta), vega: num(s.vega), rho: num(s.rho), t: Date.now()
    };
  }
  async optionQuotes(occs, ttl) {
    ttl = ttl || 2500;
    this.opt = this.opt || {};
    const out = {};
    const need = occs.filter((o) => { if (this.isBad(o)) return false; const q = this.opt[o]; return !q || Date.now() - q.t > ttl; });
    const chunks = [];
    for (let i = 0; i < need.length; i += 20) chunks.push(need.slice(i, i + 20));
    for (let chunk of chunks) {
      for (let attempt = 0; attempt < 3 && chunk.length; attempt++) {
        try {
          unwrap(await this.c.optionSnapshot(chunk)).forEach((r) => { if (r && r.symbol) this.opt[r.symbol] = this.normOpt(r); });
          break;
        } catch (e) {
          if (e.status === 401 || e.status === 403) throw e;
          const badOnes = DataManager.badList(e.message);
          if (!badOnes.length) { this.log('optionQuotes: ' + e.message); break; }
          // one contract that doesn't exist fails the whole batch: drop it and ask again for the rest
          this.markBad(badOnes);
          chunk = chunk.filter((o) => !badOnes.includes(o));
        }
      }
    }
    occs.forEach((o) => { if (this.opt[o]) out[o] = this.opt[o]; });
    return out;
  }

  // 5-minute option bars aligned to 78 regular-session slots per day (09:30-15:55 ET)
  async optionBars(o) {
    if (this.isBad(o)) { const e = new Error(o + ' is not a listed contract'); e.status = 404; throw e; }
    return this.cached('ob:' + o, 15000, async () => {
      let rows;
      try { rows = unwrap(await this.c.optionBars([o], 'M5', 1200)); } catch (e) { if (DataManager.badList(e.message).length) { this.markBad([o]); e.status = 404; } throw e; }
      const item = rows.find((r) => r && r.symbol === o) || rows[0];
      const list = item && Array.isArray(item.result) ? item.result : (item && item.time !== undefined ? rows : []);
      const raw = list.map((b) => ({ t: toMs(b.time), o: num(b.open), h: num(b.high), l: num(b.low), c: num(b.close), v: num(b.volume) || 0 })).filter((b) => b.t && b.c !== null).sort((a, b) => a.t - b.t);
      const byDay = new Map();
      raw.forEach((b) => {
        const p = nyParts(b.t);
        const slot = Math.floor(((p.h * 60 + p.m) - 570) / 5);
        if (slot < 0 || slot >= 78) return;
        if (!byDay.has(p.date)) byDay.set(p.date, new Array(78).fill(null));
        byDay.get(p.date)[slot] = b;
      });
      const days = Array.from(byDay.keys()).sort();
      const today = nyParts(Date.now()).date;
      const out = [];
      let prevC = null;
      days.forEach((d) => {
        const slots = byDay.get(d);
        let lastIdx = 77;
        if (d === today) { lastIdx = -1; slots.forEach((b, i) => { if (b) lastIdx = i; }); }
        const [Y, M, D] = d.split('-').map(Number);
        for (let i = 0; i <= lastIdx; i++) {
          let b = slots[i];
          const tSlot = Date.UTC(Y, M - 1, D, 13, 30) + i * 300000; // label only; ET formatting happens in the UI
          if (!b) { const c = prevC !== null ? prevC : (slots.find((x) => x) || {}).o; if (c === undefined || c === null) continue; b = { t: tSlot, o: c, h: c, l: c, c, v: 0, pad: true }; }
          out.push({ t: b.t, o: b.o, h: b.h, l: b.l, c: b.c, v: b.v, day: d, slot: i, pad: !!b.pad });
          prevC = b.c;
        }
      });
      return { bars: out, days: days.length };
    });
  }

  // daily candles for the box: Webull daily history (goes back to when the contract listed),
  // with today's candle built live from the 5m bars so it never lags
  async optionDailyBars(o) {
    if (this.isBad(o)) { const e = new Error(o + ' is not a listed contract'); e.status = 404; throw e; }
    return this.cached('od:' + o, 60000, async () => {
      let out = [];
      try {
        const rows = unwrap(await this.c.optionBars([o], 'D', 300));
        const item = rows.find((r) => r && r.symbol === o) || rows[0];
        const list = item && Array.isArray(item.result) ? item.result : (item && item.time !== undefined ? rows : []);
        out = list.map((b) => ({ t: toMs(b.time), o: num(b.open), h: num(b.high), l: num(b.low), c: num(b.close), v: num(b.volume) || 0 }))
          .filter((b) => b.t && b.c !== null && b.o !== null).map((b) => Object.assign(b, { day: nyParts(b.t).date }));
      } catch (e) { /* no daily history: the 5m roll-up below covers the last few weeks */ }
      try {
        const live = rollDaily((await this.optionBars(o)).bars);
        const byDay = new Map(out.map((d) => [d.day, d]));
        live.forEach((d, i) => { if (!byDay.has(d.day) || i === live.length - 1) byDay.set(d.day, d); });
        out = Array.from(byDay.values());
      } catch (e) { if (!out.length) throw e; }
      out.sort((a, b) => (a.day < b.day ? -1 : a.day > b.day ? 1 : 0));
      return { days: out };
    });
  }

  // ---------- gamma model ----------
  async gex(sym) {
    return this.cached('gex:' + sym, 60000, async () => {
      const q = (await this.quotes([sym]))[sym];
      if (!q || !q.last) throw new Error('No price for ' + sym);
      const spot = q.last;
      const ex = await this.expirations(sym);
      const exps = ex.expiries.filter((e) => yearsToExpiry(e) * 365 <= 50).slice(0, 6);
      if (!exps.length) throw new Error('No expirations found for ' + sym);
      const contracts = [];
      for (let i = 0; i < exps.length; i++) {
        const pct = INDEX_PROXY[sym] ? (i < 2 ? 0.05 : 0.07) : (i < 2 ? 0.08 : 0.12);
        const list = await this.chainContracts(sym, exps[i], pct);
        const px = INDEX_PROXY[sym];
        const use = list.filter((c) => !px || c.root === px.root || (c.root === sym && i >= 2));
        const snap = await this.optionQuotes(use.map((c) => c.occ), i < 2 ? 45000 : 180000);
        use.forEach((c) => {
          const s = snap[c.occ];
          if (!s) return;
          contracts.push({ strike: c.strike, type: c.type, exp: c.exp, oi: s.oi, iv: s.iv, gamma: s.gamma, delta: s.delta, mid: s.mid });
        });
      }
      const now = Date.now();
      const p = nyParts(now);
      const minutes = p.h * 60 + p.m - 570;
      const curSlot = Math.max(0, Math.min(13, Math.floor(minutes / 30)));
      const model = buildModel(spot, contracts, exps, { step: ex.step, curSlot, heatSlots: (this.heat[sym] && this.heat[sym].date === p.date) ? this.heat[sym].slots : [] });
      if (minutes >= 0 && minutes <= 390 && !/Sat|Sun/.test(p.wd)) {
        if (!this.heat[sym] || this.heat[sym].date !== p.date) this.heat[sym] = { date: p.date, slots: [] };
        const values = {};
        model.strikes.forEach((K, i) => { values[K] = model.nowVals[i]; });
        const slots = this.heat[sym].slots.filter((h) => h.slot !== curSlot);
        slots.push({ slot: curSlot, values });
        this.heat[sym].slots = slots;
      }
      model.expiries = exps;
      model.contracts = contracts.length;
      return model;
    });
  }

  // ---------- news (Yahoo Finance RSS, Google News RSS as a backup; both free) ----------
  rss(url, src) {
    return new Promise((resolve, reject) => {
      https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36' }, timeout: 10000 }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) { res.resume(); return resolve(this.rss(new URL(res.headers.location, url).toString(), src)); }
        let d = ''; res.on('data', (c) => { d += c; });
        res.on('end', () => {
          if (res.statusCode !== 200) return reject(new Error(src + ' news HTTP ' + res.statusCode));
          const dec = (x) => (x || '').replace(/<!\[CDATA\[|\]\]>/g, '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').trim();
          const items = [];
          (d.match(/<item>[\s\S]*?<\/item>/g) || []).slice(0, 15).forEach((it) => {
            const g = (tag) => { const m = new RegExp('<' + tag + '[^>]*>([\\s\\S]*?)</' + tag + '>').exec(it); return m ? dec(m[1]) : ''; };
            const outlet = g('source');
            let title = g('title'); if (outlet && title.endsWith(' - ' + outlet)) title = title.slice(0, -(outlet.length + 3));
            items.push({ title, link: g('link'), time: Date.parse(g('pubDate')) || null, src: outlet || src });
          });
          resolve(items);
        });
      }).on('error', reject).on('timeout', function () { this.destroy(new Error('news timeout')); });
    });
  }
  news(sym, name) {
    const s = sym === 'SPX' ? '^GSPC' : sym;
    // company stocks: only keep headlines that are actually about this company (Yahoo mixes in related tickers)
    const word = String(name || '').replace(/[.,()]/g, ' ').split(/\s+/).find((w) => w.length > 2 && !/^(the|inc|corp|corporation|co|company|holdings?|group|ltd|plc|class|technologies|platforms)$/i.test(w)) || '';
    const esc = (x) => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const about = name ? new RegExp('(^|[^A-Za-z])(' + esc(sym) + ')([^A-Za-z]|$)' + (word ? '|' + esc(word) : ''), word ? 'i' : '') : null;
    const symRe = new RegExp('(^|[^A-Za-z])' + esc(sym) + '([^A-Za-z]|$)');
    const isAbout = (t) => !about || symRe.test(t) || (word && new RegExp(esc(word), 'i').test(t));
    return this.cached('news:' + s + (name ? ':n' : ''), 5 * 60000, async () => {
      let items = [];
      try { items = await this.rss('https://feeds.finance.yahoo.com/rss/2.0/headline?s=' + encodeURIComponent(s) + '&region=US&lang=en-US', 'Yahoo Finance'); } catch (e) { this.log('yahoo news ' + s + ': ' + e.message); }
      items = items.filter((x) => x.title && isAbout(x.title));
      if (items.length < 3) {
        const q = sym === 'SPX' ? 'S&P 500 stock market' : (word ? word + ' ' : '') + sym + ' stock';
        try { items = items.concat((await this.rss('https://news.google.com/rss/search?q=' + encodeURIComponent(q) + '&hl=en-US&gl=US&ceid=US:en', 'Google News')).filter((x) => x.title && isAbout(x.title))); } catch (e) { this.log('google news ' + s + ': ' + e.message); }
      }
      const seen = new Set();
      return items.filter((x) => x.title && !seen.has(x.title) && seen.add(x.title)).sort((a, b) => (b.time || 0) - (a.time || 0)).slice(0, 12);
    });
  }
}

module.exports = { DataManager, occ, parseOcc, nyParts, minExp, unwrap, toMs };
