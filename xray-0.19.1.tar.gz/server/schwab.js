// Schwab Trader API client (individual developer app). OAuth 2 authorization-code flow with the
// callback https://127.0.0.1 : the user signs in on schwab.com, then pastes the redirected address back.
// Access tokens last ~30 minutes and are refreshed automatically; the refresh token lasts 7 days.
'use strict';
const https = require('https');
const http = require('http');
const fs = require('fs');

const CALLBACK = 'https://127.0.0.1';
const DAY = 86400000;

class SchwabClient {
  constructor(opts) {
    this.appKey = opts.appKey;
    this.appSecret = opts.appSecret;
    const hostOpt = opts.host || 'api.schwabapi.com';
    const [host, port] = hostOpt.split(':');
    this.host = host; this.port = port ? Number(port) : null;
    this.protocol = opts.protocol || 'https';
    this.tokenFile = opts.tokenFile || null;
    this.log = opts.log || (() => {});
    this.tok = null; // {access_token, refresh_token, access_expires, refresh_expires}
    this.queue = []; this.active = 0; this.maxConcurrent = 2; this.minGapMs = 450; this.lastStart = 0; this.cooldownUntil = 0;
    this.stats = { ok: 0, err: 0, last: null, lastError: null };
    if (this.tokenFile) { this.tok = require('./vault').readJSON(this.tokenFile); }
  }

  authUrl() { return 'https://api.schwabapi.com/v1/oauth/authorize?client_id=' + encodeURIComponent(this.appKey) + '&redirect_uri=' + encodeURIComponent(CALLBACK); }
  saveTok() { if (this.tokenFile) require('./vault').writeJSON(this.tokenFile, this.tok); }
  hasLogin() { return !!(this.tok && this.tok.refresh_token && this.tok.refresh_expires > Date.now()); }
  loginExpires() { return this.tok && this.tok.refresh_expires ? this.tok.refresh_expires : null; }
  forget() { this.tok = null; if (this.tokenFile) { try { fs.unlinkSync(this.tokenFile); } catch (e) { /* none */ } } }

  raw(method, path, headers, body) {
    return new Promise((resolve, reject) => {
      const lib = this.protocol === 'http' ? http : https;
      const req = lib.request({ method, host: this.host, port: this.port || undefined, path, headers, timeout: 15000 }, (res) => {
        let d = ''; res.on('data', (c) => { d += c; });
        res.on('end', () => {
          let j = null; try { j = d ? JSON.parse(d) : null; } catch (e) { j = null; }
          if (res.statusCode >= 200 && res.statusCode < 300) return resolve(j);
          const msg = (j && (j.error_description || j.message || (j.errors && j.errors[0] && (j.errors[0].detail || j.errors[0].title)) || j.error)) || ('HTTP ' + res.statusCode);
          const e = new Error('Schwab: ' + msg); e.status = res.statusCode; reject(e);
        });
      });
      req.on('timeout', () => req.destroy(new Error('Schwab request timed out')));
      req.on('error', reject);
      if (body) req.write(body);
      req.end();
    });
  }

  async tokenCall(form) {
    const basic = Buffer.from(this.appKey + ':' + this.appSecret).toString('base64');
    const body = new URLSearchParams(form).toString();
    const j = await this.raw('POST', '/v1/oauth/token', { Authorization: 'Basic ' + basic, 'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': Buffer.byteLength(body) }, body);
    if (!j || !j.access_token) throw new Error('Schwab did not return a token');
    const now = Date.now();
    const keepRefreshExp = form.grant_type === 'refresh_token' && this.tok ? this.tok.refresh_expires : now + 7 * DAY - 60000;
    this.tok = {
      access_token: j.access_token,
      refresh_token: j.refresh_token || (this.tok && this.tok.refresh_token),
      access_expires: now + ((Number(j.expires_in) || 1800) - 60) * 1000,
      refresh_expires: (j.refresh_token && form.grant_type === 'authorization_code') ? now + 7 * DAY - 60000 : keepRefreshExp
    };
    this.saveTok();
    return this.tok;
  }

  // the pasted value is the whole redirected address (https://127.0.0.1/?code=...%40&session=...) or just the code
  static codeFrom(pasted) {
    const s = String(pasted || '').trim();
    let code = s;
    const m = /[?&]code=([^&#\s]+)/.exec(s);
    if (m) code = m[1];
    try { code = decodeURIComponent(code); } catch (e) { /* keep as is */ }
    return code;
  }
  async exchangeCode(pasted) {
    const code = SchwabClient.codeFrom(pasted);
    if (!code || code.length < 10) throw new Error('That address has no login code in it. Copy the whole address from the browser bar after signing in.');
    return this.tokenCall({ grant_type: 'authorization_code', code, redirect_uri: CALLBACK });
  }
  async accessToken() {
    if (!this.tok || !this.tok.refresh_token) { const e = new Error('Log in with Schwab first.'); e.status = 401; throw e; }
    if (this.tok.refresh_expires && this.tok.refresh_expires < Date.now()) { const e = new Error('Your Schwab login expired (Schwab requires a new login every 7 days). Click Log in with Schwab.'); e.status = 401; throw e; }
    if (this.tok.access_token && this.tok.access_expires > Date.now()) return this.tok.access_token;
    if (!this._refreshing) this._refreshing = this.tokenCall({ grant_type: 'refresh_token', refresh_token: this.tok.refresh_token }).catch((e) => {
      if (e.status === 400 || e.status === 401) { this.tok.refresh_expires = 0; this.saveTok(); const e2 = new Error('Schwab ended your login. Click Log in with Schwab to reconnect.'); e2.status = 401; throw e2; }
      throw e;
    }).finally(() => { this._refreshing = null; });
    await this._refreshing;
    return this.tok.access_token;
  }

  // queued GET against the market data API (Schwab allows about 120 requests a minute)
  get(path, query) {
    return new Promise((resolve, reject) => { this.queue.push({ path, query, resolve, reject }); this.pump(); });
  }
  pump() {
    if (this.active >= this.maxConcurrent || !this.queue.length) return;
    const wait = Math.max(this.lastStart + this.minGapMs, this.cooldownUntil) - Date.now();
    if (wait > 0) { if (!this._t) this._t = setTimeout(() => { this._t = null; this.pump(); }, wait); return; }
    const job = this.queue.shift();
    this.active++; this.lastStart = Date.now();
    this.run(job).then(job.resolve, job.reject).finally(() => { this.active--; this.pump(); });
    this.pump();
  }
  async run(job, retried) {
    const qs = new URLSearchParams();
    Object.keys(job.query || {}).forEach((k) => { if (job.query[k] !== undefined && job.query[k] !== null) qs.set(k, String(job.query[k])); });
    const full = '/marketdata/v1' + job.path + (qs.toString() ? '?' + qs.toString() : '');
    try {
      const at = await this.accessToken();
      const r = await this.raw('GET', full, { Authorization: 'Bearer ' + at, Accept: 'application/json' });
      this.stats.ok++; this.stats.last = Date.now();
      return r;
    } catch (e) {
      this.stats.err++; this.stats.lastError = e.message;
      if (e.status === 429) { this.cooldownUntil = Date.now() + 5000; if (!retried) return this.run(job, true); }
      if (e.status === 401 && !retried && this.tok && this.tok.refresh_token) { this.tok.access_expires = 0; return this.run(job, true); }
      throw e;
    }
  }

  quotes(symbols, fields) { return this.get('/quotes', { symbols: symbols.join(','), fields: fields || 'quote,fundamental', indicative: 'false' }); }
  priceHistory(q) { return this.get('/pricehistory', q); }
  chains(q) { return this.get('/chains', q); }
  expirationChain(symbol) { return this.get('/expirationchain', { symbol }); }
  instruments(symbol, projection) { return this.get('/instruments', { symbol, projection }); }
}

module.exports = { SchwabClient, CALLBACK };
