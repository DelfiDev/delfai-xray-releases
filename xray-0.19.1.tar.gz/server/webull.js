// Webull OpenAPI client (US). Signing mirrors the official webull-openapi-python-sdk 3.x:
// HMAC-SHA256 over "path&k=v&..." (sorted, lower-cased sign headers + query params) + "&SHA256(body)",
// whole string percent-encoded, key = appSecret + "&".
'use strict';
const crypto = require('crypto');
const https = require('https');
const http = require('http');
const fs = require('fs');

const pyQuote = (s) => encodeURIComponent(s).replace(/[!'()*]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase());
const isoNoMillis = () => new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');

class WebullClient {
  constructor(opts) {
    this.appKey = opts.appKey;
    this.appSecret = opts.appSecret;
    this.host = opts.host || 'api.webull.com';
    this.protocol = opts.protocol || 'https';
    this.port = opts.port || null;
    this.tokenFile = opts.tokenFile || null;
    this.log = opts.log || (() => {});
    this.token = null;
    this.tokenStatus = 'NONE';
    this.tokenExpires = null;
    this.queue = [];
    this.active = 0;
    this.maxConcurrent = 3;
    this.minGapMs = 120; // ~8 requests / second
    this.lastStart = 0;
    this.cooldownUntil = 0;
    this.stats = { ok: 0, err: 0, last: null, lastError: null };
    if (this.tokenFile) this.loadToken();
  }

  // ---------- signing ----------
  signHeaders(path, query, body) {
    const fx = this._fixed || {};
    const nonce = fx.nonce || crypto.randomUUID();
    const signHeaders = {
      'x-app-key': this.appKey,
      'x-timestamp': fx.ts || isoNoMillis(),
      'x-signature-version': '1.0',
      'x-signature-algorithm': 'HMAC-SHA256',
      'x-signature-nonce': nonce
    };
    const params = {};
    Object.keys(signHeaders).forEach((k) => { params[k.toLowerCase()] = signHeaders[k]; });
    params.host = this.host + (this.port ? ':' + this.port : '');
    Object.keys(query || {}).forEach((k) => {
      const v = String(query[k]);
      params[k] = params[k] !== undefined ? params[k] + '&' + v : v;
    });
    let s = path + '&' + Object.keys(params).sort().map((k) => k + '=' + params[k]).join('&');
    if (body !== undefined && body !== null) {
      const raw = JSON.stringify(body);
      s += '&' + crypto.createHash('sha256').update(raw, 'utf8').digest('hex').toUpperCase();
    }
    const toSign = pyQuote(s);
    const signature = crypto.createHmac('sha256', this.appSecret + '&').update(toSign, 'utf8').digest('base64');
    return Object.assign({}, signHeaders, { 'x-signature': signature });
  }

  // ---------- transport ----------
  rawRequest(method, path, query, body) {
    return new Promise((resolve, reject) => {
      const headers = this.signHeaders(path, query, body);
      headers['x-version'] = 'v3';
      headers['User-Agent'] = 'DELFAi-Xray/0.1 (personal)';
      headers['Accept'] = 'application/json';
      if (this.token) headers['x-access-token'] = this.token;
      let payload = null;
      if (body !== undefined && body !== null) {
        payload = Buffer.from(JSON.stringify(body), 'utf8');
        headers['Content-Type'] = 'application/json';
        headers['Content-Length'] = payload.length;
      }
      const qs = Object.keys(query || {}).map((k) => encodeURIComponent(k) + '=' + encodeURIComponent(String(query[k]))).join('&');
      const lib = this.protocol === 'http' ? http : https;
      const req = lib.request({ host: this.host, port: this.port || undefined, method, path: path + (qs ? '?' + qs : ''), headers, timeout: 15000 }, (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const text = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = text ? JSON.parse(text) : null; } catch (e) { json = null; }
          resolve({ status: res.statusCode, json, text });
        });
      });
      req.on('timeout', () => { req.destroy(new Error('Request timed out')); });
      req.on('error', reject);
      if (payload) req.write(payload);
      req.end();
    });
  }

  request(method, path, query, body) {
    return new Promise((resolve, reject) => {
      // charts and quotes first, option snapshots last, so a busy options chain never stalls the chart
      const pri = /\/stocks\//.test(path) ? 0 : /\/options\/bars/.test(path) ? 1 : /\/options\/snapshots/.test(path) ? 3 : 2;
      const job = { method, path, query, body, resolve, reject, tries: 0, pri };
      let i = this.queue.length; while (i > 0 && this.queue[i - 1].pri > pri) i--;
      this.queue.splice(i, 0, job);
      this.pump();
    });
  }

  pump() {
    if (!this.queue.length || this.active >= this.maxConcurrent) return;
    const now = Date.now();
    const wait = Math.max(this.cooldownUntil - now, this.lastStart + this.minGapMs - now);
    if (wait > 0) { if (!this._timer) this._timer = setTimeout(() => { this._timer = null; this.pump(); }, wait); return; }
    const job = this.queue.shift();
    this.active++;
    this.lastStart = Date.now();
    this.rawRequest(job.method, job.path, job.query, job.body).then((r) => {
      this.active--;
      if ((r.status === 429 || r.status >= 500) && job.tries < 3) {
        job.tries++;
        if (r.status === 429) this.cooldownUntil = Date.now() + 1500 * job.tries;
        this.queue.unshift(job);
      } else if (r.status >= 200 && r.status < 300) {
        this.stats.ok++; this.stats.last = Date.now();
        job.resolve(r.json);
      } else {
        this.stats.err++;
        const msg = (r.json && (r.json.message || r.json.msg || r.json.error_msg || r.json.error_code)) || r.text || ('HTTP ' + r.status);
        this.stats.lastError = r.status + ' ' + String(msg).slice(0, 200) + ' (' + job.path + ')';
        const err = new Error(this.stats.lastError);
        err.status = r.status;
        job.reject(err);
      }
      this.pump();
    }).catch((e) => {
      this.active--;
      if (job.tries < 2) { job.tries++; this.queue.push(job); } else { this.stats.err++; this.stats.lastError = e.message; job.reject(e); }
      this.pump();
    });
    this.pump();
  }

  // ---------- access token (2FA approval in the Webull app) ----------
  loadToken() {
    try {
      const t = require('./vault').readJSON(this.tokenFile); if (!t) throw new Error('no token');
      if (t && t.token && t.appKey === this.appKey) { this.token = t.token; this.tokenStatus = t.status || 'NORMAL'; this.tokenExpires = t.expires || null; }
    } catch (e) { /* none yet */ }
  }
  saveToken() {
    if (!this.tokenFile) return;
    try { require('./vault').writeJSON(this.tokenFile, { appKey: this.appKey, token: this.token, status: this.tokenStatus, expires: this.tokenExpires }); } catch (e) { this.log('token save failed: ' + e.message); }
  }
  async tokenRequired() {
    const cfg = await this.request('GET', '/openapi/config', {});
    return !!(cfg && cfg.token_check_enabled);
  }
  // Returns { status: 'NORMAL'|'PENDING'|'NOT_REQUIRED'|..., message }
  async ensureToken(onUpdate) {
    const required = await this.tokenRequired();
    if (!required) { this.tokenStatus = 'NOT_REQUIRED'; return { status: 'NOT_REQUIRED' }; }
    if (this.token && this.tokenStatus === 'NORMAL') {
      try {
        const chk = await this.request('POST', '/auth/tokens/check', null, { token: this.token });
        if (chk && chk.status === 'NORMAL') { this.tokenExpires = chk.expires || this.tokenExpires; this.saveToken(); return { status: 'NORMAL' }; }
      } catch (e) { this.log('token check failed: ' + e.message); }
    }
    const body = this.token ? { token: this.token } : {};
    const created = await this.request('POST', '/auth/tokens/create', null, body);
    if (!created || !created.token) throw new Error('Webull did not return an access token.');
    this.token = created.token; this.tokenStatus = created.status; this.tokenExpires = created.expires || null;
    this.saveToken();
    if (onUpdate) onUpdate({ status: this.tokenStatus });
    const started = Date.now();
    while (this.tokenStatus !== 'NORMAL') {
      if (this.tokenStatus === 'INVALID' || this.tokenStatus === 'EXPIRED') throw new Error('Webull access token was ' + this.tokenStatus.toLowerCase() + '. Try connecting again.');
      if (Date.now() - started > 5 * 60 * 1000) throw new Error('Timed out waiting for approval in the Webull app.');
      await new Promise((r) => setTimeout(r, 5000));
      const chk = await this.request('POST', '/auth/tokens/check', null, { token: this.token });
      if (chk && chk.status) { this.tokenStatus = chk.status; this.tokenExpires = chk.expires || this.tokenExpires; this.saveToken(); if (onUpdate) onUpdate({ status: this.tokenStatus }); }
    }
    return { status: 'NORMAL' };
  }

  // ---------- market data ----------
  stockSnapshot(symbols, category) {
    return this.request('GET', '/market-data/stocks/snapshots/list', { symbols: symbols.join(','), category: category || 'US_STOCK' });
  }
  stockBars(symbols, timespan, count, category) {
    return this.request('POST', '/market-data/stocks/bars/list', null, { symbols, category: category || 'US_STOCK', timespan, count: String(count || 200) });
  }
  optionContracts(params) {
    return this.request('GET', '/trading/instruments/options/contracts/list', Object.assign({ category: 'US_OPTION' }, params));
  }
  optionSnapshot(occSymbols) {
    return this.request('GET', '/market-data/options/snapshots/list', { symbols: occSymbols.join(','), category: 'US_OPTION' });
  }
  optionBars(occSymbols, timespan, count) {
    return this.request('GET', '/market-data/options/bars/list', { symbols: occSymbols.join(','), category: 'US_OPTION', timespan, count: String(count || 200) });
  }
}

module.exports = { WebullClient, pyQuote };
