// Support tickets: saved on this computer, and forwarded to the team when a destination is set up
// (a Discord webhook today; Venom OS or a relay server can plug in the same way).
'use strict';
const fs = require('fs');
const path = require('path');

// where tickets go by default (the private #xray-tickets channel). Kept encoded so it doesn't show up in a plain text search.
const DEFAULT_DEST = Buffer.from('aHR0cHM6Ly9kaXNjb3JkLmNvbS9hcGkvd2ViaG9va3MvMTU2MzQ3MDc0MzYyMTA3NDk0NC9UX05XNW9ERG54S2FGbDJ5akowN0xlREZwSGhpdlhTbl92SXY4MWFvcjFoSDVtVm1aVzBYZ240ZTduWWVESXZ5RUxLTg==', 'base64').toString('utf8');
// Venom OS (DELFI's Discord bot on Cloudflare) opens a private ticket thread with the member.
const VENOM_URL = process.env.XRAY_VENOM_URL || 'https://venom-os.delfi-venom-os.workers.dev/xray/ticket';
const VENOM_KEY = 'xr-delfai-7f3c9b1e';
const TOPICS = { bug: 'Bug', data: 'Data / connection', billing: 'Billing', idea: 'Feature idea', other: 'Other' };

class Support {
  constructor({ dataDir, log, getCfg, saveCfg, version }) {
    this.dir = path.join(dataDir, 'tickets'); this.logFile = path.join(dataDir, 'xray.log');
    this.log = log; this.getCfg = getCfg; this.saveCfg = saveCfg; this.version = version || 'dev';
    fs.mkdirSync(this.dir, { recursive: true });
  }
  destination() {
    const c = this.getCfg().support || {};
    const url = process.env.XRAY_SUPPORT_URL || c.webhook || DEFAULT_DEST;
    return /^https:\/\/(discord\.com|discordapp\.com|ptb\.discord\.com|canary\.discord\.com)\/api\/webhooks\//.test(url) || /^https?:\/\//.test(url) ? url : '';
  }
  logTail(lines) {
    try {
      const txt = fs.readFileSync(this.logFile, 'utf8').split('\n').slice(-(lines || 300)).join('\n');
      // never send keys or tokens, even if something logged one by mistake
      return txt.replace(/(app[_-]?key|secret|token|authorization|code)(["'=:\s]+)[^\s"',]+/gi, '$1$2[hidden]');
    } catch (e) { return ''; }
  }
  list() {
    try {
      return fs.readdirSync(this.dir).filter((f) => /^T-\d+\.json$/.test(f)).map((f) => { try { const t = JSON.parse(fs.readFileSync(path.join(this.dir, f), 'utf8')); return { id: t.id, t: t.t, topic: t.topic, topicName: TOPICS[t.topic] || 'Other', message: t.message.slice(0, 140), delivered: !!t.delivered, url: t.url || null }; } catch (e) { return null; } })
        .filter(Boolean).sort((a, b) => b.id - a.id).slice(0, 30);
    } catch (e) { return []; }
  }
  async create(body, profile) {
    const cfg = this.getCfg();
    const message = String(body.message || '').trim().slice(0, 4000);
    if (message.length < 5) throw Object.assign(new Error('Add a short description so we know how to help.'), { status: 400 });
    const topic = TOPICS[body.topic] ? body.topic : 'other';
    cfg.ticketSeq = (cfg.ticketSeq || 100) + 1; this.saveCfg();
    const id = cfg.ticketSeq;
    const shot = typeof body.screenshot === 'string' && /^data:image\/(png|jpeg|webp);base64,/.test(body.screenshot) ? body.screenshot : null;
    const t = {
      id, t: Date.now(), topic, message, version: this.version, os: process.platform + ' ' + process.arch,
      page: String(body.page || '').slice(0, 30),
      name: String((profile && profile.name) || '').slice(0, 60), discord: String((profile && profile.discord) || '').slice(0, 60), plan: (profile && profile.plan) || 'Free',
      hasShot: !!shot, hasLog: !!body.attachLog, delivered: false
    };
    fs.writeFileSync(path.join(this.dir, 'T-' + id + '.json'), JSON.stringify(t, null, 2));
    if (shot) fs.writeFileSync(path.join(this.dir, 'T-' + id + '.' + (shot.slice(11, 15).replace(/;.*/, '') === 'jpeg' ? 'jpg' : 'png')), Buffer.from(shot.split(',')[1], 'base64'));
    const logTxt = body.attachLog ? this.logTail(300) : '';
    if (logTxt) fs.writeFileSync(path.join(this.dir, 'T-' + id + '.log.txt'), logTxt);
    this.log('support: ticket #' + id + ' (' + topic + ') saved');
    // 1) Venom OS: private ticket thread in the Delfi Discord. 2) fallback: the staff channel webhook.
    let venom = null;
    if (VENOM_URL) {
      try { venom = await this.toVenom(t, shot, logTxt); } catch (e) { this.log('support: venom ticket #' + id + ': ' + e.message); }
    }
    const url = this.destination();
    if (venom) { t.delivered = true; t.via = 'venom'; t.inServer = !!venom.inServer; t.url = venom.url || null; }
    else if (url) {
      try { await this.forward(url, t, shot, logTxt); t.delivered = true; t.via = 'webhook'; }
      catch (e) { this.log('support: ticket #' + id + ' not delivered: ' + e.message); }
    }
    if (t.delivered) { fs.writeFileSync(path.join(this.dir, 'T-' + id + '.json'), JSON.stringify(t, null, 2)); this.log('support: ticket #' + id + ' delivered via ' + t.via); }
    return { id, delivered: t.delivered, configured: !!(url || VENOM_URL), via: t.via || null, inServer: t.via === 'venom' ? !!t.inServer : null, url: t.url || null };
  }
  async toVenom(t, shot, logTxt) {
    const r = await fetch(VENOM_URL, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Xray-Key': VENOM_KEY }, body: JSON.stringify(Object.assign({}, t, { screenshot: shot, log: logTxt })), signal: AbortSignal.timeout(20000) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error((j && j.error) || 'Venom answered ' + r.status);
    return j;
  }
  async forward(url, t, shot, logTxt) {
    const fd = new FormData();
    const who = (t.name || 'Unnamed user') + (t.discord ? ' (@' + t.discord.replace(/^@/, '') + ')' : '');
    const payload = {
      username: 'X-ray Support',
      embeds: [{
        title: 'Ticket #' + t.id + ' · ' + (TOPICS[t.topic] || 'Other'),
        description: t.message.slice(0, 3800),
        color: t.topic === 'bug' ? 0xF2555A : t.topic === 'billing' ? 0xF2C14E : 0x8FD2EC,
        fields: [{ name: 'From', value: who, inline: true }, { name: 'Plan', value: t.plan, inline: true }, { name: 'Version', value: 'v' + t.version + ' · ' + t.os, inline: true }].concat(t.page ? [{ name: 'Page', value: t.page, inline: true }] : []),
        timestamp: new Date(t.t).toISOString()
      }]
    };
    let n = 0;
    if (shot) { const ext = /jpeg/.test(shot.slice(0, 30)) ? 'jpg' : 'png'; fd.append('files[' + n++ + ']', new Blob([Buffer.from(shot.split(',')[1], 'base64')], { type: 'image/' + (ext === 'jpg' ? 'jpeg' : 'png') }), 'ticket-' + t.id + '.' + ext); payload.embeds[0].image = { url: 'attachment://ticket-' + t.id + '.' + ext }; }
    if (logTxt) fd.append('files[' + n++ + ']', new Blob([logTxt], { type: 'text/plain' }), 'xray-log-' + t.id + '.txt');
    fd.append('payload_json', JSON.stringify(payload));
    const r = await fetch(url, { method: 'POST', body: fd, signal: AbortSignal.timeout(15000) });
    if (!r.ok) throw new Error('destination answered ' + r.status);
  }
}
module.exports = { Support, TOPICS };
