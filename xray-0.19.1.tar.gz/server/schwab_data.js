// Schwab data provider: same shapes as DataManager (Webull) so the UI and GEX model work unchanged,
// plus fundamentals (dividends, P/E, EPS). Also MultiData, which tries each connected broker in order.
'use strict';
const { DataManager, occ, parseOcc, nyParts, minExp } = require('./data');

const num = (v) => { const x = Number(v); return Number.isFinite(x) && x !== -999 ? x : null; };
const INDEX = { SPX: '$SPX', NDX: '$NDX', RUT: '$RUT' };
const ROOT_UND = { SPXW: '$SPX', SPX: '$SPX', NDXP: '$NDX', NDX: '$NDX', RUTW: '$RUT', RUT: '$RUT' };
const WEEKLY_ROOT = { SPX: 'SPXW', NDX: 'NDXP', RUT: 'RUTW' };
const schwabSym = (s) => INDEX[s] || s;
// Schwab option symbols are "ROOT__YYMMDDC00012345" with the root padded to 6 characters
const occFromSchwab = (s) => String(s || '').replace(/\s+/g, '');
const underlyingOfRoot = (root) => ROOT_UND[root] || root;
const today = () => nyParts(Date.now()).date;
const KEEP = new Set(['ETF', 'ADR', 'ADS', 'REIT', 'LP', 'LLC', 'PLC', 'SA', 'NV', 'AG', 'II', 'III', 'IV', 'US', 'USA', 'S&P', 'MSCI', 'FTSE', 'AI']);
// Schwab names come in ALL CAPS: make them readable ("TENCENT HOLDINGS LTD ADR" -> "Tencent Holdings Ltd ADR")
const niceName = (n) => (n !== n.toUpperCase() ? n : n.split(/\s+/).map((w) => (KEEP.has(w) || /\d/.test(w) ? w : w.charAt(0) + w.slice(1).toLowerCase())).join(' '));

class SchwabData extends DataManager {
  constructor(client, log) { super(client, log); this.name = 'Schwab'; this.opt = {}; }

  normQ(sym, r) {
    const q = (r && r.quote) || {};
    const last = num(q.lastPrice) ?? num(q.mark) ?? num(q.closePrice);
    const prev = num(q.closePrice);
    const chgPct = num(q.netPercentChange) ?? (prev && last ? (last / prev - 1) * 100 : 0);
    return { last, prevClose: prev, chg: num(q.netChange), chgPct, open: num(q.openPrice), high: num(q.highPrice), low: num(q.lowPrice), volume: num(q.totalVolume), bid: num(q.bidPrice), ask: num(q.askPrice), hi52: num(q['52WeekHigh']), lo52: num(q['52WeekLow']), t: Date.now(), src: 'schwab' };
  }
  async quotes(symbols) {
    const out = {};
    const want = symbols.filter((s) => /^[A-Z]{1,5}$/.test(s));
    const need = want.filter((s) => { const q = this.lastQuote[s]; return !q || Date.now() - q.t > 2500; });
    for (let i = 0; i < need.length; i += 100) {
      const chunk = need.slice(i, i + 100);
      const r = await this.c.quotes(chunk.map(schwabSym), 'quote,fundamental');
      chunk.forEach((s) => {
        const row = r && r[schwabSym(s)];
        if (row && row.quote) { this.lastQuote[s] = this.normQ(s, row); if (row.fundamental) this.fund = Object.assign(this.fund || {}, { [s]: { f: row.fundamental, t: Date.now() } }); }
      });
    }
    want.forEach((s) => { if (this.lastQuote[s]) out[s] = this.lastQuote[s]; });
    return out;
  }
  async indexQuote(sym) { const q = (await this.quotes([sym]))[sym]; if (!q) throw new Error('No ' + sym + ' quote'); return q; }

  // dividends + basic fundamentals (from the quote's fundamental block)
  async fundamentals(sym) {
    return this.cached('fund:' + sym, 10 * 60000, async () => {
      await this.quotes([sym]);
      const e = this.fund && this.fund[sym];
      if (!e) throw new Error('No fundamentals for ' + sym);
      const f = e.f, q = this.lastQuote[sym] || {};
      const d = (x) => (x ? String(x).slice(0, 10) : null);
      return {
        symbol: sym, src: 'Schwab',
        peRatio: num(f.peRatio), eps: num(f.eps), pegRatio: num(f.pegRatio), pbRatio: num(f.pbRatio), sharesOutstanding: num(f.sharesOutstanding), marketCap: num(f.marketCap), beta: num(f.beta),
        divYield: num(f.divYield), divAmount: num(f.divAmount), divFreq: num(f.divFreq), divExDate: d(f.divExDate), divPayDate: d(f.divPayDate), nextDivExDate: d(f.nextDivExDate), nextDivPayDate: d(f.nextDivPayDate),
        hi52: q.hi52 || num(f.high52), lo52: q.lo52 || num(f.low52)
      };
    });
  }

  // ---------- price history ----------
  async bars(sym, tf) {
    const ttl = tf === '1m' ? 4000 : tf === '5m' ? 8000 : tf === '1D' || tf === '1W' ? 60000 : 15000;
    return this.cached('bars:' + sym + ':' + tf, ttl, async () => {
      const intraday = { '1m': [1, 1], '5m': [5, 1], '15m': [15, 1], '1H': [30, 2], '4H': [30, 8] };
      const s = schwabSym(sym);
      let q, agg = 1;
      if (intraday[tf]) {
        const [freq, a] = intraday[tf]; agg = a;
        const daysBack = tf === '1m' ? 4 : tf === '5m' ? 10 : tf === '15m' ? 20 : 45;
        q = { symbol: s, periodType: 'day', frequencyType: 'minute', frequency: freq, startDate: Date.now() - daysBack * 86400000, endDate: Date.now() + 60000, needExtendedHoursData: 'false' };
      } else if (tf === '1D') q = { symbol: s, periodType: 'year', period: 2, frequencyType: 'daily', frequency: 1 };
      else if (tf === '1W') q = { symbol: s, periodType: 'year', period: 10, frequencyType: 'weekly', frequency: 1 };
      else throw new Error('Unknown timeframe ' + tf);
      const r = await this.c.priceHistory(q);
      let bars = ((r && r.candles) || []).map((c) => ({ t: num(c.datetime), o: num(c.open), h: num(c.high), l: num(c.low), c: num(c.close), v: num(c.volume) || 0 }))
        .filter((b) => b.t && b.o !== null && b.c !== null).sort((a, b) => a.t - b.t);
      if (agg > 1) bars = aggregate(bars, agg * 30);
      return { bars };
    });
  }

  // ---------- options ----------
  async chainFor(sym, exp, strikeCount, ttl) {
    const und = schwabSym(sym);
    return this.cached('ch:' + und + ':' + exp + ':' + strikeCount, ttl || 2500, async () => {
      const r = await this.c.chains({ symbol: und, contractType: 'ALL', strategy: 'SINGLE', includeUnderlyingQuote: 'true', fromDate: exp, toDate: exp, strikeCount });
      const list = [];
      [['C', r && r.callExpDateMap], ['P', r && r.putExpDateMap]].forEach(([type, map]) => {
        Object.keys(map || {}).forEach((ek) => {
          Object.keys(map[ek]).forEach((k) => (map[ek][k] || []).forEach((o) => {
            const sym2 = occFromSchwab(o.symbol);
            const p = parseOcc(sym2);
            if (!p) return;
            const bid = num(o.bid), ask = num(o.ask), last = num(o.last), mark = num(o.mark);
            const ivRaw = num(o.volatility);
            const row = {
              occ: sym2, strike: num(o.strikePrice) ?? p.strike, type, exp: p.exp, root: p.root,
              last, bid, ask, mid: mark !== null ? mark : (bid !== null && ask !== null && ask > 0 ? (bid + ask) / 2 : last),
              open: num(o.openPrice), high: num(o.highPrice), low: num(o.lowPrice), prevClose: num(o.closePrice),
              chg: num(o.netChange), chgPct: num(o.percentChange), volume: num(o.totalVolume) || 0, oi: num(o.openInterest) || 0,
              iv: ivRaw !== null && ivRaw > 0 ? ivRaw / 100 : null, delta: num(o.delta), gamma: num(o.gamma), theta: num(o.theta), vega: num(o.vega), rho: num(o.rho), t: Date.now()
            };
            this.opt[sym2] = row;
            list.push(row);
          }));
        });
      });
      return { list, spot: num(r && r.underlyingPrice) };
    });
  }
  async expirations(sym) {
    return this.cached('exp:' + sym + ':' + minExp(), 30 * 60000, async () => {
      const r = await this.c.expirationChain(schwabSym(sym));
      const t0 = minExp();
      const expiries = Array.from(new Set(((r && r.expirationList) || []).map((e) => String(e.expirationDate || '').slice(0, 10)).filter((d) => d && d >= t0))).sort();
      if (!expiries.length) throw new Error('No expirations found for ' + sym);
      const ch = await this.chainFor(sym, expiries[0], 30, 30 * 60000);
      const ks = Array.from(new Set(ch.list.map((c) => c.strike))).sort((a, b) => a - b);
      let step = null;
      for (let i = 1; i < ks.length; i++) { const d = +(ks[i] - ks[i - 1]).toFixed(3); if (d > 0 && (step === null || d < step)) step = d; }
      return { expiries, step: step || 1, root: WEEKLY_ROOT[sym] || sym };
    });
  }
  async chainContracts(sym, exp, pct) {
    const ex = await this.expirations(sym).catch(() => ({ step: 1 }));
    const spot = (await this.quotes([sym]))[sym];
    const range = spot && spot.last ? spot.last * pct * 2 : 50 * ex.step;
    const count = Math.max(20, Math.min(200, Math.ceil(range / (ex.step || 1)) + 4));
    const ch = await this.chainFor(sym, exp, count, 60000);
    return ch.list.filter((c) => c.exp === exp).map((c) => ({ occ: c.occ, exp: c.exp, type: c.type, strike: c.strike, root: c.root }));
  }
  async optionQuotes(occs, ttl) {
    ttl = ttl || 2500;
    const out = {};
    const groups = new Map();
    occs.forEach((o) => {
      const q = this.opt[o];
      if (q && Date.now() - q.t <= ttl) return;
      const p = parseOcc(o); if (!p) return;
      const key = underlyingOfRoot(p.root) + '|' + p.exp;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(p.strike);
    });
    for (const [key, strikes] of groups) {
      const [und, exp] = key.split('|');
      const sym = und.replace(/^\$/, '');
      const spot = (this.lastQuote[sym] && this.lastQuote[sym].last) || null;
      const far = spot ? Math.max(...strikes.map((k) => Math.abs(k - spot))) : 0;
      const ek = 'exp:' + sym + ':' + minExp(); const step = (this.cache.get(ek) && this.cache.get(ek).v && this.cache.get(ek).v.step) || (spot && spot > 1000 ? 5 : 1);
      const count = Math.max(30, Math.min(200, Math.ceil(far / step) * 2 + 10));
      try { await this.chainFor(sym, exp, count, ttl); } catch (e) { this.log('schwab chain ' + key + ': ' + e.message); if (e.status === 401) throw e; }
    }
    occs.forEach((o) => { if (this.opt[o]) out[o] = this.opt[o]; });
    return out;
  }
  // search every listed stock/ETF by symbol or company name (Schwab instrument search)
  async search(q) {
    const Q = String(q || '').trim().toUpperCase().replace(/^\^/, '');
    if (!Q) return [];
    return this.cached('search:' + Q, 10 * 60000, async () => {
      const out = [], seen = new Set();
      const add = (list) => (list || []).forEach((i) => {
        const sym = String(i.symbol || '').toUpperCase();
        if (!/^[A-Z]{1,5}$/.test(sym) || seen.has(sym)) return;
        if (i.assetType && !/^(EQUITY|ETF)$/.test(i.assetType)) return;
        seen.add(sym); out.push({ sym, name: niceName(String(i.description || sym)).slice(0, 60), type: i.assetType === 'ETF' ? 'ETF' : 'STOCK', exch: i.exchange || '' });
      });
      const rows = (r) => (r && Array.isArray(r.instruments) ? r.instruments : r && typeof r === 'object' ? Object.values(r) : []);
      if (/^[A-Z.]{2,6}$/.test(Q)) { try { add(rows(await this.c.instruments(Q.replace(/\./g, '\\.') + '.*', 'symbol-regex'))); } catch (e) { this.log('schwab search: ' + e.message); } }
      if (Q.length >= 4 && out.length < 8) { try { add(rows(await this.c.instruments(Q, 'desc-search'))); } catch (e) { this.log('schwab desc search: ' + e.message); } }
      // exact symbol first, then shorter symbols
      out.sort((a, b) => (a.sym === Q ? -1 : b.sym === Q ? 1 : a.sym.length - b.sym.length));
      return out.slice(0, 12);
    });
  }
  async optionBars() { const e = new Error('Schwab does not provide option price history'); e.unsupported = true; throw e; }
  async optionDailyBars() { const e = new Error('Schwab does not provide option price history'); e.unsupported = true; throw e; }
}

// group intraday bars into N-minute bars that start at the 09:30 ET open
function aggregate(bars, minutes) {
  const out = [];
  let cur = null, key = null;
  bars.forEach((b) => {
    const p = nyParts(b.t);
    const k = p.date + '|' + Math.floor(((p.h * 60 + p.m) - 570) / minutes);
    if (k !== key) { if (cur) out.push(cur); cur = { t: b.t, o: b.o, h: b.h, l: b.l, c: b.c, v: b.v }; key = k; }
    else { cur.h = Math.max(cur.h, b.h); cur.l = Math.min(cur.l, b.l); cur.c = b.c; cur.v += b.v; }
  });
  if (cur) out.push(cur);
  return out;
}

// Tries each connected broker in order; the first one that answers wins.
class MultiData {
  constructor(list, log) { this.list = list; this.log = log || (() => {}); }
  get names() { return this.list.map((d) => d.name); }
  async first(method, args, order) {
    let last = null;
    for (const d of (order || this.list)) {
      if (typeof d[method] !== 'function') continue;
      try { return await d[method](...args); } catch (e) { last = e; if (!e.unsupported) this.log(d.name + ' ' + method + ' failed, trying next: ' + e.message); }
    }
    throw last || new Error('No broker connected');
  }
  // quotes merge across brokers: anything the first one can't price (unknown ticker, or stale because
  // that broker stopped answering) is asked of the next one
  async quotes(symbols) {
    const out = {};
    let left = symbols.slice(), last = null;
    for (const d of this.list) {
      if (!left.length) break;
      try {
        const r = await d.quotes(left);
        left.forEach((s) => { const q = r && r[s]; if (q && q.last && (q.derived || Date.now() - (q.t || 0) < 20000)) out[s] = q; });
      } catch (e) { last = e; this.log(d.name + ' quotes failed, trying next: ' + e.message); }
      left = left.filter((s) => !out[s]);
    }
    if (!Object.keys(out).length && last && symbols.length) throw last;
    return out;
  }
  bars(...a) { return this.first('bars', a); }
  // option chains: Schwab sends a whole expiry in one call while Webull rate-limits contract lookups (429s),
  // so when both are connected Schwab answers chain questions first and Webull is the backup
  async firstOpt(method, args) { return this.first(method, args, this.list.slice().sort((a, b) => (b.name === 'Schwab') - (a.name === 'Schwab'))); }
  expirations(...a) { return this.firstOpt('expirations', a); }
  optionQuotes(...a) { return this.firstOpt('optionQuotes', a); }
  chainContracts(...a) { return this.firstOpt('chainContracts', a); }
  optionBars(...a) { return this.first('optionBars', a); }
  optionDailyBars(...a) { return this.first('optionDailyBars', a); }
  gex(...a) { return this.firstOpt('gex', a); }
  fundamentals(...a) { return this.first('fundamentals', a); }
  // broker symbol search if one supports it; otherwise check an exact ticker with a live quote
  async search(q) {
    for (const d of this.list) { if (typeof d.search === 'function') { try { const r = await d.search(q); if (r.length) return r; } catch (e) { this.log(d.name + ' search failed: ' + e.message); } } }
    const Q = String(q || '').trim().toUpperCase();
    if (!/^[A-Z]{1,5}$/.test(Q)) return [];
    const r = await this.quotes([Q]).catch(() => ({}));
    return r[Q] && r[Q].last ? [{ sym: Q, name: Q, type: 'STOCK', exch: '' }] : [];
  }
  news(...a) { return (this.list[0] || new DataManager(null, this.log)).news(...a); }
}

module.exports = { SchwabData, MultiData, aggregate, occFromSchwab };
