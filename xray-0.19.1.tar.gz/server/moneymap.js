// Market maker money map for one expiry (0DTE by default), built from today's option volume.
// Assumption (to be calibrated against the reference tool): today's buyers paid the mid, market makers
// sold to them. If the stock settles at S, buyers as a group make  sum(vol * 100 * (intrinsic(S) - paid)).
// That number is most negative at the Peak Money Line (where market makers keep the most) and crosses
// zero at the Ceiling and Floor ("wash-out": past them market makers start paying out).
'use strict';

const intrinsic = (type, K, S) => (type === 'C' ? Math.max(0, S - K) : Math.max(0, K - S));

function compute(sym, exp, spot, rows, step) {
  const live = rows.filter((r) => r.vol > 0 && r.paid > 0);
  const lo = spot * 0.96, hi = spot * 1.04;
  const gridStep = Math.max(spot * 0.0002, 0.01);
  const money = (S) => live.reduce((t, r) => t + r.vol * 100 * (intrinsic(r.type, r.strike, S) - r.paid), 0);
  const grid = [];
  for (let S = lo; S <= hi; S += gridStep) grid.push({ S, v: money(S) });
  let peak = grid[0];
  grid.forEach((g) => { if (g.v < peak.v) peak = g; });
  // wash-out levels: where buyers' P&L climbs back to zero on each side of the peak
  const cross = (dir) => {
    const i0 = grid.indexOf(peak);
    for (let i = i0; dir > 0 ? i < grid.length - 1 : i > 0; i += dir) {
      const a = grid[i], b = grid[i + dir];
      if (a.v < 0 && b.v >= 0) { const t = -a.v / (b.v - a.v); return { S: a.S + (b.S - a.S) * t, v: 0 }; }
    }
    return null;
  };
  const ceiling = cross(1), floor = cross(-1);
  const split = (lvl) => {
    const o = { callsAbove: 0, putsAbove: 0, callsBelow: 0, putsBelow: 0 };
    live.forEach((r) => { const k = (r.type === 'C' ? 'calls' : 'puts') + (r.strike >= lvl ? 'Above' : 'Below'); o[k] += r.vol; });
    return o;
  };
  // best contract to grab if price travels to a level by the close
  const playFor = (target) => {
    const type = target < spot ? 'P' : 'C';
    let best = null;
    rows.forEach((r) => {
      if (r.type !== type || !(r.ask > 0)) return;
      const d = Math.abs(r.delta || 0);
      if (r.delta != null && d < 0.15) return; // skip lottos: needs at least ~0.15 delta
      if (r.delta == null && Math.abs(r.strike - spot) / spot > 0.01) return;
      const ret = (intrinsic(type, r.strike, target) - r.ask) / r.ask * 100;
      if (!best || ret > best.ret) best = { occ: r.occ, type, strike: r.strike, buyMax: r.ask, ret, delta: r.delta };
    });
    return best;
  };
  const strikes = Array.from(new Set(rows.map((r) => r.strike))).filter((k) => k >= lo && k <= hi).sort((a, b) => b - a);
  const levels = strikes.map((K) => ({ price: K, money: money(K), pct: (K / spot - 1) * 100, play: Math.abs(K - spot) / spot > 0.0015 ? playFor(K) : null }));
  const key = (lvl) => (lvl ? { price: lvl.S, money: money(lvl.S), pct: (lvl.S / spot - 1) * 100, play: playFor(lvl.S) } : null);
  const tot = live.reduce((t, r) => { t[r.type] += r.vol; t.prem += r.vol * 100 * r.paid; return t; }, { C: 0, P: 0, prem: 0 });
  return {
    symbol: sym, exp, spot, step, t: Date.now(),
    aggregate: money(spot),
    peak: Object.assign(key(peak), split(peak.S)),
    ceiling: key(ceiling), floor: key(floor),
    atSpot: split(spot),
    calls: tot.C, puts: tot.P, premium: tot.prem,
    contracts: live.length,
    levels
  };
}

async function moneyMap(dm, sym, exp) {
  const ex = await dm.expirations(sym);
  if (!ex || !ex.expiries || !ex.expiries.length) throw new Error('No expirations for ' + sym);
  exp = exp && ex.expiries.includes(exp) ? exp : ex.expiries[0];
  const q = (await dm.quotes([sym]))[sym];
  if (!q || !q.last) throw new Error('No price for ' + sym);
  const spot = q.last;
  const list = await dm.chainContracts(sym, exp, 0.045);
  if (!list.length) throw new Error('No contracts listed for ' + sym + ' ' + exp);
  const snaps = await dm.optionQuotes(list.map((c) => c.occ), 15000);
  const rows = list.map((c) => {
    const s = snaps[c.occ]; if (!s) return null;
    const paid = s.mid != null && s.mid > 0 ? s.mid : s.last;
    return { occ: c.occ, type: c.type, strike: Number(c.strike), vol: s.volume || 0, oi: s.oi || 0, paid: paid || 0, ask: s.ask || paid || 0, delta: s.delta != null && Number.isFinite(s.delta) ? s.delta : null };
  }).filter(Boolean);
  if (!rows.length) throw new Error('No option quotes yet for ' + sym);
  return compute(sym, exp, spot, rows, ex.step);
}

module.exports = { moneyMap, compute };
