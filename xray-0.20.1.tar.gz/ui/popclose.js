// Menus close the way you expect: Esc, or a click anywhere outside the open menu.
(() => {
  const app = () => (window.__app && window.__app.c) || null;
  const close = () => { const a = app(); if (a && a.state && a.state.ecoOpen) a.setState({ ecoOpen: null, ecoSearch: '' }); };
  window.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); }, true);
  document.addEventListener('mousedown', (e) => {
    const a = app(); if (!a || !a.state || !a.state.ecoOpen) return;
    const t = e.target; if (!t || !t.closest) return;
    if (t.closest('[role="dialog"][aria-label="Choose metrics"]') || t.closest('[aria-expanded="true"]')) return;
    close();
  }, true);
})();
