// Premium-chart drawings are pinned to real time, not to candle numbers, so the same line or box shows in the same
// spot on 5m, 15m, 1H and 1D. Daily candles map a time to its spot inside that day's session (9:30 to 4:00 ET).
(() => {
  const SESSION = 390 * 60000;
  const etMin = (t) => { const p = new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(new Date(t)); const g = (k) => +(p.find((x) => x.type === k) || {}).value || 0; return g('hour') * 60 + g('minute'); };
  const openCache = new WeakMap();
  const opens = (arr) => {   // each daily candle's 9:30 ET open, in ms
    let o = openCache.get(arr); if (o) return o;
    o = arr.map((b) => (Number.isFinite(b.t) ? b.t + (570 - etMin(b.t)) * 60000 : NaN));
    openCache.set(arr, o); return o;
  };
  const ok = (arr) => Array.isArray(arr) && arr.length > 1 && Number.isFinite(arr[0].t) && Number.isFinite(arr[arr.length - 1].t);

  const tAt = (arr, daily) => {
    if (!ok(arr)) return null;
    const N = arr.length;
    if (daily) {
      const op = opens(arr);
      return (i) => { const k = Math.max(0, Math.min(N - 1, Math.floor(i))); const f = i - k; if (i < 0) return op[0] + i * 86400000; if (i >= N) return op[N - 1] + (i - (N - 1)) * 86400000; return op[k] + Math.max(0, Math.min(0.999, f)) * SESSION; };
    }
    const step = arr[N - 1].t - arr[N - 2].t || 300000;
    return (i) => { if (i <= 0) return arr[0].t + i * (arr[1].t - arr[0].t || step); if (i >= N - 1) return arr[N - 1].t + (i - (N - 1)) * step; const k = Math.floor(i); return arr[k].t + (i - k) * (arr[k + 1].t - arr[k].t); };
  };

  const iAt = (arr, daily) => {
    if (!ok(arr)) return null;
    const N = arr.length;
    const ts = daily ? opens(arr) : arr.map((b) => b.t);
    const find = (t) => { let lo = 0, hi = N - 1; while (hi - lo > 1) { const m = (lo + hi) >> 1; if (ts[m] <= t) lo = m; else hi = m; } return ts[hi] <= t ? hi : lo; };
    if (daily) return (t) => { if (t < ts[0]) return (t - ts[0]) / 86400000; const k = find(t); if (k === N - 1 && t - ts[k] > SESSION) return N - 1 + (t - ts[k]) / 86400000; return k + Math.max(0, Math.min(0.999, (t - ts[k]) / SESSION)); };
    const step = ts[N - 1] - ts[N - 2] || 300000;
    return (t) => { if (t <= ts[0]) return (t - ts[0]) / (ts[1] - ts[0] || step); if (t >= ts[N - 1]) return N - 1 + (t - ts[N - 1]) / step; const k = find(t); return k + (t - ts[k]) / Math.max(1, ts[k + 1] - ts[k]); };
  };

  window.XRDT = { tAt, iAt };
})();
