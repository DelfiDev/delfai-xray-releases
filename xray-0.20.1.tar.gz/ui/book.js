// Order Book (Level 2) for the contract on the premium chart, like Webull's: every exchange's bid and ask,
// rows colored by price level (same color = same price). Live from Schwab's stream, refreshed every second.
(() => {
  const LV = [['#8FA83A', '#10160A'], ['#E3A12F', '#1C1203'], ['#5C7CDB', '#0A1230'], ['#D9495A', '#2A060B'], ['#6A4BD8', '#F2EEFF'], ['#2FA59A', '#04201D'], ['#B4568F', '#FCEFF6']];
  const fmt = (p) => (Number.isFinite(p) ? (p >= 10 ? p.toFixed(2) : p.toFixed(2)) : '');
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
  let last = null, busy = false, lastOcc = null, lastHtml = '';

  // one row per exchange quote, each side colored by its price level
  const rows = (levels) => { const out = []; levels.forEach((lv, li) => { const mms = lv.mm.length ? lv.mm : [{ id: '—', size: lv.size }]; mms.slice().sort((a, b) => b.size - a.size).forEach((m) => out.push({ id: m.id, size: m.size, p: lv.p, li })); }); return out; };

  const render = (host, j, opt) => {
    let html;
    const head = '<div style="display:flex;justify-content:space-between;align-items:baseline;gap:8px"><span style="font-family:\'JetBrains Mono\',monospace;font-size:10.5px;letter-spacing:.12em;color:#8FD2EC">ORDER BOOK</span><span style="font-size:11.5px;color:#8796A3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + esc(opt ? opt.name || opt.occ : '') + '</span></div>';
    if (!opt || !opt.occ) html = head + '<p style="margin:0;font-size:12.5px;color:#8796A3">Pick a contract to see every exchange\'s bid and ask.</p>';
    else if (!j) html = head + '<p style="margin:0;font-size:12.5px;color:#8796A3">Loading the order book…</p>';
    else if (j.state === 'needs-schwab' || (j.error && !j.book)) html = head + '<p style="margin:0;font-size:12.5px;line-height:1.5;color:#8796A3">' + esc(j.error || 'Connecting to Schwab…') + '</p>';
    else if (!j.book) html = head + '<p style="margin:0;font-size:12.5px;color:#8796A3">Connecting to the Schwab stream…</p>';
    else {
      const b = j.book, bid = rows(b.bids), ask = rows(b.asks);
      const n = Math.max(bid.length, ask.length, 1);
      const tb = b.bids.reduce((a, x) => a + x.size, 0), ta = b.asks.reduce((a, x) => a + x.size, 0);
      const pct = tb + ta ? Math.round(tb / (tb + ta) * 100) : 50;
      const spread = b.bids[0] && b.asks[0] ? (b.asks[0].p - b.bids[0].p) : null;
      const cell = (r, side) => {
        if (!r) return '<td colspan="3" style="background:transparent"></td>';
        const [bg, fg] = LV[r.li % LV.length];
        const c = 'background:' + bg + ';color:' + fg + ';padding:3px 6px;font-family:\'JetBrains Mono\',monospace;font-size:12px;white-space:nowrap';
        return side === 'b'
          ? '<td style="' + c + '">' + esc(r.id) + '</td><td style="' + c + ';text-align:right">' + r.size + '</td><td style="' + c + ';text-align:right">' + fmt(r.p) + '</td>'
          : '<td style="' + c + '">' + fmt(r.p) + '</td><td style="' + c + ';text-align:right">' + r.size + '</td><td style="' + c + ';text-align:right">' + esc(r.id) + '</td>';
      };
      let body = '';
      for (let i = 0; i < Math.min(n, 14); i++) body += '<tr>' + cell(bid[i], 'b') + cell(ask[i], 'a') + '</tr>';
      const th = 'style="padding:4px 6px;font-weight:500;font-size:11px;color:#8796A3;text-align:left"';
      html = head
        + '<div style="display:flex;height:6px;border-radius:3px;overflow:hidden"><div style="width:' + pct + '%;background:#34D399"></div><div style="flex:1;background:#F2555A"></div></div>'
        + '<div style="display:flex;justify-content:space-between;font-size:11.5px;color:#8796A3"><span>Bid size ' + tb + ' · ' + pct + '%</span><span>Spread ' + (spread === null ? '—' : spread.toFixed(2)) + '</span><span>Ask size ' + ta + '</span></div>'
        + '<div style="overflow:auto;max-height:360px;border-radius:6px"><table style="width:100%;border-collapse:collapse;table-layout:fixed"><thead><tr><th ' + th + '>MIC</th><th ' + th.replace('left', 'right') + '>Size</th><th ' + th.replace('left', 'right').replace('#8796A3', '#34D399') + '>Bid</th><th ' + th.replace('#8796A3', '#F2555A') + '>Ask</th><th ' + th.replace('left', 'right') + '>Size</th><th ' + th.replace('left', 'right') + '>MIC</th></tr></thead><tbody>' + body + '</tbody></table></div>'
        + '<span style="font-size:11px;color:#5B6B7A">Live from Schwab' + (j.age !== null && j.age > 5000 ? ' · last update ' + Math.round(j.age / 1000) + 's ago' : '') + '. Same color = same price.</span>';
    }
    if (html !== lastHtml || !host.firstChild) { host.innerHTML = html; lastHtml = html; }
  };

  const tick = async () => {
    const host = document.getElementById('xr-book');
    if (!host || document.hidden) return;
    const opt = window.XR_OPT || null;
    if (!opt || !opt.occ) { render(host, null, null); return; }
    if (opt.occ !== lastOcc) { lastOcc = opt.occ; last = null; render(host, null, opt); }
    if (busy) return; busy = true;
    try { const r = await fetch('/api/book?occ=' + encodeURIComponent(opt.occ), { cache: 'no-store' }); last = await r.json(); } catch (e) { last = { error: 'Could not reach X-ray.' }; }
    busy = false;
    render(host, last, opt);
  };
  setInterval(tick, 1000);
})();
