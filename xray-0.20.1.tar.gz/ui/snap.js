// Copy chart image: the camera button on a chart's drawing toolbar (or Ctrl/Cmd+Shift+S over a chart) puts a picture
// of that chart on the clipboard, ready to paste into Discord, X, notes, anywhere. Desktop app only.
(() => {
  const isApp = /Electron/i.test(navigator.userAgent);
  if (!isApp) { const st = document.createElement('style'); st.textContent = '.xr-snap{display:none!important}'; document.head.appendChild(st); return; }

  // the whole chart card (title, price, candles, axis), not just the plot
  const cardOf = (which) => {
    const plot = document.getElementById(which === 'O' ? 'xr-oplot' : 'xr-plot');
    if (!plot) return null;
    if (which === 'S') { const c = document.getElementById('xr-chart'); if (c && c.contains(plot)) return c; }
    let el = plot.parentElement, best = plot;
    while (el && el !== document.body) {
      const cs = getComputedStyle(el);
      const boxed = parseFloat(cs.borderTopLeftRadius) > 0 && cs.borderTopStyle !== 'none' && cs.backgroundColor !== 'rgba(0, 0, 0, 0)';
      best = el; if (boxed) return el;
      el = el.parentElement;
    }
    return best;
  };

  let toastEl = null, toastT = 0;
  const toast = (txt) => {
    if (!toastEl) { toastEl = document.createElement('div'); toastEl.setAttribute('role', 'status'); toastEl.style.cssText = 'position:fixed;left:50%;bottom:28px;transform:translateX(-50%);z-index:99999;background:#0B1017;color:#E8EEF2;border:1px solid #2C4A63;border-radius:999px;padding:9px 16px;font:500 13px "IBM Plex Sans",sans-serif;box-shadow:0 8px 28px rgba(0,0,0,.45);pointer-events:none;transition:opacity .2s'; document.body.appendChild(toastEl); }
    toastEl.textContent = txt; toastEl.style.opacity = '1'; clearTimeout(toastT); toastT = setTimeout(() => { toastEl.style.opacity = '0'; }, 2400);
  };

  let busy = false;
  const snap = async (which) => {
    if (busy) return; const card = cardOf(which); if (!card) return;
    busy = true;
    const r0 = card.getBoundingClientRect();   // the whole card has to be on screen to be captured
    if (r0.top < 0 || r0.bottom > window.innerHeight) { card.scrollIntoView({ block: r0.height > window.innerHeight ? 'start' : 'center' }); await new Promise((r) => setTimeout(r, 250)); }
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    const r = card.getBoundingClientRect();
    const x = Math.max(0, r.left), y = Math.max(0, r.top);
    const w = Math.min(r.right, window.innerWidth) - x, h = Math.min(r.bottom, window.innerHeight) - y;
    try {
      const res = await fetch('/api/snap', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ x, y, w, h }) });
      const j = await res.json().catch(() => ({}));
      if (res.ok && j.ok) {
        card.animate([{ boxShadow: 'inset 0 0 0 2px rgba(143,210,236,.9)' }, { boxShadow: 'inset 0 0 0 2px rgba(143,210,236,0)' }], { duration: 650 });
        toast('📸 Chart copied. Paste it anywhere (' + (/Mac/.test(navigator.platform) ? '⌘V' : 'Ctrl+V') + ')');
      } else toast('Could not copy the chart. Try again.');
    } catch (e) { toast('Could not copy the chart. Try again.'); }
    busy = false;
  };

  document.addEventListener('click', (e) => {
    const b = e.target.closest && e.target.closest('[data-xr-snap]');
    if (!b) return; e.preventDefault(); e.stopPropagation(); snap(b.getAttribute('data-xr-snap'));
  }, true);

  // keyboard: Ctrl/Cmd+Shift+S copies the chart under the mouse (price chart if the mouse isn't over one)
  let over = 'S', lastMv = 0;
  document.addEventListener('mousemove', (e) => {
    const now = Date.now(); if (now - lastMv < 200) return; lastMv = now;
    const t = e.target; if (!t || !t.closest) return;
    const o = cardOf('O'); if (o && o.contains(t)) { over = 'O'; return; }
    const s = cardOf('S'); if (s && s.contains(t)) over = 'S';
  }, { passive: true });
  window.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && !e.altKey && (e.key === 'S' || e.key === 's')) {
      const tg = e.target && e.target.tagName; if (tg === 'INPUT' || tg === 'TEXTAREA') return;
      e.preventDefault(); snap(document.getElementById(over === 'O' ? 'xr-oplot' : 'xr-plot') ? over : (over === 'O' ? 'S' : 'O'));
    }
  }, true);
})();
