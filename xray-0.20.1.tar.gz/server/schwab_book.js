// Live options order book (Level 2) from Schwab's streaming feed: every exchange's bid and ask for one contract,
// like Webull's Order Book. Opens the stream only while someone is looking at a book, and closes it when idle.
'use strict';

const toSchwab = (occ) => { const m = /^([A-Z.]{1,6})(\d{6}[CP]\d{8})$/.exec(String(occ || '')); return m ? m[1].padEnd(6, ' ') + m[2] : null; };
const fromSchwab = (s) => String(s || '').replace(/\s+/g, '');

class SchwabBook {
  constructor(client, log) {
    this.c = client; this.log = log || (() => {});
    this.ws = null; this.state = 'off'; this.err = null; this.info = null;
    this.books = new Map();   // occ -> { t, bids, asks, at }
    this.want = new Map();    // occ -> last asked (ms)
    this.subbed = ''; this.reqId = 1; this.retryAt = 0;
    this._idle = setInterval(() => this.tidy(), 5000); if (this._idle.unref) this._idle.unref();
  }

  // what /api/book returns for one contract
  get(occ) {
    const key = toSchwab(occ); if (!key) return { error: 'Not an option contract.' };
    this.want.set(occ, Date.now());
    this.open().catch(() => {});
    this.sync();
    const b = this.books.get(occ);
    return { occ, state: this.state, error: this.err, book: b || null, age: b ? Date.now() - b.at : null };
  }

  async open() {
    if (this.ws || this.state === 'connecting' || Date.now() < this.retryAt) return;
    if (typeof WebSocket !== 'function') { this.state = 'error'; this.err = 'Live order book needs a newer X-ray build.'; return; }
    this.state = 'connecting'; this.err = null;
    try {
      const at = await this.c.accessToken();
      const pref = await this.c.raw('GET', '/trader/v1/userPreference', { Authorization: 'Bearer ' + at, Accept: 'application/json' });
      const si = pref && pref.streamerInfo && pref.streamerInfo[0];
      if (!si || !si.streamerSocketUrl) throw new Error('Schwab did not return streaming access for this login.');
      this.info = si;
      const ws = new WebSocket(si.streamerSocketUrl); this.ws = ws;
      ws.onopen = () => this.send([{ service: 'ADMIN', command: 'LOGIN', parameters: { Authorization: at, SchwabClientChannel: si.schwabClientChannel, SchwabClientFunctionId: si.schwabClientFunctionId } }]);
      ws.onmessage = (ev) => this.onMsg(ev.data);
      ws.onerror = () => { this.err = 'Lost the Schwab stream.'; };
      ws.onclose = () => { this.ws = null; this.subbed = ''; if (this.state !== 'off') { this.state = 'off'; this.retryAt = Date.now() + 5000; } };
    } catch (e) {
      this.ws = null; this.state = 'error'; this.err = e.message || 'Could not open the Schwab stream.'; this.retryAt = Date.now() + 15000;
      this.log('book: ' + this.err);
    }
  }

  send(reqs) {
    if (!this.ws || this.ws.readyState !== 1 || !this.info) return;
    const si = this.info;
    this.ws.send(JSON.stringify({ requests: reqs.map((r) => Object.assign({ requestid: String(this.reqId++), SchwabClientCustomerId: si.schwabClientCustomerId, SchwabClientCorrelId: si.schwabClientCorrelId }, r)) }));
  }

  onMsg(raw) {
    let m; try { m = JSON.parse(raw); } catch (e) { return; }
    (m.response || []).forEach((r) => {
      if (r.service === 'ADMIN' && r.command === 'LOGIN') {
        const code = r.content && r.content.code;
        if (code === 0) { this.state = 'live'; this.err = null; this.subbed = ''; this.sync(); }
        else { this.state = 'error'; this.err = 'Schwab stream login failed' + (r.content && r.content.msg ? ': ' + r.content.msg : '.'); try { this.ws.close(); } catch (e) { /* closed */ } this.retryAt = Date.now() + 30000; }
      }
    });
    (m.data || []).forEach((d) => {
      if (d.service !== 'OPTIONS_BOOK') return;
      (d.content || []).forEach((c) => {
        const occ = fromSchwab(c.key || c['0']);
        const side = (arr) => (Array.isArray(arr) ? arr : []).map((lv) => ({
          p: +lv['0'], size: +lv['1'] || 0, n: +lv['2'] || 0,
          mm: (Array.isArray(lv['3']) ? lv['3'] : []).map((x) => ({ id: String(x['0'] || ''), size: +x['1'] || 0, t: +x['2'] || 0 }))
        })).filter((lv) => Number.isFinite(lv.p));
        this.books.set(occ, { t: +c['1'] || Date.now(), bids: side(c['2']).sort((a, b) => b.p - a.p), asks: side(c['3']).sort((a, b) => a.p - b.p), at: Date.now() });
      });
    });
  }

  // keep the subscription equal to the contracts someone looked at in the last 20 seconds
  sync() {
    if (this.state !== 'live') return;
    const now = Date.now();
    const keys = [...this.want.entries()].filter(([, t]) => now - t < 20000).map(([o]) => toSchwab(o)).filter(Boolean).slice(0, 5).sort().join(',');
    if (keys === this.subbed) return;
    this.subbed = keys;
    if (keys) this.send([{ service: 'OPTIONS_BOOK', command: 'SUBS', parameters: { keys, fields: '0,1,2,3' } }]);
    else this.send([{ service: 'OPTIONS_BOOK', command: 'UNSUBS', parameters: { keys: '' } }]);
  }

  tidy() {
    const now = Date.now();
    for (const [o, t] of this.want) if (now - t > 20000) { this.want.delete(o); this.books.delete(o); }
    this.sync();
    if (!this.want.size && this.ws) { this.state = 'off'; try { this.send([{ service: 'ADMIN', command: 'LOGOUT', parameters: {} }]); this.ws.close(); } catch (e) { /* closed */ } this.ws = null; this.subbed = ''; }
  }
}

module.exports = { SchwabBook, toSchwab };
